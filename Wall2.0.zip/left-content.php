<div class="panel panel-white">
            <div class="panel-heading">
              <h3 class="panel-title">Welcome to Wall Script <?php //echo "$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
              </h3>
            </div>
            
            <div class="panel-body">
              <img src="user_img/<?php echo $folder1.'/'.$g_img; ?>" class="home-avatar img-thumbnail" alt="user profile image">
              <a href="profile.php">@ <?php echo urlencode($username); ?> </a><br/>
              Connection Status 
              <a href="profile.php"><i class="fa fa-check-circle connected-status"></i> </a>
              <?php
                 
                  echo '<h5 class="text-white text-center alert-success"> online Now</h5>'
                  ?>
               
            </div>
          </div>
<?php
$today=date('d');
$tomonth=date('m');
if ($day==$today AND $month==$tomonth) 
{

echo '     <div class="panel panel-white">
            <div class="panel-heading">
              <h3 class="panel-title" style="font-family:monospace,monospace; color: green">Happy Earth day !!! From Wall Script
              </h3>
            </div>
            
            <div class="panel-body">
              <p align="center" style="color: pink;">designed to help people of all skill levels – designer or developer, huge nerd or early beginner.
copy and paste the code. Use it as a complete kit or use it to start something more complex.
tags: chat,user,list,message,social network,messages,messenger</p>             
            </div>
          </div>';
}
?>

                      <div class="panel panel-default panel-user-detail">
            <div class="panel-body">
              <ul class="list-unstyled">
                <li><i class="fa fa-suitcase"></i> Works at <a href="#"><?php echo $headline;?></a></li>
                <li><i class="fa fa-calendar"></i> Born on <?php echo "$day - $month - $yr";?></li>

<?php

$queryFollowing=$db->query("SELECT F.status, U.username,U.img,U.uid, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
END

AND
F.status='1'");
 //Count total number of people am following
$rowCountFollowing = mysqli_num_rows($queryFollowing); // count of total friends


$queryFollowers=$db->query("SELECT F.status, U.username,U.img,U.uid, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = U.uid
THEN F.friend_two = '$_SESSION[uid]'
END

AND
F.status='1'");
 //Count total number of people am following
$rowCountFollowers = mysqli_num_rows($queryFollowers); // count of total friends

?>

                <li><i class="fa fa-rss"></i> Followed by 
                <a href="home.php"><?php 
                if($rowCountFollowers <=1)
                {
                  echo "$rowCountFollowers Person";
                }
                else
                {
                  echo "$rowCountFollowers People";
                }
                ?>
                 </a>
                 </a></li>
                 <li><i class="fa fa-rss"></i> Following 
                <a href="home.php"><?php if($rowCountFollowing <=1)
                {
                  echo "$rowCountFollowing Person";
                }
                else
                {
                  echo "$rowCountFollowing People";
                }
                ?>
                 </a></li>
                 <li><i class="fa fa-globe"></i> Visit
                 <?php if(!empty($site))
                {
                  echo '<a href="http://'.$site.'">'.$site.'</a>';
                }
                ?>
                </li>
                
                 <?php 
                if(empty($name))
                {
              echo '<li><i class="fa fa-info"></i>
              <a href="edit-profile.php" class="alert alert-warning"> You are awesome, but You\'r not complete</a></li>';
                }
                ?>
                
              </ul>
            </div>
            </div>
    
          <div class="panel panel-white">
            <div class="panel-heading">
              <h3 class="panel-title">Friends activity
              </h3>
            </div>
            <div class="panel-body">
            <?php
$querycount = $db->query("SELECT * FROM notification ORDER BY id DESC LIMIT 0,10");
    //Count total number of rows
    //$tweetcount = $querycount->num_rows;

while($items=mysqli_fetch_array($querycount))
{
  $id=$items['id'];
  $activityID=$items['activityID'];
  $userid=$items['userid'];
  $type=$items['type'];
  $ncreated=$items['created'];
// if grouppost select from group update table
  if ($type=='grouppost') {

$query001 = $db->query("SELECT G.group_name, G.img, G.group_id, U.created FROM groups G, updates U WHERE G.group_id='$activityID' ORDER BY U.update_id DESC  ");
 $tweetcount = $query001->num_rows;

$row=mysqli_fetch_array($query001);
$group_id=$row['group_id'];
$group_name=$row['group_name'];
$group_img=$row['img'];
$group_created=$row['created'];

$sql_user= $db->query("SELECT img, username,uid FROM users WHERE uid=$userid");
$ruser=mysqli_fetch_array($sql_user);
//$name=$ruser['name'];
$username=$ruser['username'];
$imgpost=$ruser['img'];
$groupowner=$ruser['uid'];


echo '
<div class="notification-row">
                <div class="notification-padding">
                  <div class="sidebar-fa-image">
                    <img src="groups/'.$group_name.'/'.$group_img.'" class="avatar" alt="'.$group_name.'">
                  </div>
                  <div class="sidebar-fa-text">
                    <b>
                      <a href="'.$username.'" class="post-user-name">'.$username.'</a>
                    </b> Share a post on 
                    <b>
                      <a href="group.php?id='.$group_id.'">'.$group_name.' Group Wall </a>
                    </b><br/>
                    <span class="timeago" >'.time_passed($ncreated).'</span>
                  </div>
                </div>
              </div>';

       

  }

 
}
 
  if ($tweetcount > 10) {
 echo '<a href="notifications.php" class="pull-right">View all&nbsp;<i class="fa fa-edit"></i></a>
';
              }    

?>
</div>
</div>
<!-- End Friends activity -->

          <!-- suggested groups -->
          <div class="panel panel-white panel-groups">
            <div class="panel-heading">
              <h3 class="panel-title">Suggested Groups
              </h3>
            </div>
            <div class="panel-body">
              <ul class="list-group">
                <?php
$querygroup= $db->query("select * from groups");
  while($pages=mysqli_fetch_array($querygroup))
  {
  $groupName=$pages['group_name'];
  $groupImage=$pages['img'];
  $GroupId=$pages['group_id'];


  echo '<li class="list-group-item">
                  <div class="col-xs-3 col-sm-6 col-md-3">
                      <img src="groups/'.$groupName.'/'.$groupImage.'" alt="Group" class="img-responsive" />
                  </div>
                  <div class="col-xs-9 col-sm-6">
                      <a href="group.php?id='.$GroupId.'"><span class="name">'.$groupName.'</span></a>
                  </div>
                  <div class="clearfix"></div>
                </li>
';
  }
?>  
              </ul>
            </div>
          </div>
          <!--End suggested groups -->  
          <!-- People You May Know -->
          <div class="panel panel-white">
            <div class="panel-heading">
              <h3 class="panel-title">People You May Know
              </h3>
            </div>
            <div class="panel-body">

              
              <!-- *********************************************************************
   Purpose      : to determin if the logged in user is folloeing any user else
                  display follow button or following button to current user
   Returns      : True or false

                                  START HERE
   *********************************************************************** -->
                <?php
                $friendsall=$db->query("SELECT * FROM users ORDER BY rand() ASC LIMIT 0,7 ");

                while ($data=mysqli_fetch_array($friendsall)) {
                  //$name=$data['name'];
                  $img=$data['img'];
                  $username=$data['username'];
                  $userid=$data['uid'];
                if ($userid==$session_uid) {
                  # code...
                  echo ' <div class="notification-row">
                <div class="notification-padding">
                  <div class="sidebar-fa-image img-may-know">
                    <img class="notifications" src="user_img/'.$username.'/'.$img.'">
                  </div>
                  <div class="sidebar-fa-text">
                    <b>
                      <a href="'.$username.'">'.$username.'</a>
                    </b>
                    <br>
                    <a class="btn btn-warning btn-sm" href="">
                      <i class="fa fa-user"> You
                      </i>
                    </a>
                  </div>
                </div>
              </div>';
                }else{
//
                  echo ' <div class="notification-row">
                <div class="notification-padding">
                  <div class="sidebar-fa-image img-may-know">
                    <img class="notifications" src="user_img/'.$username.'/'.$img.'">
                  </div>
                  <div class="sidebar-fa-text">
                    <b>
                      <a href="'.$username.'">'.$username.'</a>
                    </b>';

                  echo '
                  <br>
                    <a class="btn btn-success btn-sm" href="'.$username.'"">
                      <i class="fa fa-play-circle"> View Profile
                      </i>
                    </a>
                  </div>
                </div>
              </div>';
                            // end form here
                

                }
                }
                ?>
<!-- *********************************************************************
   Purpose      : to determin if the logged in user is following any user else
                  display follow button or following button to current user
   Returns      : True or false

                                  END HERE
   *********************************************************************** -->
					
            </div>
          
            <?php

$errorMessage = '&nbsp;';


if (isset($_POST['feedx'])) {

  $Sendername  = $_SESSION['username'];
    $Senderemail  = $_SESSION['email'];
    $msg  = ($_POST['feedx']);
//now send email

 // The email address is valid } 

  $to = "unduworldofliving@gmail.com";
  $subject="Suggestion";
  $body = "From: $Sendername <br/> Email:  $Senderemail <hr/><br/> $msg <hr/>";
  $header = "From: $Sendername@Thewallclone.com \r\n";
  $header .= "MIME-Version: 1.0\r\n";
  $header .= "Content-type: text/html\r\n";

if (mail($to, $subject, $body, $header))

{  
 echo("<script>alert('Thank you for your interest to help render a good services!'); </script></p>"); 
 } 
else
 {   
  echo("<script>alert('Email delivery failed…'); </script>"); 
  } 
}

  ?>
        <!-- invite -->
          <div class="panel panel-white panel-groups left-content">
            <div class="panel-heading">
              <h3 class="panel-title">COMMENT / FEEDBACK
              </h3>
            </div>
            <div class="panel-body">
            <p>We are always open to the suggestions on how to improve our website.</p>
             <form action="" method="POST" name="form" id="imageform">
<textarea name="feedx" id="feedx" required="" class="form-control input-lg p-text-area" rows="3" cols="25" placeholder="Write your suggestions here"></textarea>
<div class="panel-footer">
<input type="submit" id="" value="Send  your suggestions" class="btn btn-info pull-right">               
</div>
</form>

            </div>
          </div>
          
          </div>