<?php
include 'session.php';
include 'connection.php';

?>
<?php
$session_uid=$_SESSION['uid'];
$query_profile= $db->query("select * from users where uid=$session_uid AND 1=1");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_email=$user_data['email'];
  $profile_background=$user_data['profile_background'];
  $g_img=$user_data['img'];
  $profile_background_position=$user_data['profile_background_position'];

$folder1=$_SESSION['username'];

$sqlheadline=$db->query("select * from user_bio where uid='$session_uid'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$linked=$row['linkedIn'];
$info=$row['about'];

  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Day-Friend</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">
    <script src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
            <style type="text/css">
      body {
  padding-top: 0;
  font-size: 14px;
  color: #777;
  background: #f9f9f9;
  font-family: 'Open Sans',sans-serif;
  margin-top:20px;
}

.bg-white {
  background-color: #fff;
}

.friend-list {
  list-style: none;
margin-left: -40px;
}

.friend-list li {
  border-bottom: 1px solid #eee;
}

.friend-list li a img {
  float: left;
  width: 45px;
  height: 45px;
  margin-right: 0px;
}

 .friend-list li a {
  position: relative;
  display: block;
  padding: 10px;
  transition: all .2s ease;
  -webkit-transition: all .2s ease;
  -moz-transition: all .2s ease;
  -ms-transition: all .2s ease;
  -o-transition: all .2s ease;
}

.friend-list li.active a {
  background-color: #f1f5fc;
}

.friend-list li a .friend-name, 
.friend-list li a .friend-name:hover {
  color: #777;
}

.friend-list li a .last-message {
  width: 65%;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}

.friend-list li a .time {
  position: absolute;
  top: 10px;
  right: 8px;
}

small, .small {
  font-size: 85%;
}

.friend-list li a .chat-alert {
  position: absolute;
  right: 8px;
  top: 27px;
  font-size: 10px;
  padding: 3px 5px;
}

.chat-message {
  padding: 60px 20px 115px;
}

.chat {
    list-style: none;
    margin: 0;
}

.chat-message{
    background: #f9f9f9;  
}

.chat li img {
  width: 45px;
  height: 45px;
  border-radius: 50em;
  -moz-border-radius: 50em;
  -webkit-border-radius: 50em;
}

img {
  max-width: 100%;
}

.chat-body {
  padding-bottom: 20px;
}

.chat li.left .chat-body {
  margin-left: 70px;
  background-color: #fff;
}

.chat li .chat-body {
  position: relative;
  font-size: 14px;
  padding: 10px;
  border: 1px solid #f1f5fc;
  box-shadow: 0 1px 1px rgba(0,0,0,.05);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,.05);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,.05);
}

.chat li .chat-body .header {
  padding-bottom: 5px;
  border-bottom: 1px solid #f1f5fc;
}

.chat li .chat-body p {
  margin: 0;
}

.chat li.left .chat-body:before {
  position: absolute;
  top: 10px;
  left: -8px;
  display: inline-block;
  background: #fff;
  width: 16px;
  height: 16px;
  border-top: 1px solid #f1f5fc;
  border-left: 1px solid #f1f5fc;
  content: '';
  transform: rotate(-45deg);
  -webkit-transform: rotate(-45deg);
  -moz-transform: rotate(-45deg);
  -ms-transform: rotate(-45deg);
  -o-transform: rotate(-45deg);
}

.chat li.right .chat-body:before {
  position: absolute;
  top: 10px;
  right: -8px;
  display: inline-block;
  background: #fff;
  width: 16px;
  height: 16px;
  border-top: 1px solid #f1f5fc;
  border-right: 1px solid #f1f5fc;
  content: '';
  transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
  -moz-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  -o-transform: rotate(45deg);
}

.chat li {
  margin: 15px 0;
}

.chat li.right .chat-body {
  margin-right: 70px;
  background-color: #fff;
}

.chat-box {
  position: fixed;
  bottom: 0;
  left: 444px;
  right: 0;
  padding: 15px;
  border-top: 1px solid #eee;
  transition: all .5s ease;
  -webkit-transition: all .5s ease;
  -moz-transition: all .5s ease;
  -ms-transition: all .5s ease;
  -o-transition: all .5s ease;
}

.primary-font {
  color: #3c8dbc;
}

a:hover, a:active, a:focus {
  text-decoration: none;
  outline: 0;
}
    </style>
  </head>
  <body class="animated fadeIn">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <a class="navbar-brand" href="home.php">
            <b>The Wall Script 2.0
            </b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <div class="col-md-5 col-sm-4">         
            <form class="navbar-form" action="search.php" method="get">
              <div class="form-group" style="display:inline;">
                <div class="input-group" style="display:table;">
                  <input class="form-control" name="s" placeholder="Hit Enter Search Users, Groups..." autocomplete="off" type="text">
                  <input type="hidden" name="searching" value="yes" />
                  <span class="input-group-addon" style="width:1%;">
                    <span class="fa fa-search"></span>
                  </span>
                </div>
              </div>
            </form>
          </div>        
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="home.php">
                <i class="fa fa-bars">
                </i>&nbsp;Home
              </a>
            </li>
            <li  class="active">
              <a href="messages.php">
                <i class="fa fa-envelope">
                </i>
              </a>
            </li>
            <li>
              <a href="notifications.php">
                <i class="fa fa-globe">
                </i>
              </a>
            </li>
            <li>
              <a href="edit-profile.php">
                <i class="fa fa-cogs">
                </i>
              </a>
            </li>
            <li>
              <a href="#" class="nav-controller">
                <i class="fa fa-users">
                </i>
              </a>
            </li>
            <li>
              <a href="logout.php" class="nav-controller">
                <i class="fa fa-sign-out">
                </i> Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Timeline content -->
    <div class="container bootstrap snippet">
    <div class="row">
    <div class="col-md-4 bg-white ">
            <div class=" row border-bottom padding-sm" style="height: 13px;">
            </div>
            
            <!-- =============================================================== -->
            <!-- member list -->
            <h2 align="center">Member's</h2>

            <ul class="friend-list">
<?php
  require "classes/agoTime_example.php";

$query= $db->query("SELECT u.uid,c.c_id,u.username,u.email,u.img
 FROM conversation c, users u
 WHERE CASE
 WHEN c.user_one = '$session_uid'
 THEN c.user_two = u.uid
 WHEN c.user_two = '$session_uid'
 THEN c.user_one= u.uid
 END
 AND (
 c.user_one ='$session_uid'
 OR c.user_two ='$session_uid'
 )
 Order by c.c_id DESC Limit 20") or die(mysql_error());

while($list=mysqli_fetch_array($query))
{
$c_id=$list['c_id'];
$user_id=$list['uid'];
$username=$list['username'];
$email=$list['email'];
$Cimg=$list['img'];

$cquery= $db->query("SELECT R.cr_id,R.time,R.reply,u.img 
  FROM conversation_reply R, users u 
  WHERE R.c_id_fk='$c_id' ORDER BY R.cr_id DESC LIMIT 1") or die(mysqli_error());
$crow=mysqli_fetch_array($cquery);
$cr_id=$crow['cr_id'];
$reply=$crow['reply'];
$time=$crow['time'];
//HTML Output.

?>
                <li class="active bounceInDown">
                  <a href="?token=<?php echo $user_id; ?>" class="clearfix">
                    <img src="user_img/<?php echo "$username/$Cimg"; ?>" alt="" class="img-circle">
                    <div class="friend-name"> 
                      <strong> <?php echo $username ?></strong>
                    </div>
                    <div class="last-message text-muted"> <?php echo $reply; ?></div>
                    <small class="time text-muted"><?php echo time_passed($time); ?></small>
                    <small class="chat-alert label label-danger">1</small>
                  </a>
                </li>

   <?php } ?>            

            </ul>
    </div>

        
        <!--=========================================================-->
<?php
if (isset($_GET['token'])) {
  $token=($_GET['token']);

//##############   IF USER SELECTED GET ID FROM URL PASS THE SCRIPT BELOW

 $sql_chat=$db->query("SELECT * FROM users WHERE uid ='$token'");
$user_get=mysqli_fetch_array($sql_chat);
$get_id=$user_get['uid'];
$get_username=$user_get['username'];
$get_img=$user_get['img'];

 ?>


  <?php
if(isset($_POST['msg']) && $_POST['msg'] != '')
{
  $message =htmlspecialchars($_POST['msg']);
  $user_one=htmlentities($_SESSION['uid']);
  $user_two=$get_id;


$time=time();
$ip=$_SERVER['REMOTE_ADDR'];


$query_users= $db->query("SELECT img FROM users WHERE (uid='$user_one')") or die(mysqli_error());
$users=mysqli_fetch_assoc($query_users);
$img_db=$users['img'];

$q= $db->query("SELECT c_id FROM conversation WHERE (user_one='$user_one' and user_two='$user_two') or (user_one='$user_two' and user_two='$user_one') ") or die(mysqli_error());
$row=mysqli_fetch_assoc($q);
$cid_db=$row['c_id'];

if(mysqli_num_rows($q)==0)
{
$query = $db->query("INSERT INTO conversation (user_one,user_two,ip,time) VALUES ('$user_one','$user_two','$ip','$time')") or die(mysql_error());

$q= $db->query("SELECT c_id FROM conversation WHERE (user_one='$user_one' and user_two='$user_two') or (user_one='$user_two' and user_two='$user_one') ") or die(mysqli_error());
$row=mysqli_fetch_assoc($q);
$cid_db=$row['c_id'];

$db->query("INSERT INTO conversation_reply (user_id_fk,reply,ip,time,c_id_fk) VALUES ('$user_one','$message','$ip','$time','$cid_db')");
}
else
{
$db->query("INSERT INTO conversation_reply (user_id_fk,reply,ip,time,c_id_fk) VALUES ('$user_one','$message','$ip','$time','$cid_db')");

}
}// if post action was taken
?>

<?php
$check= $db->query("SELECT u.uid,c.c_id,u.username,u.email,u.img
 FROM conversation c, users u
 WHERE 
 c.user_one = '$get_id'
AND
 c.user_two ='$session_uid'

 OR 
  c.user_one = '$session_uid'
AND
 c.user_two ='$get_id'
 
 Order by c.c_id DESC") or die(mysqli_error());

$data=mysqli_fetch_array($check);
$c_id=$data['c_id'];
$user_id=$data['uid'];
$c_username=$data['username'];

$query= $db->query("SELECT R.cr_id,R.time,R.reply,U.uid,U.img,U.username,U.email FROM users U, conversation_reply R WHERE R.user_id_fk=U.uid and R.c_id_fk='$c_id' ORDER BY R.cr_id ASC LIMIT 20") or die(mysqli_error());
$checkconver=mysqli_num_rows($query);
?>        
        <!-- selected chat -->
      <div class="col-md-8 bg-white ">
            <div class="chat-message">
                <ul class="chat">
 <?php
//convert hashtags
function gethashtags($text)
{
  //Match the hashtags
  preg_match_all('/(^|[^a-z0-9_])#([a-z0-9_]+)/i', $text, $matchedHashtags);
  $hashtag = '';
  // For each hashtag, strip all characters but alpha numeric
  if(!empty($matchedHashtags[0])) {
    foreach($matchedHashtags[0] as $match) {
      $hashtag .= preg_replace("/[^a-z0-9]+/i", "", $match).',';
    }
  }
    //to remove last comma in a string
return rtrim($hashtag, ',');
}

//convert text to clickable links
function convert_clickable_links($message)
{
  $parsedMessage = preg_replace(array('/(?i)\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))/', '/(^|[^a-z0-9_])@([a-z0-9_]+)/i', '/(^|[^a-z0-9_])#([a-z0-9_]+)/i'), array('<a href="$1" target="_blank">$1</a>', '$1<a href="">@$2</a>', '$1<a target="_blank" href="http://localhost/social/searchpage.php?s=$2&searching=yes">#$2</a>'), $message);
  return $parsedMessage;
}

while($row=mysqli_fetch_array($query))
{
$cr_id=$row['cr_id'];
$Mtime=$row['time'];
$reply=$row['reply'];
$db_user_id=$row['uid'];
$dbusername=$row['username'];
$email=$row['email'];
$user_img=$row['img'];
//HTML Output
  //get hashtag from message
  $hashtag = gethashtags($reply);

?>

<?php
if ($db_user_id==$get_id){
// IF SELECTED USER ID IS EQUAL TO USER ID GET FROM DATABASE
  // ALIGN USER TO LEFT SIDE
?>               
                    <li class="left clearfix">
                      <span class="chat-img pull-left">
                        <img src="user_img/<?php echo "$dbusername/$user_img"; ?>" alt="User Avatar">
                      </span>
                      <div class="chat-body clearfix">
                        <div class="header">
                          <strong class="primary-font"><?php echo $dbusername; ?></strong>
                            <small class="pull-right text-muted"><i class="fa fa-clock-o"></i> <?php echo time_passed($Mtime); ?></small>
                        </div>
                        <p style="word-wrap: break-word;">
                            <?php echo convert_clickable_links($reply); ?>
                            <?php
if(preg_match('~(?:https?://)?(?:www.)?(?:thescript.net16.net|thescript.net16.net)/(?:group.php\?id=)?([^\s]+)~', $reply, $match1)){


$sql_check= $db->query("SELECT * FROM groups WHERE group_id='".($match1[1])."'");
$groupinfo=mysqli_fetch_array($sql_check);
$group_nameinfo=$groupinfo['group_name'];
$group_info=$groupinfo['group_desc'];
$group_idinfo=$groupinfo['group_id'];
$owner_idinfo=$groupinfo['user_id_fk'];
$group_imginfo=$groupinfo['img'];
$group_coverinfo=$groupinfo['cover'];

if ($group_idinfo==$match1[1]) {
$GroupLike=$db->query("SELECT U.username, U.uid, U.img
FROM
users U, group_users G
WHERE
U.uid=G.user_id_fk
AND
G.group_id_fk='$group_idinfo' ORDER BY G.group_user_id DESC");
 //Count total number of people am following
$CountGroupLike = mysqli_num_rows($GroupLike); // count of total friends like

$querycount = $db->query("SELECT * FROM updates WHERE group_id_fk='".($match1[1])."' ");
    //Count total number of rows
    $tweetcount = $querycount->num_rows;

$postlike= $db->query("SELECT * FROM group_users WHERE group_id_fk='".($match1[1])."' AND status='1' ");
while($liked=mysqli_fetch_array($postlike))
{
$user_id_like_Post=$liked['user_id_fk'];
}

   echo '<a href="group.php?id='.($match1[1]).'"><div class="box box-widget widget-user">';
  ?>

        <div class="" style="background-image: url(<?php echo "groups/$group_nameinfo/$group_coverinfo"; ?>); background-size:cover; position:relative; background-position:center ">
<?php
         echo '
         <h3 class="widget-user-username" style="color:red;">'.$group_nameinfo.' Group</h3>
        </div>
        <div class="widget-user-image">
          <img class="img-responsive" src="groups/'.$group_nameinfo."/".$group_imginfo.'" alt="User Avatar">
        </div></a>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-4 border-right">
              <div class="description-block">
                <h5 class="description-header"><i class="fa fa-rss"></i> '.$tweetcount.'</h5>
                <span class="description-text">TWEETS</span>
              </div>
            </div>
            <div class="col-sm-4 border-right">
              <div class="description-block">';
                ?>
                <?php
                if($CountGroupLike <=1)
                {

                  echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                  <span class="description-text">LIKE</span>';

                }
                else
                {
                   echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                   <span class="description-text">LIKES</span>';
                }
                ?>
                <?php
              echo '</div>
            </div>
            <div class="col-sm-4">
              <div class="description-block">';
              ?>
              <?php
              echo "<h5 class='groupstd' id='($match1[1])'>";
              ?>
                 <h5 class="description-header" id="like<?php echo ($match1[1]); ?>">
                <a href="group.php?id=<?php echo ($match1[1]); ?>"  id="<?php echo ($match1[1]); ?>"><i class="fa fa-link"></i> Visit <?php echo $group_nameinfo; ?></a>
                </h5>

             
                <?php
                echo '<p class="sponsor-name alert-success"><i class="fa fa-check"></i> Sponsored Group</p>
              </div>
            </div>
            <p style="word-wrap: break-word; padding:9px;">'.convert_clickable_links($group_info).'</p>
          </div>
        </div>
      </div>
';
}
else
{
  echo '
              <div class="description-block">
                <h5 class="description-header alert-danger"><i class="fa fa-info-circle"></i> THIS GROUP DOES NOT EXIST</h5>
                <br/>
                <a href="createpage.php" class="alert alert-success"><i class="fa fa-check"></i> CREATE NEW GROUP</a>
              </div>
            ';
}
}
?>
</p>
                      </div>
                    </li>

<!--
##############   ##############   ##############   ##############
Script for youtube and vimeo url extractor

##############   ##############   ##############   ##############
-->
                        <?php
if(preg_match('~(?:https?://)?(?:www.)?(?:youtube.com|youtu.be)/(?:watch\?v=)?([^\s]+)~', $reply, $match)){
echo "<br><iframe width='800' height='300' src='http://www.youtube.com/embed/".$match[1]."' frameborder='0' allowfullscreen class='video'></iframe><br>\n";
//print Youtube ID: ($match[1]);
}

if(preg_match("/(https?:\/\/)?(www.)?(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/", $reply, $output_array)) {
echo "<br>";

echo '<br><iframe width="800" height="300" frameborder="0" src="//player.vimeo.com/video/'.$output_array[5].'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff"></iframe>';

    //echo "Vimeo ID: $output_array[5]";
    }
?>
<!--
##############   ##############   ##############   ##############
End Script for youtube and vimeo url extractor

##############   ##############   ##############   ##############
-->
         
    <?php
    // ELSE ALIGN USER TO RIGHT SIDE
}else
{

?>

                    <li class="right clearfix">
                      <span class="chat-img pull-right">
                        <img src="user_img/<?php echo "$dbusername/$user_img"; ?>" alt="User Avatar">
                      </span>
                      <div class="chat-body clearfix">
                        <div class="header">
                          <strong class="primary-font"><?php echo $dbusername; ?></strong>
                            <small class="pull-right text-muted"><i class="fa fa-clock-o"></i>  <?php echo time_passed($Mtime) ?></small>
                        </div>
                                                  <p style="word-wrap: break-word;">
                            <?php echo convert_clickable_links($reply); ?>
<?php
if(preg_match('~(?:https?://)?(?:www.)?(?:thescript.net16.net|thescript.net16.net)/(?:group.php\?id=)?([^\s]+)~', $reply, $match1)){


$sql_check= $db->query("SELECT * FROM groups WHERE group_id='".($match1[1])."'");
$groupinfo=mysqli_fetch_array($sql_check);
$group_nameinfo=$groupinfo['group_name'];
$group_info=$groupinfo['group_desc'];
$group_idinfo=$groupinfo['group_id'];
$owner_idinfo=$groupinfo['user_id_fk'];
$group_imginfo=$groupinfo['img'];
$group_coverinfo=$groupinfo['cover'];

if ($group_idinfo==$match1[1]) {
$GroupLike=$db->query("SELECT U.username, U.uid, U.img
FROM
users U, group_users G
WHERE
U.uid=G.user_id_fk
AND
G.group_id_fk='$group_idinfo' ORDER BY G.group_user_id DESC");
 //Count total number of people am following
$CountGroupLike = mysqli_num_rows($GroupLike); // count of total friends like

$querycount = $db->query("SELECT * FROM updates WHERE group_id_fk='".($match1[1])."' ");
    //Count total number of rows
    $tweetcount = $querycount->num_rows;

$postlike= $db->query("SELECT * FROM group_users WHERE group_id_fk='".($match1[1])."' AND status='1' ");
while($liked=mysqli_fetch_array($postlike))
{
$user_id_like_Post=$liked['user_id_fk'];
}

   echo '<a href="group.php?id='.($match1[1]).'"><div class="box box-widget widget-user">';
  ?>

        <div class="" style="background-image: url(<?php echo "groups/$group_nameinfo/$group_coverinfo"; ?>); background-size:cover; position:relative; background-position:center ">
<?php
         echo '
         <h3 class="widget-user-username" style="color:red;">'.$group_nameinfo.' Group</h3>
        </div>
        <div class="widget-user-image">
          <img class="img-responsive" src="groups/'.$group_nameinfo."/".$group_imginfo.'" alt="User Avatar">
        </div></a>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-4 border-right">
              <div class="description-block">
                <h5 class="description-header"><i class="fa fa-rss"></i> '.$tweetcount.'</h5>
                <span class="description-text">TWEETS</span>
              </div>
            </div>
            <div class="col-sm-4 border-right">
              <div class="description-block">';
                ?>
                <?php
                if($CountGroupLike <=1)
                {

                  echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                  <span class="description-text">LIKE</span>';

                }
                else
                {
                   echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                   <span class="description-text">LIKES</span>';
                }
                ?>
                <?php
              echo '</div>
            </div>
            <div class="col-sm-4">
              <div class="description-block">';
              ?>
              <?php
              echo "<h5 class='groupstd' id='($match1[1])'>";
              ?>
                 <h5 class="description-header" id="like<?php echo ($match1[1]); ?>">
                <a href="group.php?id=<?php echo ($match1[1]); ?>"  id="<?php echo ($match1[1]); ?>"><i class="fa fa-link"></i> Visit <?php echo $group_nameinfo; ?></a>
                </h5>

             
                <?php
                echo '<p class="sponsor-name alert-success"><i class="fa fa-check"></i> Sponsored Group</p>
              </div>
            </div>
            <p style="word-wrap: break-word; padding:9px;">'.convert_clickable_links($group_info).'</p>
          </div>
        </div>
      </div>
';
}
else
{
  echo '
              <div class="description-block">
                <h5 class="description-header alert-danger"><i class="fa fa-info-circle"></i> THIS GROUP DOES NOT EXIST</h5>
                <br/>
                <a href="createpage.php" class="alert alert-success"><i class="fa fa-check"></i> CREATE NEW GROUP</a>
              </div>
            ';
}
}
?>
                          </p>
                      </div>
                    </li>
<!--
##############   ##############   ##############   ##############
Script for youtube and vimeo url extractor

##############   ##############   ##############   ##############
-->
                        <?php
if(preg_match('~(?:https?://)?(?:www.)?(?:youtube.com|youtu.be)/(?:watch\?v=)?([^\s]+)~', $reply, $match)){
echo "<br><iframe width='800' height='300' src='http://www.youtube.com/embed/".$match[1]."' frameborder='0' allowfullscreen class='video'></iframe><br>\n";
//print Youtube ID: ($match[1]);
}

if(preg_match("/(https?:\/\/)?(www.)?(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/", $reply, $output_array)) {
echo "<br>";

echo '<br><iframe width="800" height="300" frameborder="0" src="//player.vimeo.com/video/'.$output_array[5].'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff"></iframe>';

    //echo "Vimeo ID: $output_array[5]";
    }
?>
<!--
##############   ##############   ##############   ##############
End Script for youtube and vimeo url extractor

##############   ##############   ##############   ##############
-->
           

<?php } }
// ##################   END DECSION #################
?>
      
                    

                </ul>
            </div>
            <form action="" method="post">
            <div class="chat-box bg-white">
              <div class="input-group">
                <input class="form-control border no-shadow no-rounded" autofocus="" name="msg" placeholder="Type your message here">
                <span class="input-group-btn">
                 <input type="hidden" id="user_two" value="<?php echo $token; ?>">
                <input type="hidden" id="user2" value="<?php echo $_SESSION['uid']; ?>">

                  <button type="submit" name="send" class="btn btn-success no-rounded" type="button">Send</button>
                </span>
              </div><!-- /input-group --> 
            </div>  
            </form>          
    </div>        
  </div>
</div>
 <?php
}
else
{

echo '<div class="description-block">
                <h5 class="description-header alert-danger"><i class="fa fa-info-circle"></i> SELECT USER TO START NEW OR EXISTING CONVERSATION</h5>
                <br/>
                <a href="friends.php" class="alert alert-success"><i class="fa fa-check"></i> CREATE NEW CONVERSATION</a>
              </div>';
}
// ##################  IF USER IS NOT SELECT DISPLAY MESSAGE ################

?>

   
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs"><a href="#" class="hide-chat btn btn-success btn-sm">Hide</a></p> 
        <p class="text-center chat-title">Online users</p>  
           <?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs">
          <a href="#" class="hide-chat btn btn-success btn-sm">Hide
          </a>
        </p> 
        <p class="text-center chat-title">Online users</p>  
<?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>
      </div>
    </div><!-- Online users sidebar content-->


    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>
  </body>
</html>
