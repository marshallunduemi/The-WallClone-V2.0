  <?php
  // include db configuration
  require_once "config/config.php";
  ?>

  <!DOCTYPE html>
  <html lang="en">
     <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="images/favicon.ico">
        <title>THE WALL SCRIPT SOCIAL NETWORK : PASSWORD RESET</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/login/css/animate.min.css" rel="stylesheet">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet">
        <link href="assets/login/css/timeline.css" rel="stylesheet">

  <link rel="stylesheet" type="text/css" href="css/style.css" />
        <!--[if lt IE 9]> <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
     </head>
     <body class="welcome-page animated fadeIn">
        <nav class="navbar navbar-default navbar-fixed-top navbar-principal welcome-nav">
           <div class="container">
              <div class="navbar-header">
                 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                     <a class="navbar-brand" href="#">
                        <img src="images/logo.png" class="img-logo"> <b>THE WALL SCRIPT</b>
                      </a>
                    </div>
              <!-- <div id="navbar" class="collapse navbar-collapse"> <ul class="nav navbar-nav navbar-right">
               <li><a href="profile.html"><i class="fa fa-user fa-2x"></i>Profile</a></li><li><a href="home.html"><i class="fa fa-home fa-2x"></i>Home</a></li></ul> </div>-->
           </div>
        </nav>
        <div class="row-welcome" style="background-image: url('images/pass.png'); background-size: 1400px; margin-top: 20px;">
           <div class="row-body">
              <div class="welcome-inner">
                 <!-- <div class="welcome-message welcome-text-shadow">
                    <div class="welcome-title"> Welcome </div>
                    <div class="welcome-desc"> To WALLSCRIPT VERSION 1.0 Build Your Own Social network </div>
                    <div class="welcome-about"> share your memories, connect with others, make new friends. </div>
                 </div>-->
                 <div class="welcome-inputs animated fadeInLeft">

                 <h1>Change Password </h1>
<?php
if(!empty($_POST['password']) && !empty($_POST['password1'])){
  $password=md5($_POST['password']);
  $password1=md5($_POST['password1']);
  if($password == $password1)
 {   
  $passup=$db->query("UPDATE users SET password ='".$password."'  WHERE userid='".$userid."'") ;;
?>
<script>
 function Redirect() {
 window.location="<?php echo "login.php";?>" } 
 document.write('<p align="center" style="background-color:#CFF;">Password updated !<br> Authormatically redirect in 5 sec.</p>'); setTimeout('Redirect()', 5000);
 
 </script>
<?php  
 }else
 {
  echo"<p align='center' style='background-color:#CFF;'>Password is not thesame try again !</p>";
 }
  }
  if(empty($_POST['password']) && empty($_POST['password1'])){
echo"<p align='center' style='background-color:#CFF;'>All fields required !</p>";
  }

?>
                 </div>
              </div>
           </div>
        </div>
        <div class="welcome-full">
           <div class="row-body">
              <div class="welcome-users-inner animated fadeInRight">

              </div>
           </div>
        </div>
        <footer class="welcome-footer">
           <div class="container">
              <p>
              <div class="footer-links"> <a href="http://codexpresslabs.info/">Website</a> | <a href="#">Privacy Policy</a> | <a href="http://facebook.com/marshallunduemi">Developer</a> | <a href="http://codexpresslabs.info/p/contact-me.html">Contact</a> | <a href="http://codexpresslabs.info/p/about-me.html">About</a> | <a href="http://codexpresslabs.info/p/about-me.html">Download</a>  </div>
              Copyright &copy; Codexpress labs- All rights reserved </p>
           </div>
        </footer>
     </body>
        <script src="assets/js/jquery.1.11.1.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/custom.js"></script>
        <script src="js/modernizr-2.0.6-min.js"></script>


     <script type="text/javascript">
       $(function(){
  $('#username').bind('input', function(){
    $(this).val(function(_, v){
     return v.replace(/\s+/g, '');
    });
  });
});
     </script>

     <script>
$(document).ready(function(){
    if(!Modernizr.input.placeholder) {
        $("input[placeholder]").each(function() {
            var placeholder = $(this).attr("placeholder");

            $(this).val(placeholder).focus(function() {
                if($(this).val() == placeholder) {
                    $(this).val("")
                }
            }).blur(function() {
                if($(this).val() == "") {
                    $(this).val(placeholder)
                }
            });
        });
    } // Modernizr placeholder
});
</script>

<script type="text/javascript">
function removeSpaces(string) {
 return string.split(' ').join('');
}
</script>
  </html>
