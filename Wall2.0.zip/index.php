<?php
  include('login.php'); // Include Login Script

  if ((isset($_SESSION['username']) != '')) 
  {
    header('Location: home.php');
  } 
  include ('validate_signup.php');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta content='Marshall unduemi' name='author'/>
<meta content='info@codexpresslabs.info' name='email'/>
<meta content='en' name='language'/>
<meta content='nigeria' name='country'/>
<meta content='blogger' name='generator'/>
<meta content='FOLLOW,INDEX' name='robots'/>
<meta content='Welcome to our social networking script fully customizable, easy to implement, this script gives you access to build your own social website in minute or two.' name='description'/>
<meta content='The Wall Clone Social Network : Codexpress Labs Programming Blog' property='og:site_name'/>
<!-- <meta expr:content='data:blog.homepageUrl' name='twitter:domain'/> -->
<meta content='Wall Clone Social Network Script 2.0' name='twitter:title'/>
    <link rel="icon" href="img/favicon.jpg">
    <title><?php echo APPNAME ?></title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <!--<link href="css/font-awesome.min.css" rel="stylesheet">-->
    <link href="css/timeline.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="welcome-page animated fadeIn">
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal welcome-nav">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" value="Login" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Login</span>
            <span class="btn btn-warning">Login</span>
 
          </button>
          <a class="navbar-brand" href="#">
            <img src="images/logo.jpg" class="img-logo">
            <b>The Wall Clone</b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav navbar-right">
              <form class="navbar-form form-login" role="form" action="" method="POST" autocomplete="off" id="login">
                  <div class="form-group">
                      <input type="text" class="form-control" id="username" name="username" placeholder="Username">
                  </div>
                  <div class="form-group">
                      <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                  </div>
                  <button type="submit" name="submit" class="btn btn-default btn-login">Login</button>
                  <span class="forgot-password-link text-shadow"> <a href="#">Forgot your password?</a> 
              </form>     
          </ul>        
        </div>
      </div>
    </nav><!-- end fixed nav-->
     <div class="row-welcome" style="background-image: url(https://coverfiles.alphacoders.com/348/34811.jpg); background-size: cover; background-position: center center;">
      <div class="row-body">
        <div class="welcome-inner">
          <!-- welcome message -->
          <div class="welcome-message">
            <div class="welcome-title">
              Welcome
            </div>
            <div class="welcome-desc">
              to our social network
            </div>
            <div class="welcome-about">
              share your memories, connect with others, make new friends.
            </div>                        
          </div><!-- end welcome message-->
          <!-- register and login form-->
          <div class="welcome-inputs">
            <div class="panel panel-success panel-inputs animated fadeInLeft panel-login">
              <div class="panel-heading">
                <h3 class="panel-title">Create New Account</h3>
              </div>
              <div class="panel-body">
                <form action="" method="POST" autocomplete="off" id="login">
                  <input type="text" id="username" required="" name="username" onblur="this.value=removeSpaces(this.value);" placeholder="Username">
                  <input type="password" id="password" name="password" placeholder="Password">
                  <input type="email" id="email" name="email" placeholder="Email">
                  <button type="submit" name="submit-button" class="btn btn-success">
                    <i class="fa fa-user-plus"></i>
                    + Signup
                  </button>
                </form> 
              </div>
            </div>          
             <?php echo $error; ?>
          </div><!-- end register and login form -->
        </div>
      </div>
    </div>

        <div class="welcome-full animated fadeInLeft">
      <div class="row-body">
        <!-- some registered users -->
        <div class="welcome-users-inner">
<?php $queryUsers=$db->query("SELECT * FROM users WHERE img!='avatar.png' order by rand() desc LIMIT 0,10 ");
                        $count=mysqli_num_rows($queryUsers);
                                  if ($count) {
                        while($dis = mysqli_fetch_assoc($queryUsers)) {
                          echo '<div class="welcome-user">
            <a href="'.$dis['username'].'">
              <img src="user_img/'.$dis['username'].'/'.$dis['img'].'" class="img-rounded" />
            </a>
          </div>'; }
        }
                          ?>
        </div> 
      </div>
    </div>
 <?php  include 'footer.php'; ?>
    <script src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <script src="assets/js/custom.js"></script>
        <script src="js/modernizr-2.0.6-min.js"></script>


     <script type="text/javascript">
       $(function(){
  $('#username').bind('input', function(){
    $(this).val(function(_, v){
     return v.replace(/\s+/g, '');
    });
  });
});
     </script>

     <script>
$(document).ready(function(){
    if(!Modernizr.input.placeholder) {
        $("input[placeholder]").each(function() {
            var placeholder = $(this).attr("placeholder");

            $(this).val(placeholder).focus(function() {
                if($(this).val() == placeholder) {
                    $(this).val("")
                }
            }).blur(function() {
                if($(this).val() == "") {
                    $(this).val(placeholder)
                }
            });
        });
    } // Modernizr placeholder
});
</script>

<script type="text/javascript">
function removeSpaces(string) {
 return string.split(' ').join('');
}
</script>
  </body>
</html>
