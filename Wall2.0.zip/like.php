<?php
include ('connection.php');
?>
<?php
$user_id=$_POST['userid'];
//Insert query
$post_id=$_POST['postid'];
	
$db->query("INSERT INTO likes
(postid,userid )
VALUES
(' $post_id ',' $user_id ')");   // if(!mysql_errno()){
//echo "Form Submitted Succesfully $friend_id / $user_id";


 ?>
