     <div id='content'>
     <div id="loader"></div>
<?php
//convert hashtags
function gethashtags($text)
{
  //Match the hashtags
  preg_match_all('/(^|[^a-z0-9_])#([a-z0-9_]+)/i', $text, $matchedHashtags);
  $hashtag = '';
  // For each hashtag, strip all characters but alpha numeric
  if(!empty($matchedHashtags[0])) {
    foreach($matchedHashtags[0] as $match) {
      $hashtag .= preg_replace("/[^a-z0-9]+/i", "", $match).',';
    }
  }
    //to remove last comma in a string
return rtrim($hashtag, ',');
}

//convert text to clickable links
function convert_clickable_links($message)
{
  $parsedMessage = preg_replace(array('/(?i)\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))/', '/(^|[^a-z0-9_])@([a-z0-9_]+)/i', '/(^|[^a-z0-9_])#([a-z0-9_]+)/i'), array('<a href="$1" target="_blank">$1</a>', '$1<a href="http://thewallclone.com/$2">@$2</a>',  '$1<a target="_blank" href="http://thewallclone.com/search.php?s=$2&searching=yes">#$2</a>'), $message);
  return $parsedMessage;
}




$query = $db->query("SELECT * FROM updates WHERE group_id_fk='$pid' ORDER BY update_id DESC");
    //Count total number of rows
    $rowCount = $query->num_rows;
 while($row=mysqli_fetch_array($query))
 {
$user_id=$row['user_id_fk'];
$message=$row['message'];
$id=$row['update_id'];
$timecreated=$row['created'];
$update_id_fk=$row['group_id_fk'];
$update_img=$row['img'];
$update_type=$row['type'];
  //get hashtag from message
$hashtag = gethashtags($message);

$sql_group= $db->query("SELECT * FROM groups WHERE group_id=$update_id_fk");
$owner=mysqli_fetch_array($sql_group);
$group_name=$owner['group_name'];
$owner_id=$owner['user_id_fk'];
$group_img=$owner['img'];


$sql_user= $db->query("SELECT img, username, uid FROM users WHERE uid=$user_id");
$ruser=mysqli_fetch_array($sql_user);
//$name=$ruser['name'];
$usernamepost=$ruser['username'];
$imgpost=$ruser['img'];
$groupowner=$ruser['uid'];
include_once("classes/agoTime_example.php"); // Include the class library
// ##############  Extracting Youtube cntent from post link ###########
?>
      <!-- first post-->
          <div class="panel panel-white post panel-shadow" id="<?php echo $id; ?>">
 <?php

if ($owner_id==$groupowner) 
{
 echo '  <div class="post-heading">
              <div class="pull-left image">
                <img src="groups/'.$group_name."/".$group_img.'" class="avatar" alt="user profile image">
              </div>
              <div class="pull-left meta">
                <div class="title h5">
                  <a href="" class="post-user-name">'.$group_name.'</a>';
                  ?>
                   <?php if ($update_type=='cover' AND $update_img==true)
                        {
                          echo "Updated her cover picture";
                        }
                        elseif ($update_type=='profile')
                        {
                            echo "Uploaded her profile picture";
                        }
                        elseif ($update_type=='timeline')
                        {
                            echo "Shared New picture";
                        }
                        elseif ($update_type=='local')
                        {
                            echo "Shared New picture";
                        }
                        else
                        {
                          echo "Shared a post";
                        }
                        
                        ?>
<?php
             echo '</div>
                <h6 class="text-muted time"><i class="fa fa-calendar"></i> '.time_passed($timecreated).'</h6>
              </div>
            </div>';
}
else
{
  echo '  <div class="post-heading">
              <div class="pull-left image">
                <img src="user_img/'.$usernamepost."/".$imgpost.'" class="avatar" alt="user profile image">
              </div>
              <div class="pull-left meta">
                <div class="title h5">
                  <a href="'.$usernamepost.'" class="post-user-name">'.$usernamepost.'</a>';
                  ?>
                    <?php if ($update_type=='cover' AND $update_img==true)
                        {
                          echo "Updated her cover picture";
                        }
                        elseif ($update_type=='profile')
                        {
                            echo "Uploaded a picture";
                        }
                        elseif ($update_type=='timeline')
                        {
                            echo "Shared New picture";
                        }
                        elseif ($update_type=='local')
                        {
                            echo "Shared New picture";
                        }
                        else
                        {
                          echo "Shared a post on >> <a href='#'>$group_name Wall</a>";
                        }
                        
                        ?>
<?php
             echo '</div>
                <h6 class="text-muted time"><i class="fa fa-calendar"></i> '.time_passed($timecreated).'</h6>
              </div>
            </div>';
}

 ?>

  <?php

                        if($update_type=='cover' AND !empty($update_img)) {
                          ?>
                       <div class="post-image">
                      <img src="<?php echo "groups/$group_name/$update_img"; ?>" class="image show-in-modal" alt="image post">
                      </div>
                      <?php
                        }
                        if($update_type=='profile' AND !empty($update_img)) {
                          ?>
                       <div class="post-image">
                      <img src="<?php echo "groups/$group_name/$update_img"; ?>" class="image show-in-modal" alt="image post">
                      </div>
                      <?php
                        }
                        if($update_type=='local' AND !empty($update_img)) {
                        ?>
                        <div class="post-image">
                      <img src="<?php echo "groups/$group_name/$update_img"; ?>" class="image show-in-modal" alt="image post">
                      </div>
                      <?php
                        }
                        ?>

          
            <div class="post-description">
              <p class="show-read-more"><?php echo convert_clickable_links($message); ?></p>
<?php
if(preg_match('~(?:https?://)?(?:www.)?(?:thewallclone.com|thescript.net16.net)/(?:group\?id=)?([^\s]+)~', $message, $match)){


$sql_check= $db->query("SELECT * FROM groups WHERE group_id='".($match[1])."'");
$groupinfo=mysqli_fetch_array($sql_check);
$group_nameinfo=$groupinfo['group_name'];
$group_info=$groupinfo['group_desc'];
$group_idinfo=$groupinfo['group_id'];
$owner_idinfo=$groupinfo['user_id_fk'];
$group_imginfo=$groupinfo['img'];
$group_coverinfo=$groupinfo['cover'];

if ($group_idinfo==$match[1]) {
$GroupLike=$db->query("SELECT U.username, U.uid, U.img
FROM
users U, group_users G
WHERE
U.uid=G.user_id_fk
AND
G.group_id_fk='$group_idinfo' ORDER BY G.group_user_id DESC");
 //Count total number of people am following
$CountGroupLike = mysqli_num_rows($GroupLike); // count of total friends like


$querycount = $db->query("SELECT * FROM updates WHERE group_id_fk='".($match[1])."' ");
    //Count total number of rows
    $tweetcount = $querycount->num_rows;

$postlikes= $db->query("SELECT * FROM group_users WHERE group_id_fk='".($match[1])."' AND status='1' ");
$liked=mysqli_fetch_array($postlikes);
$user_id_like_Post=$liked['user_id_fk'];

   echo '<a href="group.php?id='.($match[1]).'"><div class="box box-widget widget-user">';
  ?>

        <div class="widget-user-header" style="background-image: url(<?php echo "groups/$group_nameinfo/$group_coverinfo"; ?>); background-size:cover; position:relative; background-position:center ">
<?php
         echo '
         <h3 class="widget-user-username" style="color:red;">'.$group_nameinfo.' Group</h3>
        </div>
        <div class="widget-user-image">
          <img class="img-responsive" src="groups/'.$group_nameinfo."/".$group_imginfo.'" alt="User Avatar">
        </div></a>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-4 border-right">
              <div class="description-block">
                <h5 class="description-header"><i class="fa fa-rss"></i> '.$tweetcount.'</h5>
                <span class="description-text">TWEETS</span>
              </div>
            </div>
            <div class="col-sm-4 border-right">
              <div class="description-block">';
                ?>
                <?php
                if($CountGroupLike <=1)
                {

                  echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                  <span class="description-text">LIKE</span>';

                }
                else
                {
                   echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                   <span class="description-text">LIKES</span>';
                }
                ?>
                <?php
              echo '</div>
            </div>
            <div class="col-sm-4">
              <div class="description-block">';
              ?>
              <?php
                      if (@$user_id_like_Post==$session_uid) 
                      {
                        ?>
                       <h5 class="description-header">
                <a href="#"  id="<?php echo ($match[1]); ?>" class="unlikeGroupPost"><i class="fa fa-times"></i> UNLIKE</a>
                </h5>
                      <?php
                      }
                      else
                      {
                        ?>
                 <h5 class="description-header">
                <a href="#"  id="<?php echo ($match[1]); ?>" class="likeGroupPost"><i class="fa fa-heart"></i> LIKE GROUP</a>
                </h5>
                      <?php
                      }
                      ?>
                <?php
                echo '<p class="sponsor-name alert-success"><i class="fa fa-check"></i> Sponsored Group</p>
              </div>
            </div>
            <p style="word-wrap: break-word;">'.convert_clickable_links($group_info).'</p>
          </div>
        </div>
      </div>
';
}
else
{
  echo '
              <div class="description-block">
                <h5 class="description-header alert-danger"><i class="fa fa-info-circle"></i> THIS GROUP DOES NOT EXIST</h5>
                <br/>
                <a href="createpage.php" class="alert alert-success"><i class="fa fa-check"></i> CREATE NEW GROUP</a>
              </div>
            ';
}
}

if(preg_match('~(?:https?://)?(?:www.)?(?:youtube.com|youtu.be)/(?:watch\?v=)?([^\s]+)~', $message, $match)){
echo "<br><iframe width='600' src='http://www.youtube.com/embed/".$match[1]."' frameborder='0' class='video' allowfullscreen></iframe><br>\n";
//print Youtube ID: ($match[1]);
}

if(preg_match("/(https?:\/\/)?(www.)?(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/", $message, $output_array)) {
echo "<br>";

echo '<br><iframe width="600" src="//player.vimeo.com/video/'.$output_array[5].'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" class="video"></iframe>';

    //echo "Vimeo ID: $output_array[5]";
    }
?>


 <?php 
 $querycomment = $db->query("SELECT * FROM group_comments WHERE id_post='$id' ORDER BY id ASC LIMIT 0,8");
//Count total number of rows for comment
$countComment= $querycomment->num_rows;


$querylikes = $db->query("SELECT * FROM grouplikes WHERE postid='$update_id_fk'");
    //Count total number of rows
    $rowCountCommentlikes = $querylikes->num_rows;
    $row=mysqli_fetch_array($querylikes);
    {
      $user_idlike=$row['userid'];
      $postidlike=$row['postid'];
    }
    ?> 

              <div class="stats">
<div class="feed" id="feed<?php echo $id; ?>">
<div class="heart" id="like<?php echo $id; ?>" rel="like">
<div class="likeCount" id="likeCount<?php echo $id; ?>"><?php echo $rowCountCommentlikes; ?></div>
</div> 

                <a href="#" class="stat-item">
                  <i class="fa fa-retweet icon">
                  </i>
                  <?php echo number_format($countComment); ?>
                </a>
                <a href="#" class="stat-item">
                  <i class="fa fa-comments-o icon">
                  </i>
                  <?php echo number_format($countComment); ?>
                </a>

</div>
              </div>
            </div>

<!-- *********************************************************************
            Comment box
   *********************************************************************** -->
            <div class="post-footer">
<ul class="comments-list" id="comments-list<?php echo $id; ?>">
 
<?php  
 while($rowcomment=mysqli_fetch_array($querycomment)){

$uid=$rowcomment['uid'];
$comment=$rowcomment['comment'];
$commentid=$rowcomment['id'];
$commentTimeCreated=$rowcomment['created'];
$id_post=$rowcomment['id_post'];
//select from users table
$sql_user= $db->query("SELECT img, username,time FROM users WHERE uid='$uid'");
$ruser=mysqli_fetch_array($sql_user);
//$name=$ruser['name'];
$usernamecomment=$ruser['username'];
$imgcomment=$ruser['img'];


$querylikes = $db->query("SELECT * FROM commentlikes WHERE postid='$commentid'");
    //Count total number of rows
    $rowCountCommentlikes = $querylikes->num_rows;
    $row=mysqli_fetch_array($querylikes);
    {
      $user_idlike=$row['userid'];
      $postidlike=$row['postid'];
    }
?>
<div >
               <li class="comment panel-success">
                  <a class="pull-left" href="#">
                    <img class="avatar" src="user_img/<?php echo $usernamecomment.'/'.$imgcomment; ?>" alt="avatar">
                  </a>
                  <div class="comment-body">
                    <div class="comment-heading">
                      <h4 class="comment-user-name">
                        <a href="#"><?php echo $usernamecomment; ?></a>
                      </h4>
                      <h5 class="time"><?php echo time_passed($commentTimeCreated); ?></h5>
                    </div>
                    <p><?php echo convert_clickable_links($comment); ?></p>
                    <?php
                    if(preg_match('~(?:https?://)?(?:www.)?(?:thescript.net16.net|thescript.net16.net)/(?:group.php\?id=)?([^\s]+)~', $comment, $match1)){


$sql_check= $db->query("SELECT * FROM groups WHERE group_id='".($match1[1])."'");
$groupinfo=mysqli_fetch_array($sql_check);
$group_nameinfo=$groupinfo['group_name'];
$group_info=$groupinfo['group_desc'];
$group_idinfo=$groupinfo['group_id'];
$owner_idinfo=$groupinfo['user_id_fk'];
$group_imginfo=$groupinfo['img'];
$group_coverinfo=$groupinfo['cover'];

if ($group_idinfo==$match1[1]) {
$GroupLike=$db->query("SELECT U.username, U.uid, U.img
FROM
users U, group_users G
WHERE
U.uid=G.user_id_fk
AND
G.group_id_fk='$group_idinfo' ORDER BY G.group_user_id DESC");
 //Count total number of people am following
$CountGroupLike = mysqli_num_rows($GroupLike); // count of total friends like

$querycount = $db->query("SELECT * FROM updates WHERE group_id_fk='".($match1[1])."' ");
    //Count total number of rows
    $tweetcount = $querycount->num_rows;

$postlike= $db->query("SELECT * FROM group_users WHERE group_id_fk='".($match1[1])."' AND status='1' ");
while($liked=mysqli_fetch_array($postlike))
{
$user_id_like_Post=$liked['user_id_fk'];
}

   echo '<a href="group.php?id='.($match1[1]).'"><div class="box box-widget widget-user">';
  ?>

        <div class="" style="background-image: url(<?php echo "groups/$group_nameinfo/$group_coverinfo"; ?>); background-size:cover; position:relative; background-position:center ">
<?php
         echo '
         <h3 class="widget-user-username" style="color:red;">'.$group_nameinfo.' Group</h3>
        </div>
        <div class="widget-user-image">
          <img class="img-responsive" src="groups/'.$group_nameinfo."/".$group_imginfo.'" alt="User Avatar">
        </div></a>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-4 border-right">
              <div class="description-block">
                <h5 class="description-header"><i class="fa fa-rss"></i> '.$tweetcount.'</h5>
                <span class="description-text">TWEETS</span>
              </div>
            </div>
            <div class="col-sm-4 border-right">
              <div class="description-block">';
                ?>
                <?php
                if($CountGroupLike <=1)
                {

                  echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                  <span class="description-text">LIKE</span>';

                }
                else
                {
                   echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                   <span class="description-text">LIKES</span>';
                }
                ?>
                <?php
              echo '</div>
            </div>
            <div class="col-sm-4">
              <div class="description-block">';
              ?>
              <?php
              echo "<h5 class='groupstd' id='($match1[1])'>";
                      if (@$user_id_like_Post==$session_uid) 
                      {
                        ?>
                       <h5 class="description-header" id="unlike<?php echo ($match1[1]); ?>">
                <a href="#"  id="<?php echo ($match1[1]); ?>" class="unlikeGroupPost"><i class="fa fa-times"></i> UNLIKE</a>
                </h5>


                      <?php
                      }
                      else
                      {
                        ?>
                 <h5 class="description-header" id="like<?php echo ($match1[1]); ?>">
                <a href="group.php?id=<?php echo ($match1[1]); ?>"  id="<?php echo ($match1[1]); ?>"><i class="fa fa-link"></i> Click Here</a>
                </h5>

                      <?php
                      }
                      ?>
                <?php
                echo '<p class="sponsor-name alert-success"><i class="fa fa-check"></i> Sponsored Group</p>
              </div>
            </div>
            <p style="word-wrap: break-word; padding:9px;">'.convert_clickable_links($group_info).'</p>
          </div>
        </div>
      </div>
';
}
else
{
  echo '
              <div class="description-block">
                <h5 class="description-header alert-danger"><i class="fa fa-info-circle"></i> THIS GROUP DOES NOT EXIST</h5>
                <br/>
                <a href="createpage.php" class="alert alert-success"><i class="fa fa-check"></i> CREATE NEW GROUP</a>
              </div>
            ';
}
}
?>
                  </div>

<div class="stats" align="left">
<div class="feed" id="feed<?php echo $commentid; ?>">
<div class="heart" id="like<?php echo $commentid; ?>" rel="like">
<div class="likeCount" id="likeCount<?php echo $commentid; ?>"><?php echo $rowCountCommentlikes; ?></div>
</div> 

</div>
              </div>
              <br/>
                </li>
                </div>
                <?php } ?>
                </ul>              
             

<!-- *********************************************************************
          End  Comment box
   *********************************************************************** -->

              <div class="panel-footer">
              <div id="cflash<?php echo $id; ?>"></div>
              
 <form action="" method="post" name="<?php echo $id; ?>">
<input  value="" placeholder="Say something..." name="comment" class="form-control"  id="comment<?php echo $id; ?>" type="text" autocomplete="off" />
<input  value="<?php echo $id; ?>" type="hidden" name="postid" />
<br/>
<button type="submit" value="Comment" class="comment_submit btn btn-success" id="<?php echo $id; ?>" /><span class="fa fa-send"></span></button> 
</form>
 
<!-- *********************************************************************
           End Comment form
   *********************************************************************** -->
             </div>
                  
            </div>
          </div>
          <!-- first post-->
        <?php } ?>
        </div>
    
