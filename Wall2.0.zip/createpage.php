<?php include 'session.php'; ?>
<?php include 'connection.php'; ?>
<?php
include ('group-setup.php');
$session_uid=$_SESSION['uid'];
?>
<?php 
$query_profile= $db->query("select * from users where uid='$session_uid' AND 1=1");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_email=$user_data['email'];
  $profile_background=$user_data['profile_background'];
  $user_img=$user_data['img'];
  $profile_background_position=$user_data['profile_background_position'];


$sqlheadline=$db->query("select * from user_bio where uid='$session_uid'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$phone=$row['phone'];
$address=$row['address'];
$site=$row['site'];
$country=$row['country'];
$state=$row['state'];
$lessons=$row['lessons'];
$linked=$row['linkedIn'];
$info=$row['about'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Wall Script Social Network: Create Group : Codexpress Labs</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
.error{
                margin-bottom: 40px;
                background: red;
                padding: 5px;
                color: white;
            }

#imagePreview{
    width: 100px;
    height: 100px;
    margin-left: 5px;
    background-position: center center;
    background-size: cover;
    -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
    display: inline-block;
}
            .alert{
                margin-bottom: 40px;
                background: #ebf8a4;
                padding: 5px;
                color: black;
            }
.timelineUploadBG {
              position: absolute;
              margin-top: 60px;
              margin-right: 813px;
              height: 32px;
              width: 30px;
              left: 140px;
              top: 100px;
            }

            .uploadFile {
            background: url('images/whitecam.png') no-repeat;
            height: 32px;
            width: 30px;
            overflow: hidden;
            cursor: pointer;
            }
            .uploadFile input {
            filter: alpha(opacity=0);
            opacity: 0;
            margin-right: -110px;
            }

            .custom-file-input {
            height: 25px;
            cursor: pointer;
            }
            .left {
        position: absolute;
              margin-top: 250px;
              margin-right: 813px;
              height: 32px;
              left: 75px;
              top: 115px;
}
</style>
  </head>
  <body class="animated fadeIn">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <a class="navbar-brand" href="home.php">
            <b>The Wall Script 2.0
            </b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <div class="col-md-5 col-sm-4">         
            <form class="navbar-form" action="search.php" method="get">
              <div class="form-group" style="display:inline;">
                <div class="input-group" style="display:table;">
                  <input class="form-control" name="s" placeholder="Hit Enter Search Users, Groups..." autocomplete="off" type="text">
                  <input type="hidden" name="searching" value="yes" />
                  <span class="input-group-addon" style="width:1%;">
                    <span class="fa fa-search"></span>
                  </span>
                </div>
              </div>
            </form>
          </div>        
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="home.php">
                <i class="fa fa-bars">
                </i>&nbsp;Home
              </a>
            </li>
            <li>
              <a href="messages.php">
                <i class="fa fa-envelope">
                </i>
              </a>
            </li>
            <li>
              <a href="notifications.php">
                <i class="fa fa-globe">
                </i>
              </a>
            </li>
            <li>
              <a href="edit-profile.php">
                <i class="fa fa-cogs">
                </i>
              </a>
            </li>
            <li>
              <a href="#" class="nav-controller">
                <i class="fa fa-users">
                </i>
              </a>
            </li>
            <li>
              <a href="logout.php" class="nav-controller">
                <i class="fa fa-sign-out">
                </i> Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Timeline content -->
    <div class="container container-timeline" style="margin-top:100px;">
    	<div class="col-md-10 no-paddin-xs">
			<!-- left content-->
    		<div class="col-md-10 col-md-offset-2 no-paddin-xs">

				<form id="myGroup" action="" method="post" enctype="multipart/form-data">
			    <!-- update cover and profile image-->
					<div class="panel panel-white post panel-shadow">
					  <div class="post-heading">
					      <div class="pull-left image">
					          <div class="avatar" style="background-image: url(<?php echo "images/warning.png"; ?>);" id="imagePreview"></div>

                    <div class="uploadFile timelineUpload">
                      <input id="uploadFile" type="file" required name="photoimg" class=" custom-file-input" original-title="Change Cover Picture">
                      </div>

					      </div>
					  </div>
            <textarea name="info" id="info" required="" class="form-control input-lg p-text-area" rows="2" placeholder="Short Description of group" maxlength="200" minlength="10"></textarea>
					</div><!-- end update cover and profile image-->
			    <!-- update info -->
					<div class="panel panel-white post panel-shadow">
					  <div class="panel-body">

   <ul class="nav nav-tabs" role="tablist">
      <li class="active"><a href="#tab1" role="tab" data-toggle="tab"><span class="fa fa-child"></span>Group Info</a></li>
 </ul>

<?php echo "$success"; ?>
 <div class="tab-content">
      <div class="tab-pane active" id="tab1">

            <div class="form-group">
                <label class="col-md-3 control-label">Group Username</label>
                <div class="col-md-8">
                  <input class="form-control" id="username"  placeholder="userame of Group e.g TheWall" required="" name="name" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Tags</label>
                <div class="col-md-8">
                  <input class="form-control" value="" name="tag" type="text">
                </div>
              </div>  
              </div>
               </div>
               </div>
              </div><!-- end update info-->

					<div class="panel panel-white post-load-more panel-shadow text-center">
						<button class="btn btn-success" name="btn_create" type="submit" id="update">
							Create Group
						</button>
					</div>				
				</form>
    		</div><!-- end left content--> 
    	</div>
    </div>

    <!-- Online users sidebar content-->
<?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs">
          <a href="#" class="hide-chat btn btn-success btn-sm">Hide
          </a>
        </p> 
        <p class="text-center chat-title">Online users</p>  
<?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>


        
      </div>
    </div><!-- Online users sidebar content-->
    
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>
    <script src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
     <script src="js/jquery.form.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
            // bind 'myForm' and provide a simple callback function
            $('#msg').hide();// hide input for image upload after ajax call
            var username=$('#username').val();
            var uploadFile=$('#uploadFile').val();
            var info=$('#info').val();
            
            $('#myUpdate').ajaxForm(function() {                
               $('#msg').slideDown().fadeOut(7000);
              $('#update').text("Create Group"); // after form submision set button to default text Update

            });

            // if user click update button, please change update text to updating
            $('#update').click(function(){
            $('#update').text("Please wait...");
        });
       
             });
    </script>



    <script type="text/javascript">
$(function() {
    $("#uploadFile").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function(){ // set image data as background of div
                $("#imagePreview").css("background-image", "url("+this.result+")");
            }
        }
    });
});
</script>

<script type="text/javascript">
       $(function(){
  $('#username').bind('input', function(){
    $(this).val(function(_, v){
     return v.replace(/\s+/g, '');
    });
  });
});
     </script>

  </body>
</html>
