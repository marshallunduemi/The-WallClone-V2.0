<?php include 'session.php'; ?>
<?php include 'connection.php'; ?>
<?php
$session_uid=$_SESSION['uid'];
if (isset($_POST['comment']) AND !empty($_POST['comment']))
 {
//convert hashtags
function gethashtags($text)
{
  //Match the hashtags
  preg_match_all('/(^|[^a-z0-9_])#([a-z0-9_]+)/i', $text, $matchedHashtags);
  $hashtag = '';
  // For each hashtag, strip all characters but alpha numeric
  if(!empty($matchedHashtags[0])) {
    foreach($matchedHashtags[0] as $match) {
      $hashtag .= preg_replace("/[^a-z0-9]+/i", "", $match).',';
    }
  }
    //to remove last comma in a string
return rtrim($hashtag, ',');
}

//convert text to clickable links
function convert_clickable_links($message)
{
  $parsedMessage = preg_replace(array('/(?i)\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))/', '/(^|[^a-z0-9_])@([a-z0-9_]+)/i', '/(^|[^a-z0-9_])#([a-z0-9_]+)/i'), array('<a href="$1" target="_blank">$1</a>', '$1<a href="http://thewallclone.com/$2">@$2</a>',  '$1<a target="_blank" href="http://thewallclone.com/search.php?s=$2&searching=yes">#$2</a>'), $message);
  return $parsedMessage;
}
$commentval=htmlentities($_POST['comment']);
$postid=htmlentities($_POST['postid']);
$emaila=htmlentities($_REQUEST['email']);
$cmusername=htmlentities($_POST['name']);
//$photo=htmlentities($_POST['photoimg']);
$uid=$_SESSION['uid'];
//$username=$_SESSION['username'];
$time=time();


 $db->query("INSERT INTO comments (uid, comment, id_post, created)VALUES( '$uid', '$commentval', '$postid', '$time')");

  $sql_user= $db->query("SELECT img,email, username,time FROM users WHERE uid='$uid'");
$ruser=mysqli_fetch_array($sql_user);
//$name=$ruser['name'];
$usernamecomment=$ruser['username'];
$imgcomment=$ruser['img'];
$uemail=$ruser['email'];

// PHP MAILER SETTING  
$to = $emaila;

 $subject = "TheWallclone Comment Notification";
 $body = "Hello <b>$cmusername</b>, <a href='thewallclone.com/$usernamecomment'>$usernamecomment</a> commented on your post  at
  <a href='www.thewallclone.com'>The Wall  Clone</a> \r\n - $commentval - \r\n <a href='www.thewallclone.com'>click to reply</a> \r\n \r\n \r\n
  <a href='http://www.codexpresslabs.info/2016/05/wall-clone-social-network-script-20.html'>More About Wall Clone Social Network Script 2.0</a> | <a href='www.thewallclone.com/marshallunduemi'>Wall Clone Social Network Script 2.0 By Marshall unduemi</a>";

$header = "From: noreply@thewallclone.com \r\n";
 $header .= "Cc:$email \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
  $sent=mail($to,$subject,$body,$header);
  
         if( $sent) {
           // echo "Message sent successfully...";
         }else {
           // echo "Message could not be sent...";
         }
//
}
?>

                <li class="comment">
                  <a class="pull-left" href="<?php echo $usernamecomment; ?>">
                    <img class="avatar" src="user_img/<?php echo $usernamecomment.'/'.$imgcomment; ?>" alt="avatar">
                  </a>
                  <div class="comment-body">
                    <div class="comment-heading">
                      <h4 class="comment-user-name">
                        <a href="<?php echo $usernamecomment; ?>"><?php echo $usernamecomment; ?></a>
                      </h4>
                      <h5 class="time"><?php echo date("s"); ?> sec ago</h5>
                    </div>
                    <p><?php echo convert_clickable_links($commentval); ?></p>
                   <?php
                    if(preg_match('~(?:https?://)?(?:www.)?(?:thewallclone.com|thescript.net16.net)/(?:group\?id=)?([^\s]+)~', $message, $match)){


$sql_check= $db->query("SELECT * FROM groups WHERE group_id='".($match1[1])."'");
$groupinfo=mysqli_fetch_array($sql_check);
$group_nameinfo=$groupinfo['group_name'];
$group_info=$groupinfo['group_desc'];
$group_idinfo=$groupinfo['group_id'];
$owner_idinfo=$groupinfo['user_id_fk'];
$group_imginfo=$groupinfo['img'];
$group_coverinfo=$groupinfo['cover'];

if ($group_idinfo==$match1[1]) {
$GroupLike=$db->query("SELECT U.username, U.uid, U.img
FROM
users U, group_users G
WHERE
U.uid=G.user_id_fk
AND
G.group_id_fk='$group_idinfo' ORDER BY G.group_user_id DESC");
 //Count total number of people am following
$CountGroupLike = mysqli_num_rows($GroupLike); // count of total friends like

$querycount = $db->query("SELECT * FROM updates WHERE group_id_fk='".($match1[1])."' ");
    //Count total number of rows
    $tweetcount = $querycount->num_rows;

$postlike= $db->query("SELECT * FROM group_users WHERE group_id_fk='".($match1[1])."' AND status='1' ");
while($liked=mysqli_fetch_array($postlike))
{
$user_id_like_Post=$liked['user_id_fk'];
}

   echo '<a href="group.php?id='.($match1[1]).'"><div class="box box-widget widget-user">';
  ?>

        <div class="" style="background-image: url(<?php echo "groups/$group_nameinfo/$group_coverinfo"; ?>); background-size:cover; position:relative; background-position:center ">
<?php
         echo '
         <h3 class="widget-user-username" style="color:red;">'.$group_nameinfo.' Group</h3>
        </div>
        <div class="widget-user-image">
          <img class="img-responsive" src="groups/'.$group_nameinfo."/".$group_imginfo.'" alt="User Avatar">
        </div></a>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-4 border-right">
              <div class="description-block">
                <h5 class="description-header"><i class="fa fa-rss"></i> '.$tweetcount.'</h5>
                <span class="description-text">TWEETS</span>
              </div>
            </div>
            <div class="col-sm-4 border-right">
              <div class="description-block">';
                ?>
                <?php
                if($CountGroupLike <=1)
                {

                  echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                  <span class="description-text">LIKE</span>';

                }
                else
                {
                   echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                   <span class="description-text">LIKES</span>';
                }
                ?>
                <?php
              echo '</div>
            </div>
            <div class="col-sm-4">
              <div class="description-block">';
              ?>
              <?php
              echo "<h5 class='groupstd' id='($match1[1])'>";
                      if (@$user_id_like_Post==$session_uid) 
                      {
                        ?>
                       <h5 class="description-header" id="unlike<?php echo ($match1[1]); ?>">
                <a href="#"  id="<?php echo ($match1[1]); ?>" class="unlikeGroupPost"><i class="fa fa-times"></i> UNLIKE</a>
                </h5>


                      <?php
                      }
                      else
                      {
                        ?>
                 <h5 class="description-header" id="like<?php echo ($match1[1]); ?>">
                <a href="group.php?id=<?php echo ($match1[1]); ?>"  id="<?php echo ($match1[1]); ?>"><i class="fa fa-link"></i> Click Here</a>
                </h5>

                </h5>

                      <?php
                      }
                      ?>
                <?php
                echo '<p class="sponsor-name alert-success"><i class="fa fa-check"></i> Sponsored Group</p>
              </div>
            </div>
            <p style="word-wrap: break-word; padding:9px;">'.convert_clickable_links($group_info).'</p>
          </div>
        </div>
      </div>
';
}
else
{
  echo '
              <div class="description-block">
                <h5 class="description-header alert-danger"><i class="fa fa-info-circle"></i> THIS GROUP DOES NOT EXIST</h5>
                <br/>
                <a href="createpage.php" class="alert alert-success"><i class="fa fa-check"></i> CREATE NEW GROUP</a>
              </div>
            ';
}
}

if(preg_match('~(?:https?://)?(?:www.)?(?:youtube.com|youtu.be)/(?:watch\?v=)?([^\s]+)~', $commentval, $match)){
echo "<br><iframe width='600' src='http://www.youtube.com/embed/".$match[1]."' frameborder='0' class='video' allowfullscreen></iframe><br>\n";
//print Youtube ID: ($match1[1]);
}

if(preg_match("/(https?:\/\/)?(www.)?(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/", $commentval, $output_array)) {
echo "<br>";

echo '<br><iframe width="600" src="//player.vimeo.com/video/'.$output_array[5].'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" class="video"></iframe>';

    //echo "Vimeo ID: $output_array[5]";
    }

                    ?>
                  </div>
                </li>
                <div class="stats" align="left">
<div class="feed" id="feed<?php echo $commentid; ?>">
<div class="heart" id="like<?php echo $commentid; ?>" rel="like">
<div class="likeCount" id="likeCount<?php echo $commentid; ?>">0</div>
</div> 

</div>
              </div>
              <br/>
             