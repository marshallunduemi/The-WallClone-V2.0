<?php include 'session.php'; ?>
<?php include 'connection.php'; ?>
<?php
$session_uid=$_SESSION['uid'];
if (isset($_POST['comment']) AND !empty($_POST['comment']))
 {
//convert hashtags
function gethashtags($text)
{
  //Match the hashtags
  preg_match_all('/(^|[^a-z0-9_])#([a-z0-9_]+)/i', $text, $matchedHashtags);
  $hashtag = '';
  // For each hashtag, strip all characters but alpha numeric
  if(!empty($matchedHashtags[0])) {
    foreach($matchedHashtags[0] as $match) {
      $hashtag .= preg_replace("/[^a-z0-9]+/i", "", $match).',';
    }
  }
    //to remove last comma in a string
return rtrim($hashtag, ',');
}

//convert text to clickable links
function convert_clickable_links($message)
{
  $parsedMessage = preg_replace(array('/(?i)\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))/', '/(^|[^a-z0-9_])@([a-z0-9_]+)/i', '/(^|[^a-z0-9_])#([a-z0-9_]+)/i'), array('<a href="$1" target="_blank">$1</a>', '$1<a href="">@$2</a>', '$1<a href="http://thescript.net16.net/search.php?s=$2&searching=yes">#$2</a>'), $message);
  return $parsedMessage;
}

$commentval=htmlentities($_POST['comment']);
$postid=htmlentities($_POST['postid']);
//$photo=htmlentities($_POST['photoimg']);
$uid=$_SESSION['uid'];
//$username=$_SESSION['username'];
$time=time();

    
   $db->query("INSERT INTO group_comments (uid, comment, id_post, created)VALUES( '$uid', '$commentval', '$postid', '$time')");

  $sql_user= $db->query("SELECT img, username,time FROM users WHERE uid='$uid'");
$ruser=mysqli_fetch_array($sql_user);
//$name=$ruser['name'];
$usernamecomment=$ruser['username'];
$imgcomment=$ruser['img'];
}
?>

                <li class="comment">
                  <a class="pull-left" href="profile.php">
                    <img class="avatar" src="user_img/<?php echo $usernamecomment.'/'.$imgcomment; ?>" alt="avatar">
                  </a>
                  <div class="comment-body">
                    <div class="comment-heading">
                      <h4 class="comment-user-name">
                        <a href="profile.php"><?php echo $usernamecomment; ?></a>
                      </h4>
                      <h5 class="time">Just now</h5>
                    </div>
                    <p><?php echo convert_clickable_links($commentval); ?></p>
                   <?php
                    if(preg_match('~(?:https?://)?(?:www.)?(?:thewallclone.com|thescript.net16.net)/(?:group\?id=)?([^\s]+)~', $commentval, $match1)){


$sql_check= $db->query("SELECT * FROM groups WHERE group_id='".($match1[1])."'");
$groupinfo=mysqli_fetch_array($sql_check);
$group_nameinfo=$groupinfo['group_name'];
$group_info=$groupinfo['group_desc'];
$group_idinfo=$groupinfo['group_id'];
$owner_idinfo=$groupinfo['user_id_fk'];
$group_imginfo=$groupinfo['img'];
$group_coverinfo=$groupinfo['cover'];

if ($group_idinfo==$match1[1]) {
$GroupLike=$db->query("SELECT U.username, U.uid, U.img
FROM
users U, group_users G
WHERE
U.uid=G.user_id_fk
AND
G.group_id_fk='$group_idinfo' ORDER BY G.group_user_id DESC");
 //Count total number of people am following
$CountGroupLike = mysqli_num_rows($GroupLike); // count of total friends like

$querycount = $db->query("SELECT * FROM updates WHERE group_id_fk='".($match1[1])."' ");
    //Count total number of rows
    $tweetcount = $querycount->num_rows;

$postlike= $db->query("SELECT * FROM group_users WHERE group_id_fk='".($match1[1])."' AND status='1' ");
while($liked=mysqli_fetch_array($postlike))
{
$user_id_like_Post=$liked['user_id_fk'];
}

   echo '<a href="group.php?id='.($match1[1]).'"><div class="box box-widget widget-user">';
  ?>

        <div class="" style="background-image: url(<?php echo "groups/$group_nameinfo/$group_coverinfo"; ?>); background-size:cover; position:relative; background-position:center ">
<?php
         echo '
         <h3 class="widget-user-username" style="color:red;">'.$group_nameinfo.' Group</h3>
        </div>
        <div class="widget-user-image">
          <img class="img-responsive" src="groups/'.$group_nameinfo."/".$group_imginfo.'" alt="User Avatar">
        </div></a>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-4 border-right">
              <div class="description-block">
                <h5 class="description-header"><i class="fa fa-rss"></i> '.$tweetcount.'</h5>
                <span class="description-text">TWEETS</span>
              </div>
            </div>
            <div class="col-sm-4 border-right">
              <div class="description-block">';
                ?>
                <?php
                if($CountGroupLike <=1)
                {

                  echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                  <span class="description-text">LIKE</span>';

                }
                else
                {
                   echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                   <span class="description-text">LIKES</span>';
                }
                ?>
                <?php
              echo '</div>
            </div>
            <div class="col-sm-4">
              <div class="description-block">';
              ?>
              <?php
              echo "<h5 class='groupstd' id='($match1[1])'>";
                      if (@$user_id_like_Post==$session_uid) 
                      {
                        ?>
                       <h5 class="description-header" id="unlike<?php echo ($match1[1]); ?>">
                <a href="#"  id="<?php echo ($match1[1]); ?>" class="unlikeGroupPost"><i class="fa fa-times"></i> UNLIKE</a>
                </h5>


                      <?php
                      }
                      else
                      {
                        ?>
                 <h5 class="description-header" id="like<?php echo ($match1[1]); ?>">
                <a href="group.php?id=<?php echo ($match1[1]); ?>"  id="<?php echo ($match1[1]); ?>"><i class="fa fa-link"></i> Click Here</a>
                </h5>

                </h5>

                      <?php
                      }
                      ?>
                <?php
                echo '<p class="sponsor-name alert-success"><i class="fa fa-check"></i> Sponsored Group</p>
              </div>
            </div>
            <p style="word-wrap: break-word; padding:9px;">'.convert_clickable_links($group_info).'</p>
          </div>
        </div>
      </div>
';
}
else
{
  echo '
              <div class="description-block">
                <h5 class="description-header alert-danger"><i class="fa fa-info-circle"></i> THIS GROUP DOES NOT EXIST</h5>
                <br/>
                <a href="createpage.php" class="alert alert-success"><i class="fa fa-check"></i> CREATE NEW GROUP</a>
              </div>
            ';
}
}


                    ?>
                  </div>
                </li>
                <div class="stats" align="left">
<div class="feed" id="feed<?php echo $commentid; ?>">
<div class="heart" id="like<?php echo $commentid; ?>" rel="like">
<div class="likeCount" id="likeCount<?php echo $commentid; ?>">0</div>
</div> 

</div>
              </div>
              <br/>
             


