<?php
include 'config/config.php';
include 'scripts/Oaut.php';

if(isset($_POST["btn_update"])) 
{

  if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
    {

    	$name=htmlentities($_POST['name']);
    	$work=htmlentities($_POST['work']);
    	$day=htmlentities($_POST['day']);
        $month=htmlentities($_POST['month']);
        $yr=htmlentities($_POST['yr']);
    	$phone=htmlentities($_POST['phone']);
    	$site=htmlentities($_POST['site']);
    	$address=htmlentities($_POST['address']);
    	$country=htmlentities($_POST['country']);
    	$state=htmlentities($_POST['state']);
    	$fb=htmlentities($_POST['fb']);
    	$tw=htmlentities($_POST['tw']);
    	$gplus=htmlentities($_POST['gplus']);
    	$lessons=htmlentities($_POST['lessons']);
        $sex=htmlentities($_POST['sex']);

$action=$db->query("UPDATE user_bio SET address='$address', country='$country', state='$state', lessons='$lessons', day='$day', month='$month', yr='$yr', phone='$phone', name='$name', sex='$sex',  fb='$fb', gplus='$gplus', headline='$work', tw='$tw', site='$site' WHERE uid='$_SESSION[uid]'");


    }

}
