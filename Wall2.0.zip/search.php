<?php include 'session.php'; ?>
<?php include 'connection.php'; ?>
<?php
include_once("classes/agoTime_example.php"); // Include the class library

$session_uid=$_SESSION['uid'];
$query_profile= $db->query("select * from users where uid=$session_uid AND 1=1");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_img=$user_data['img'];
  $status=$user_data['status'];
  $ago=$user_data['ago'];

$folder1=$_SESSION['username'];

$sqlheadline=$db->query("select * from user_bio where uid='$session_uid'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$phone=$row['phone'];
$address=$row['address'];
$site=$row['site'];
$country=$row['country'];
$state=$row['state'];
$lessons=$row['lessons'];
$linked=$row['linkedIn'];
$dob=$row['dob'];
$info=$row['about'];
$useruid=$row['uid'];

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Wall Script Social Network : Search : Codexpress Labs </title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="animated fadeIn">

           <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <a class="navbar-brand" href="home.php">
            <b>The Wall Script 2.0
            </b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <div class="col-md-5 col-sm-4">         
            <form class="navbar-form" action="search.php" method="get">
              <div class="form-group" style="display:inline;">
                <div class="input-group" style="display:table;">
                  <input class="form-control" name="s" placeholder="Hit Enter Search Users, Groups..." autocomplete="off" type="text">
                  <input type="hidden" name="searching" value="yes" />
                  <span class="input-group-addon" style="width:1%;">
                    <span class="fa fa-search"></span>
                  </span>
                </div>
              </div>
            </form>
          </div>        
          <ul class="nav navbar-nav navbar-right">
              <li>
              <a href="profile.php">
                <img src="user_img/<?php echo "$folder1/$g_img"; ?>" class="img-nav">
              </a>
            </li>
            <li  class="active">
              <a href="home.php">
                <i class="fa fa-bars">
                </i>&nbsp;Home
              </a>
            </li>
            <li>
              <a href="messages.php">
                <i class="fa fa-envelope">
                </i>
              </a>
            </li>
            <li>
              <a href="notifications.php">
                <i class="fa fa-globe">
                </i>
              </a>
            </li>
            <li>
              <a href="edit-profile.php">
                <i class="fa fa-cogs">
                </i>
              </a>
            </li>
            <li>
              <a href="#" class="nav-controller">
                <i class="fa fa-users">
                </i>
              </a>
            </li>
            <li>
              <a href="logout.php" class="nav-controller">
                <i class="fa fa-sign-out">
                </i> Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

<!-- Timeline content -->
    <div class="container container-timeline" style="margin-top:70px;">
      <div class="col-md-10 no-paddin-xs">
        <div class="col-md-5 no-paddin-xs">
          <div class="panel panel-white">
            <div class="panel-heading">
              <h3 class="panel-title">Welcome to Wall Script
              </h3>
            </div>
            
            <div class="panel-body">
              <img src="user_img/<?php echo $folder1.'/'.$g_img; ?>" class="home-avatar img-thumbnail" alt="user profile image">
              <a href="profile.php">@ <?php echo ucfirst($username); ?> </a><br/>
              Connection Status 
              <a href="profile.php"><i class="fa fa-check-circle connected-status"></i> </a>
              <?php
                 if ($status==1) 
                 {
                  echo '<h5 class="text-white text-center alert-success"> Online '.time_passed($ago).'</h5>';
                 }
                 else
                 {
                  echo '<h5 class="text-white text-center alert-danger"> Offline '.time_passed($ago).'</h5>';
                 }

                  ?>
               
            </div>
          </div>
                      <div class="panel panel-default panel-user-detail">
            <div class="panel-body">
              <ul class="list-unstyled">
                <li><i class="fa fa-suitcase"></i> Works at <a href="#"><?php echo $info;?></a></li>
                <li><i class="fa fa-calendar"></i> Born on <?php echo $dob;?></li>

<?php

$queryFollowing=$db->query("SELECT F.status, U.username,U.img,U.uid, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
END

AND
F.status='1'");
 //Count total number of people am following
$rowCountFollowing = mysqli_num_rows($queryFollowing); // count of total friends


$queryFollowers=$db->query("SELECT F.status, U.username,U.img,U.uid, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = U.uid
THEN F.friend_two = '$_SESSION[uid]'
END

AND
F.status='1'");
 //Count total number of people am following
$rowCountFollowers = mysqli_num_rows($queryFollowers); // count of total friends

?>

                <li><i class="fa fa-rss"></i> Followed by 
                <a href="home.php"><?php 
                if($rowCountFollowers <=1)
                {
                  echo "$rowCountFollowers Person";
                }
                else
                {
                  echo "$rowCountFollowers People";
                }
                ?>
                 </a>
                 </a></li>
                 <li><i class="fa fa-rss"></i> Following 
                <a href="home.php"><?php if($rowCountFollowing <=1)
                {
                  echo "$rowCountFollowing Person";
                }
                else
                {
                  echo "$rowCountFollowing People";
                }
                ?>
                 </a></li>
                 <li><i class="fa fa-globe"></i> Visit
                 <?php if(!empty($site))
                {
                  echo '<a href="'.$site.'">'.$site.'</a>';
                }
                ?>
                </li>
                
                 <?php 
                if(empty($name))
                {
              echo '<li><i class="fa fa-info"></i>
              <a href="edit-profile.php" class="alert alert-warning"> You are awesome, but You\'r not complete</a></li>';
                }
                ?>
                
              </ul>
            </div>
            </div>
         
          <!-- suggested groups -->
          <div class="panel panel-white panel-groups">
            <div class="panel-heading">
              <h3 class="panel-title">Suggested Groups
              </h3>
            </div>
            <div class="panel-body">
              <ul class="list-group">
                <?php
$querygroup= $db->query("select * from groups");
  while($pages=mysqli_fetch_array($querygroup))
  {
  $groupName=$pages['group_name'];
  $groupImage=$pages['img'];
  $GroupId=$pages['group_id'];


  echo '<li class="list-group-item">
                  <div class="col-xs-3 col-sm-6 col-md-3">
                      <img src="groups/'.$groupName.'/'.$groupImage.'" alt="Group" class="img-responsive" />
                  </div>
                  <div class="col-xs-9 col-sm-6">
                      <a href="group.php?id='.$GroupId.'"><span class="name">'.$groupName.'</span></a>
                  </div>
                  <div class="clearfix"></div>
                </li>
';
  }
?>  
              </ul>
            </div>
          </div>
          <!--End suggested groups -->  
          <!-- People You May Know -->
          <div class="panel panel-white">
            <div class="panel-heading">
              <h3 class="panel-title">People You May Know
              </h3>
            </div>
            <div class="panel-body">

              
              <!-- *********************************************************************
   Purpose      : to determin if the logged in user is folloeing any user else
                  display follow button or following button to current user
   Returns      : True or false

                                  START HERE
   *********************************************************************** -->
                <?php
                $friendsall=$db->query("SELECT * FROM users ORDER BY rand() LIMIT 0,8");

                while ($data=mysqli_fetch_array($friendsall)) {
                  //$name=$data['name'];
                  $img=$data['img'];
                  $username=$data['username'];
                  $userid=$data['uid'];
                if ($userid==$session_uid) {
                  # code...
                  echo ' <div class="notification-row">
                <div class="notification-padding">
                  <div class="sidebar-fa-image img-may-know">
                    <img class="notifications" src="user_img/'.$username.'/'.$img.'">
                  </div>
                  <div class="sidebar-fa-text">
                    <b>
                      <a href="'.$username.'">'.$username.'</a>
                    </b>
                    <br>
                    <a class="btn btn-warning btn-sm" href="">
                      <i class="fa fa-user"> You
                      </i>
                    </a>
                  </div>
                </div>
              </div>';
                }else{
//
                  echo ' <div class="notification-row">
                <div class="notification-padding">
                  <div class="sidebar-fa-image img-may-know">
                    <img class="notifications" src="user_img/'.$username.'/'.$img.'">
                  </div>
                  <div class="sidebar-fa-text">
                    <b>
                      <a href="'.$username.'">'.$username.'</a>
                    </b>';

                 // Display people you may know
                $result12=$db->query("SELECT F.status,F.friend_one,F.friend_two, U.username,U.img,U.uid, U.email
                FROM users U, friends F
                WHERE
                CASE

                WHEN F.friend_one = '$userid'
                THEN F.friend_two = U.uid
                WHEN F.friend_two= '$userid'
                THEN F.friend_one= U.uid
                END");

                $rrow=mysqli_fetch_array($result12);
                  $friend1=$rrow['friend_one'];
                  $friend2=$rrow['friend_two'];
                  $status=$rrow['status'];
                if ($friend2==$session_uid OR $friend1==$session_uid AND $status=='1')
                {
                  // Display follow button if not you
                  echo '
                  <br>
                    <a class="btn btn-danger btn-sm" href="'.$username.'" id="'.$userid.'">
                      <i class="fa fa-play-circle"> Following
                      </i>
                    </a>
                  </div>
                </div>
              </div>';
                            // end form here
                }else {

                  // Display follow button if not you
                  echo '<p id="follow'.$userid.'">
                  <br>
                    <a class="btn btn-success btn-sm follow" href="#" id="'.$userid.'">
                      <i class="fa fa-user-plus"> Follow
                      </i>
                    </a>
                  </div>
                </div>
              </div></p>';
                            // end form here
                          }

                }
                }
                ?>
<!-- *********************************************************************
   Purpose      : to determin if the logged in user is folloeing any user else
                  display follow button or following button to current user
   Returns      : True or false

                                  END HERE
   *********************************************************************** -->
					
            </div>
          </div>
          <!-- End people yout may know -->
        </div>
        <!-- end left content -->

			<!-- notification list-->
    		<div class="col-md-7 no-paddin-xs">
    		<div class="panel panel-white post panel-shadow">
					  <div class="panel-body">

   <ul class="nav nav-tabs" role="tablist">
      <li class="active"><a href="#tab1" role="tab" data-toggle="tab"><span class="fa fa-child"></span> People</a></li>
      <li><a href="#tab2" role="tab" data-toggle="tab"><span class="fa fa-group"></span> Groups</a></li>
 </ul>
 </div>
 </div>
  <div class="tab-content">
      <div class="tab-pane active" id="tab1">


<?php  //This is only displayed if they have submitted the form 
$searching=$_REQUEST['searching'];
$find=$_REQUEST['s'];
$field="username";

if ($searching =="yes") 
 {  //If they did not enter a search term we give them an error  
 if ($find == "")  {  echo "<p class=\"errorlog\"><img src=\"img/x.png\" width=\"15px\"> You forgot to enter a search term";  exit;  }   
 /// We preform a bit of filtering  
 $find = strtoupper($find);  $find = strip_tags($find);  $find = trim ($find);   
 //Now we search for our search term, in the field the user specified  
 $data = $db->query("SELECT * FROM users WHERE upper($field) LIKE'%$find%'");
 $anymatches=mysqli_num_rows($data);   
 //And we display the results  
 while($result = mysqli_fetch_array( $data )) 
  {  
  	$username=$result['username'];
  	$searchuid=$result['uid'];
  	$image=$result['img'];

$sqlheadline=$db->query("select * from user_bio where uid='$searchuid'");
$row=mysqli_fetch_array($sqlheadline);
$country=$row['country'];
$state=$row['state'];

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$searchuid'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$searchuid'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


 echo  '<div class="panel panel-white post panel-shadow">
				  <div class="post-heading">
				      <div class="pull-left image">
				          <img src="user_img/'.$username.'/'.$image.'" class="avatar" alt="'.$username.'">
				      </div>
				      <div class="pull-left meta">
				          <div class="title h5">
				              <a href="'.$username.'" class="post-user-name">@ '.$username.'</a>
				          </div>';
				          ?>
				          <?php
				          if ($friendsList<=1) {

				          echo '<h6 class="text-muted time"><i class="fa fa-user"></i>
				          '.number_format($friendsList).' Friend</h6>';
				          }
				          else
				          {
				          echo '<h6 class="text-muted time"><i class="fa fa-users"></i> '.number_format($friendsList).' Friends</h6>';
				          }

				          echo '<h6 class="text-muted time"><i class="fa fa-map-marker"></i> '.$country.' '.$state.'</h6>';
				          ?>
				          <?php
				      echo '</div>
				  </div>
				</div>'; 
 }   //This counts the number or results - and if there wasn't any it gives them a little message explaining that  
  if ($anymatches == 0)  
  	{  
  		echo "<p class=\"alert alert-danger\"><img src=\"img/x.png\" width=\"15px\"> Sorry, but we can not find an entry to match your query<br><br>";
  		 } 
 }  ?>
				

</div>



     <div class="tab-pane" id="tab2">

				
<?php  //This is only displayed if they have submitted the form 
$searching=$_REQUEST['searching'];
$find=$_REQUEST['s'];
$field="group_name";

if ($searching =="yes") 
 {  //If they did not enter a search term we give them an error  
 if ($find == "")  {  echo "<p class=\"errorlog\"><img src=\"img/x.png\" width=\"15px\"> You forgot to enter a search term";  exit;  }   
 /// We preform a bit of filtering  
 $find = strtoupper($find);  $find = strip_tags($find);  $find = trim ($find);   
 //Now we search for our search term, in the field the user specified  
 $data = $db->query("SELECT * FROM groups WHERE upper($field) LIKE'%$find%'");
 $anymatches=mysqli_num_rows($data);   
 //And we display the results  
 while($result = mysqli_fetch_array( $data )) 
  {  
  	$group_name=$result['group_name'];
  	$group_id=$result['group_id'];
  	$group_image=$result['img'];

 $querygroup= $db->query("select * from group_users where group_id_fk='$group_id' AND 1=1");
 $pages=mysqli_fetch_array($querygroup);
 $groupmatches=mysqli_num_rows($querygroup);  

 $query = $db->query("SELECT * FROM updates WHERE group_id_fk='$group_id'");
    //Count total number of rows
    $rowCount = $query->num_rows;
 



 echo  '<div class="panel panel-white post panel-shadow">
				  <div class="post-heading">
				      <div class="pull-left image">
				          <img src="groups/'.$group_name.'/'.$group_image.'" class="avatar" alt="'.$group_name.'">
				      </div>
				      <div class="pull-left meta">
				          <div class="title h5">
				              <a href="group.php?id='.$group_id.'" class="post-user-name">'.$group_name.' Group</a>
				          </div>';
				          ?>
				          <?php
				          if ($groupmatches<=1) {

				          echo '<h6 class="text-muted time"><i class="fa fa-heart alert-success"></i>
				          '.number_format($groupmatches).' LIKE</h6>';
				          }
				          else
				          {
				          echo '<h6 class="text-muted time"><i class="fa fa-heart alert-success"></i> '.number_format($groupmatches).' LIKES</h6>';
				          }
				          echo '<h6 class="text-muted time"><i class="fa fa-share-square-o"></i> '.number_format($rowCount ).' TWEET</h6>';


				          ?>
				          <?php
				      echo '</div>
				  </div>
				</div>'; 
 }   //This counts the number or results - and if there wasn't any it gives them a little message explaining that  
  if ($anymatches == 0)  
  	{  
  		echo "<p class=\"alert alert-danger\"><img src=\"img/x.png\" width=\"15px\"> Sorry, but we can not find an entry to match your query<br><br>";
  		 } 
 }  ?>
				


</div>
</div>

				

				<div class="panel panel-white post-load-more panel-shadow text-center">
					<button class="btn btn-success">
						<i class="fa fa-refresh"></i>Load More...
					</button>
				</div>				
    		</div><!-- notification list-->
    	</div>
    </div>
<?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs">
          <a href="#" class="hide-chat btn btn-success btn-sm">Hide
          </a>
        </p> 
        <p class="text-center chat-title">Online users</p>  
<?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>


        
      </div>
    </div>
    
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>
        <script src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>

<script type="text/javascript">
$(document).ready(function(){
//Initialize the DOM
$(".follow").click(function(){

var element = $(this);
var usertoken = element.attr("id");
  //alert(usertoken);
  $(this).removeClass();
    $(this).addClass("btn btn-danger following");
    $(this).text("Following");

var dataString = 'friend='+usertoken+'&user_id='+<?php echo $session_uid; ?>;
                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "ajax/respond-request.php",
                    data: dataString,
                    cache: false,

                  });
return false;

});

});
</script>
  </body>
</html>
