<?php
$alert="";
// is the email valid?
if (isset($_POST['submit-button'])) {
if(empty($_POST['username']) || empty($_POST['password']) || empty($_POST['email']))
{
    $error="<script> alert('Enter all the fields');</script>";
}
else
{
// is the email valid?
if(!preg_match("/^[\.A-z0-9_\-\+]+[@][A-z0-9_\-]+([.][A-z0-9_\-]+)+[A-z]{1,4}$/", $_POST['email']))
{
     $error="<script> alert('Error: You haven't provided a valid email');</script>";
}else
{

// Here you must put your code for validating and escaping all the input data,
// inserting new records in your DB and echo-ing a message of the type:
    // Define $username and $password
            $username=$_POST['username'];
            $pass=$_POST['password'];
            $email=$_POST['email'];

            // To protect from MySQL injection
            $username = stripslashes($username);
            $pass = stripslashes($pass);
            $email = stripslashes($email);
            $username = mysqli_real_escape_string($db, $username);
            $pass = mysqli_real_escape_string($db, $pass);
            $email = mysqli_real_escape_string($db, $email);
            $pass = md5($pass);




$query = $db->query("SELECT * FROM `users` WHERE `username` = '$username' OR `email` = '$email'");
$count = mysqli_num_rows($query);
    $rows = mysqli_fetch_assoc($query);
    $dbemail=$rows['email'];
    $usernamedb=$rows['username'];
 if ($dbemail==$email) 
 {
     # code...
   $error="<script> alert('Email unavaliable. try use another email address!');</script>";
 }
 // end checking email ...
 else
 {
    if ($username==$usernamedb) 
 {
     # code...
   $error="<script> alert('username unavaliable.');</script>";
 }else
 {


 $path="user_img/".$username."";
mkdir($path, 0777);



$source = "img/avatar.png";
$dest = 'user_img/'.$username.'/avatar.png';
copy($source, $dest);
//unlink($source);

function gen_random_string($length=5)
{
   $chars ='1234567890abcdefghijklmnopqrstuvwsyz';//length:28
    $final_rand='';
    for($i=0;$i<$length; $i++)
    {
        $final_rand .= $chars[ rand(1,strlen($chars)-1)];
 
    }
    return $final_rand;
}
 $key=gen_random_string(10); //generates a string with length 4


$db->query("INSERT INTO users (username, password, email, img)
    VALUES('$username', '$pass','$email', 'avatar.png')");

    session_start();
    include("connection.php"); //Establishing connection with our database
    
        //Check username and password from database
            $sql="SELECT uid, username FROM users WHERE username='$username' and password='$pass'";
            $result=mysqli_query($db,$sql);
            $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
            $uid=$row['uid'];
            
            //If username and password exist in our database then create a session.
            //Otherwise echo error.
            
            if(mysqli_num_rows($result) == 1)
            {
                $_SESSION['username'] = $username; // Initializing Session
                $_SESSION['uid'] = $uid; // Initializing Session

                header("location: profile.php"); // Redirecting To Other Page
            }
//$error="<script> alert('Successfully registered');</script>";


 }
 //
}
 }
}  
                }//submit-button
?>
