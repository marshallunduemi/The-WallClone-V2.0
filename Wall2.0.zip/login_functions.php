<?php
function cleanInput($text)
{
	//strip tags
	$text = strip_tags($text);
	$text = trim($text);
	return $text;
}

function Is_email($user)
{
	//If the username input string is an e-mail, return true
	if(filter_var($user, FILTER_VALIDATE_EMAIL)) {
		return true;
	} else {
		return false;
	}
}
