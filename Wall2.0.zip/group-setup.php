<?php
$success="";
if(isset($_POST["btn_create"])) 
{

if(!empty($_POST['name']) || !empty($_POST['info']))
{

    	$pname=stripcslashes($_POST['name']);
    	$tag=htmlentities($_POST['tag']);
    	$uid=$_SESSION['uid'];
    	$info=htmlentities($_POST['info']);

$setid= $db->query("SELECT * FROM groups WHERE group_name='$pname'");
$check=mysqli_num_rows($setid);

if ($check==1) {
 $success='<div class="alert alert-danger" id="msg">Group name taken, ! try something new</div>';
}
else
{

$path="groups/".$pname."/";
mkdir($path, 0777);

    $valid_formats = array("jpg","jpeg", "JPG", "png", "PNG", "gif", "bmp");

            $name = $_FILES['photoimg']['name'];
            $size = $_FILES['photoimg']['size'];
            
            if(strlen($name))
                {
                    list($txt, $ext) = explode(".", $name);
                    if(in_array($ext,$valid_formats))
                    {
                    if($size<(1024*1024))
                        {
                            $image = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
                            $tmp = $_FILES['photoimg']['tmp_name'];
                            if(move_uploaded_file($tmp, $path.$image))
                                {

$db->query("INSERT INTO groups (group_name,group_desc,user_id_fk,img, created)
 VALUES ('$pname', '$info', '$uid', '$image', NOW())");
  
   $success='<div class="alert alert-success" id="msg">Group Successful Created</div>';
                }
              else

                $success='<div class="error">failed to Upload! </div>';     
            }
            else
              $success='<div class="error">Image file size must not exceed 1MB!</div>';        
            }
            else
               $success='<div class="error">Invalid file format!</div>';
        }
        
      else
       $success='<div class="error">Please select image to upload</div>';   
        
 
    }
}
}