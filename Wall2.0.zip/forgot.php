  <?php
  // include db configuration
  require_once "config/config.php";
  ?>

  <!DOCTYPE html>
  <html lang="en">
     <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="images/favicon.ico">
        <title>THE WALL SCRIPT SOCIAL NETWORK : PASSWORD RESET</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/login/css/animate.min.css" rel="stylesheet">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet">
        <link href="assets/login/css/timeline.css" rel="stylesheet">

  <link rel="stylesheet" type="text/css" href="css/style.css" />
        <!--[if lt IE 9]> <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
     </head>
     <body class="welcome-page animated fadeIn">
        <nav class="navbar navbar-default navbar-fixed-top navbar-principal welcome-nav">
           <div class="container">
              <div class="navbar-header">
                 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                     <a class="navbar-brand" href="#">
                        <img src="images/logo.png" class="img-logo"> <b>THE WALL SCRIPT</b>
                      </a>
                    </div>
              <!-- <div id="navbar" class="collapse navbar-collapse"> <ul class="nav navbar-nav navbar-right">
               <li><a href="profile.html"><i class="fa fa-user fa-2x"></i>Profile</a></li><li><a href="home.html"><i class="fa fa-home fa-2x"></i>Home</a></li></ul> </div>-->
           </div>
        </nav>
        <div class="row-welcome" style="background-image: url('images/pass.png'); background-size: 1400px; margin-top: 20px;">
           <div class="row-body">
              <div class="welcome-inner">
                 <!-- <div class="welcome-message welcome-text-shadow">
                    <div class="welcome-title"> Welcome </div>
                    <div class="welcome-desc"> To WALLSCRIPT VERSION 1.0 Build Your Own Social network </div>
                    <div class="welcome-about"> share your memories, connect with others, make new friends. </div>
                 </div>-->
                 <div class="welcome-inputs animated fadeInLeft">

                 <h1>FORGET PASSWORD ?</h1>
    <?php
  if(isset($_POST['forget_pass'])){
$email = $_POST['email']; //Storing email in $username variable.
$username = $_POST['username']; //Storing email in $username variable.

$match = $db->query("SELECT * FROM users WHERE username ='$username'"); 
$mysql_num_rows = mysqli_num_rows($match);
if(mysqli_num_rows($match)!=0)
{ 
while($row=mysqli_fetch_assoc($match))
{
    $db_email = $row['email'];
}
if($email==$db_email)
{
  $code = rand(10000,1000000);
  $to = $db_email;
  $subject = "Wall Script. Password Reset Link";
  $body = "Hello $to.  This is an automatic mail please don't reply to this message.
  Click the link below to reset your password  or copy to your browser
  http://www.undwebservices.com/forget.php?code=$code&username=$username&email=$db_email ". "\r\n" ."
  Rgards: Marshall Unduemi J
  
  ";
  $db->query("UPDATE users SET passreset ='$code' WHERE username = '$username'");
  mail($to,$subject,$body);
  echo "<i style='color:#F00'>Email Sent to you, check your inbox</i><br>";
}else
{
  echo "<i style='background-color:#CFF;'>Email address does not match with this username try again</i>";
}
}else
{
 echo "<i style='background-color:#CFF;'>Incorrect Username try again</i>"; 
}
}

     if(@$_GET['code'])
     {
     $get_username = $_GET['username'];
     $get_code = $_GET['code'];
     @$emailme = $_GET['email'];
     $query = $db->query("SELECT * FROM users WHERE username ='$get_username'");
     while($data = mysqli_fetch_assoc($query))
     {
     $db_code = $data['passreset'];
     $db_username = $data['username'];  
     }
     if($get_username == $db_username & $get_code == $db_code)
     {
       echo "
       <form action='reset_password.php?code=$get_code&email=$emailme' method='post' class='login'>
    <input type='password' name='newpass' required='required' class='post-footer'/><br>
     <input type='password' name='newpass1' required='required' class='topic'/>
                      <input type='hidden' name='username' value='$db_username'/><br>
      <input type='submit' value='Update Password!' class='topic'>
    </p>
      </form>
       
       ";
     }else
     {
    echo "Invalid verification code <a href='forg0t.php'>click here to go back </a><br><br><br>";   
     }
     }
     if(!@$_GET['code'])
     {
     echo '
        <form action="?" method="POST" autocomplete="off" id="login">
        <input type="text" id="username" required name="username" onblur="this.value=removeSpaces(this.value);" placeholder="Username">
      <input type="email" id="email" name="email" placeholder="Email">

      <input type="submit" value="Submit" name="forget_pass" class="btn btn-success">
    </p>
      </form>';
    
     }

?>
                 </div>
              </div>
           </div>
        </div>
        <div class="welcome-full">
           <div class="row-body">
              <div class="welcome-users-inner animated fadeInRight">

              </div>
           </div>
        </div>
        <footer class="welcome-footer">
           <div class="container">
              <p>
              <div class="footer-links"> <a href="http://codexpresslabs.info/">Website</a> | <a href="#">Privacy Policy</a> | <a href="http://facebook.com/marshallunduemi">Developer</a> | <a href="http://codexpresslabs.info/p/contact-me.html">Contact</a> | <a href="http://codexpresslabs.info/p/about-me.html">About</a> | <a href="http://codexpresslabs.info/p/about-me.html">Download</a>  </div>
              Copyright &copy; Codexpress labs- All rights reserved </p>
           </div>
        </footer>
     </body>
        <script src="assets/js/jquery.1.11.1.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/custom.js"></script>
        <script src="js/modernizr-2.0.6-min.js"></script>


     <script type="text/javascript">
       $(function(){
  $('#username').bind('input', function(){
    $(this).val(function(_, v){
     return v.replace(/\s+/g, '');
    });
  });
});
     </script>

     <script>
$(document).ready(function(){
    if(!Modernizr.input.placeholder) {
        $("input[placeholder]").each(function() {
            var placeholder = $(this).attr("placeholder");

            $(this).val(placeholder).focus(function() {
                if($(this).val() == placeholder) {
                    $(this).val("")
                }
            }).blur(function() {
                if($(this).val() == "") {
                    $(this).val(placeholder)
                }
            });
        });
    } // Modernizr placeholder
});
</script>

<script type="text/javascript">
function removeSpaces(string) {
 return string.split(' ').join('');
}
</script>
  </html>
