<?php include 'session.php'; ?>
<?php include 'connection.php'; ?>
<?php
$session_uid=$_SESSION['uid'];
?>
<?php 
$query_profile= $db->query("select * from users where uid='$session_uid' AND 1=1");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_email=$user_data['email'];
  $profile_background=$user_data['profile_background'];
  $user_img=$user_data['img'];
  $profile_background_position=$user_data['profile_background_position'];


$sqlheadline=$db->query("select * from user_bio where uid='$session_uid'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$phone=$row['phone'];
$address=$row['address'];
$site=$row['site'];
$country=$row['country'];
$state=$row['state'];
$lessons=$row['lessons'];
$linked=$row['linkedIn'];
$dob=$row['dob'];
$info=$row['about'];



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Wall Script Social Network: Friends : Codexpress Labs</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">
    <script src="js/jquery.1.11.1.min.js">
    </script>
    <script src="js/bootstrap.min.js">
    </script>
    <script src="js/custom.js">
    </script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">

#imagePreview{
    width: 150px;
    height: 150px;
    margin-left: 80px;
    background-position: center center;
    background-size: cover;
    -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
    display: inline-block;
}
            .alert{
                margin-bottom: 40px;
                background: #ebf8a4;
                padding: 5px;
                color: black;
            }
    </style>
  </head>
  <body class="animated fadeIn">

  <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <a class="navbar-brand" href="home.php">
            <b>The Wall Script 2.0
            </b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <div class="col-md-5 col-sm-4">         
            <form class="navbar-form" action="search.php" method="get">
              <div class="form-group" style="display:inline;">
                <div class="input-group" style="display:table;">
                  <input class="form-control" name="s" placeholder="Hit Enter Search Users, Groups..." autocomplete="off" type="text">
                  <input type="hidden" name="searching" value="yes" />
                  <span class="input-group-addon" style="width:1%;">
                    <span class="fa fa-search"></span>
                  </span>
                </div>
              </div>
            </form>
          </div>        
          <ul class="nav navbar-nav navbar-right">
            <li>
              <a href="home.php">
                <i class="fa fa-bars">
                </i>&nbsp;Home
              </a>
            </li>
            <li>
              <a href="messages.php">
                <i class="fa fa-envelope">
                </i> Message
              </a>
            </li>
            <li>
              <a href="notifications.php">
                <i class="fa fa-globe">
                </i> Notification
              </a>
            </li>
            <li>
              <a href="#" class="nav-controller">
                <i class="fa fa-user">
                </i> Users
              </a>
            </li>
            <li>
              <a href="logout.php" class="nav-controller">
                <i class="fa fa-sign-out">
                </i> Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Timeline content -->
    <div class="container container-timeline">
      <!-- cover content -->
      <div class="row">
        <div class="col-md-10 no-paddin-xs">
          <!-- cover and profile image-->
          <div class="col-md-12 col-sm-12 col-xs-12 cover-content">
            <div class="cover-container" style="background-image: url(<?php echo "user_img/$username/$profile_background"; ?>);">
              <div class="social-cover"></div>
              <div class="social-desc">
                 <div class="desc-content">
                    <h1 class="fg-white text-shadow"><?php echo "$country $state"; ?></h1>
                <h5 class="fg-white text-shadow">- <?php echo date('M d, Y'); ?></h5>
                    <div style="margin-top:50px;"></div>
                 </div>
              </div>
              <div class="social-avatar" >
              <div class="img-avatar" style="background-image: url(<?php echo "user_img/$username/$user_img"; ?>);" id="imagePreview"></div>
                 <h4 class="fg-white text-center text-shadow">
             <?php echo "$name @ $username";?></h4>
             <h5 class="fg-white text-center" style="opacity:0.8;"><?php echo $info;?></h5>
                 <hr class="border-black75 text-shadow" style="border-width:2px;" >
                 <div class="text-center">
                  <a href="edit-profile.php" class="btn btn-inverse btn-outlined btn-retainBg btn-brightblue"><span>Edit Profile</span> </a>
                 </div>
              </div>
            </div>
          </div><!-- end cover and profile image-->
          <!-- cover menu -->
          <div class="col-md-12  col-sm-12 col-xs-12">
            <div class="panel-options">
              <div class="navbar navbar-default navbar-cover">
                <div class="container-fluid">
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#profile-opts-navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                    </button>
                  </div>

                  <div class="collapse navbar-collapse" id="profile-opts-navbar">
                    <ul class="nav navbar-nav navbar-right">
                      <li><a href="profile.php"><i class="fa fa-tasks"></i>Timeline</a></li>
                      <li><a href="<?php echo "$username"; ?>"><i class="fa fa-info-circle"></i>About</a></li>
                      <li class="active"><a href="friends.php"><i class="fa fa-users"></i>Friends</a></li>
                      <li><a href="photos.php"><i class="fa fa-file-image-o"></i>Photos</a></li>
                      <li><a href="messages.php"><i class="fa fa-comment"></i>Messages</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- cover menu -->
        </div>
      </div><!-- cover content -->
      <div class="row">
        <div class="col-md-10 no-paddin-xs">
          <div class="col-md-12">
            <!-- panel friends -->
            <div class="panel panel-white panel-list-friends">
              <div class="panel-heading">
                <h3 class="panel-title">Friends</h3>
              </div>
              <div class="panel-body">

                 <?php
// Friends List Data relations between users and friends tables for displaying user friends
include_once("classes/agoTime_example.php"); // Include the class library
$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status,U.ago, U.email,U.profile_background
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND 
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends

while($fdata=mysqli_fetch_array($flist))
{
  $dbusername=$fdata['username'];
  $dbuid=$fdata['uid'];
  $dbimg=$fdata['img'];
  $status=$fdata['status'];
  $ago=$fdata['ago'];
  $dbprofile_background=$fdata['profile_background'];


echo '<div class="col-md-4">
                  <div class="g-hover-card">
                    <img src="user_img/'.$dbusername.'/'.$dbprofile_background.'" alt="">
                    <div class="user-avatar">
                      <img src="user_img/'.$dbusername.'/'.$dbimg.'" alt="'.$dbusername.'">
                    </div>
                    <div class="info">
                      <div class="title">
                        <a href="'.$dbusername.'">'.$dbusername.'</a>
                      </div>
                    </div>
                    <div class="bottom">
                      <a href="'.$dbusername.'" class="btn btn-info btn-xs">
                        <i class="fa fa-check-circle"></i>
                      </a>
                      <a href="messages.php?token='.$dbuid.'" class="btn btn-primary btn-xs">
                        <i class="fa fa-envelope"></i></a>';
                        ?>
                        <?php
                 if ($status==1) 
                 {
                  echo '<h5 class="text-white text-center alert-success"> Online '.time_passed($ago).'</h5>';
                 }
                 else
                 {
                  echo '<h5 class="text-white text-center alert-danger"> Offline '.time_passed($ago).'</h5>';
                 }

                  ?>
                  <?php
                  echo '</div>
                  </div>
                </div>';


}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>



                  </div>
                </div>
                <div class="col-md-12 panel-white post-load-more panel-shadow text-center">
                  <button class="btn btn-success">
                    <i class="fa fa-refresh"></i>Load More...
                  </button>
                </div>
              </div>
            </div><!-- end panel friends -->
          </div>
        </div>        
      </div>
    </div>

   <?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs">
          <a href="#" class="hide-chat btn btn-success btn-sm">Hide
          </a>
        </p> 
        <p class="text-center chat-title">Online users</p>  
<?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>


        
      </div>
    </div>
    <!-- Online users sidebar content-->
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>
  </body>
</html>
