
<?php include 'connection.php'; ?>
<?php
$folder1=$_SESSION['username'];
$session_uid=$_SESSION['uid'];

$query_me= $db->query("SELECT * FROM users WHERE uid='$session_uid'");
  $me=mysqli_fetch_array($query_me);
  $g_img=$me['img'];


   if(isset($_GET['user']))
  {
  $user=$_GET['user'];
$query_profile= $db->query("SELECT * FROM users  WHERE username='$user' AND 1=1");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $email=$user_data['email'];
  $status=$user_data['status'];
  $ago=$user_data['ago'];
  $profile_background=$user_data['profile_background'];
  $user_img=$user_data['img'];
  $profile_background_position=$user_data['profile_background_position'];

$sqlheadline=$db->query("select * from user_bio where uid='$friend_id'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$phone=$row['phone'];
$address=$row['address'];
$site=$row['site'];
$country=$row['country'];
$state=$row['state'];
$lessons=$row['lessons'];
$linked=$row['linkedIn'];
$dob=$row['dob'];
$info=$row['about'];
$day=$row['day'];
$month=$row['month'];
$yr=$row['yr'];
$useruid=$row['uid'];
include_once("classes/agoTime_example.php"); // Include the class library
}

  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Wall Script Social Network: About : Codexpress Labs</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">
    <script src="js/jquery.1.11.1.min.js">
    </script>
    <script src="js/bootstrap.min.js">
    </script>
    <script src="js/custom.js">
    </script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
       <style type="text/css">

#imagePreview{
    width: 150px;
    height: 150px;
    margin-left: 80px;
    background-position: center center;
    background-size: cover;
    -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
    display: inline-block;
}
            .alert{
                margin-bottom: 40px;
                background: #ebf8a4;
                padding: 5px;
                color: black;
            }
    </style>
  </head>
  <body class="animated fadeIn">

    <!-- Fixed navbar -->
      <?php include ('navbar.php'); ?>
    </nav>

    <!-- Timeline content -->
    <div class="container">
      <!-- cover content -->
      <div class="row">
        <div class="col-md-10 no-paddin-xs">
          <!-- cover and profile image-->
          <div class="col-md-12 col-sm-12 col-xs-12 cover-content">
            <div class="cover-container" style="background-image: url(<?php echo "user_img/$username/$profile_background"; ?>);">
              <div class="social-cover"></div>
              <div class="social-desc">
                 <div class="desc-content">
                    <h1 class="fg-white text-shadow"><?php echo "$country $state"; ?></h1>
                <h5 class="fg-white text-shadow">- <?php echo date('M d, Y'); ?></h5>
                    <div style="margin-top:50px;"></div>
                 </div>
              </div>
              <div class="social-avatar" >
                <div class="img-avatar" style="background-image: url(<?php echo "user_img/$username/$user_img"; ?>);" id="imagePreview"></div>
                 <h4 class="text-white text-center" style="color: white;"><?php echo "$name @ $username";?></h4>
                 <?php
                 echo '<h5 class="text-white text-center alert-success">Status</h5>';
                 

                  ?>
                  
                 <hr class="border-black75 text-shadow" style="border-width:2px;" >
                 <div class="text-center">
                 <?php
                 if ($session_uid==$friend_id) {
                   echo '<a href="messages.php" role="button" class="btn btn-inverse btn-outlined btn-retainBg btn-brightblue"><span class="fa fa-envelope"> Messages</span></a>';
                 }
                 else
                  echo '<a href="messages.php?token='.$friend_id.'" role="button" class="btn btn-inverse btn-outlined btn-retainBg btn-brightblue"><span class="fa fa-envelope"> PM Me</span></a>';
                 ?>
                  
                 </div>
              </div>
            </div>
          </div><!-- end cover and profile image-->
          <!-- cover menu -->
          <div class="col-md-12  col-sm-12 col-xs-12">
            <div class="panel-options">
              <div class="navbar navbar-default navbar-cover">
                <div class="container-fluid">
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#profile-opts-navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                    </button>
                  </div>
    <?php
// Friends List Data relations between users and friends tables for displaying user friends

$fcheck=$db->query("SELECT *
FROM friends
WHERE friend_one = '$session_uid' AND friend_two = '$friend_id' AND status='1'");
$friendcheck=mysqli_num_rows($fcheck); // count of total friends
?>
                  <div class="collapse navbar-collapse" id="profile-opts-navbar">
                    <ul class="nav navbar-nav navbar-right">
                      <li><a href="profile.php"><i class="fa fa-tasks"></i>Timeline</a></li>
                      <li class="active"><a href="<?php echo "$username";?>"><i class="fa fa-info-circle"></i>About</a></li>
                      <li><a href="friends.php"><i class="fa fa-users"></i>Friends</a></li>
                      <li><a href="photos.php"><i class="fa fa-file-image-o"></i>Photos</a></li>
                      <li><a href="messages.php"><i class="fa fa-comment"></i>Messages</a></li>
                      <?php   
                      if ($friendcheck==1) {
                       echo '<li><a href="'.$username.'" class="alert-warning">
                        <i class="fa fa-play"></i> Following</a></li>';
                      }
                      else
                      {
                        echo '<li><a href="#" class="alert-success follow" id="'.$friend_id.'">
                        <i class="fa fa-plus"></i> Follow</a></li>';
                      }
                      ?>
                     
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- cover menu -->
        </div>
      </div><!-- cover content -->
      <div class="row">
        <div class="col-md-10 no-paddin-xs">
          <!-- tabs user info -->
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="panel panel-white panel-about">
              <div class="panel-heading">
                <h3 class="panel-title">About
                  <a href="edit-profile.php" class="pull-right"><i class="fa fa-edit"></i>Edit</a>
                </h3>
              </div>
              <div class="panel-body">
                <div class="col-md-12 col-sm-12 col-xs-12 about-tab-container">
                  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 about-tab-menu">
                    <div class="list-group">
                      <a href="#" class="list-group-item active text-center">
                        <h4 class="fa fa-child"></h4><br/>Overview
                      </a>
                      <a href="#" class="list-group-item text-center">
                        <h4 class="fa fa-briefcase"></h4><br/>Work
                      </a>
                      <a href="#" class="list-group-item text-center">
                        <h4 class="fa fa-map-marker"></h4><br/>Places
                      </a>
                      <a href="#" class="list-group-item text-center">
                        <h4 class="fa fa-newspaper-o"></h4><br/>Contact info
                      </a>
                      <a href="#" class="list-group-item text-center">
                        <h4 class="fa fa-calendar"></h4><br/>Events
                      </a>
                    </div>
                  </div>
                  <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9 about-tab">
                    <!-- Overview section -->
                    <div class="about-tab-content active">
                       <ul class="list-group">
                        <li class="list-group-item"><i class="fa fa-briefcase text-primary"></i>&nbsp; Work at <?php echo $headline; ?></li>
                        <li class="list-group-item"><i class="fa fa-mobile text-primary"></i>&nbsp; <?php echo $phone; ?></li>
                        <li class="list-group-item"><i class="fa fa-facebook text-primary"></i>&nbsp;/<?php echo $fb; ?>(Facebook)</li>
                        <li class="list-group-item"><i class="fa fa-google-plus text-primary"></i>&nbsp;<?php echo $gplus; ?> (Google+)</li>
                        <li class="list-group-item"><i class="fa fa-twitter text-primary"></i>&nbsp;@<?php echo $tw; ?>(twitter)</li>
                        <li class="list-group-item"><i class="fa fa-info text-primary"></i>&nbsp;@<?php echo $lessons; ?> (9Lessons.info)</li>
                        <li class="list-group-item"><i class="fa fa-birthday-cake text-primary"></i>&nbsp; <?php echo "$day - $month - $yr";?></li>
                        <li class="list-group-item"><i class="fa fa-envelope text-primary"></i>&nbsp; <?php echo "$email";?></li>
                        <li class="list-group-item"><i class="fa fa-globe text-primary"></i>&nbsp; 
                          <label class="label label-info"> <?php echo $country; ?></label> 
                          <label class="label label-primary"> <?php echo $state; ?></label> 
                        </li>
                      </ul>
                    </div>
                    <!-- Work section -->
                    <div class="about-tab-content">
                       <ul class="list-group">
                        <li class="list-group-item"><i class="fa fa-briefcase"></i>&nbsp; Software developer at <a href="#"><?php echo $headline; ?></a></li>
                        <li class="list-group-item"><i class="fa fa-cubes"></i>&nbsp;User at<a href="#">  <?php echo APPNAME; ?></a></li>
                      </ul>
                    </div>

                    <!-- Places search -->
                    <div class="about-tab-content">
                      <ul class="photos">
                        <li>
                            <a href="#">
                              <!--<img src="img/Post/staticmap.png" alt="map 1" class="img-responsive show-in-modal tip">-->
                              <?php echo $country; ?> <?php echo $state; ?>
                            </a>
                        </li>
                      </ul>
                    </div>
                    <!-- Contact section -->
                    <div class="about-tab-content">
                      <ul class="list-group">
                        <li class="list-group-item"><i class="fa fa-phone"></i>&nbsp; <?php echo $phone; ?></li>
                        <li class="list-group-item"><i class="fa fa-facebook text-primary"></i>&nbsp;/<?php echo $fb; ?>(Facebook)</li>
                        <li class="list-group-item"><i class="fa fa-google-plus text-primary"></i>&nbsp;<?php echo $gplus; ?>(Google+)</li>
                        <li class="list-group-item"><i class="fa fa-twitter text-primary"></i>&nbsp;@<?php echo $tw; ?>(twitter)</li>
                        <li class="list-group-item"><i class="fa fa-twitter text-primary"></i>&nbsp;@<?php echo $lessons; ?>(9Lessons.info)</li>
                        <li class="list-group-item"><i class="fa fa-envelope text-primary"></i>&nbsp; <?php echo $email; ?></li>
                      </ul>
                    </div>
                    <!-- Events section-->
                    <div class="about-tab-content">
                      <ul class="list-group">
                        <li class="list-group-item"><i class="fa fa-calendar text-danger"></i>&nbsp; <a href="#">August 12 welcome to my like</a></li>
                        <li class="list-group-item"><i class="fa fa-calendar text-danger"></i>&nbsp; <a href="#">August 5 Nach concert at barcelona</a></li>
                        <li class="list-group-item"><i class="fa fa-calendar text-danger"></i>&nbsp; <a href="#">July 13 El grones concert on medellin</a></li>
                        <li class="list-group-item"><i class="fa fa-calendar text-danger"></i>&nbsp; <a href="#">June 30 final of ty</a> </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- end tabs user info -->
          
          <!-- family -->
          <div class="col-md-12">
            <div class="panel panel-white panel-family">
              <div class="panel-heading">
                <h3 class="panel-title">Friends</h3>
              </div>
              <div class="panel-body">
<?php
include_once("classes/agoTime_example.php"); // Include the class library
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img, U.status,U.ago, U.uid, U.email
FROM users U, friends F
WHERE
CASE

WHEN F.friend_one = '$friend_id'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$friend_id'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends

while($fdata=mysqli_fetch_array($flist))
{
$fimg=$fdata['img'];
$fuid=$fdata['uid'];
$status=$fdata['status'];
$ago=$fdata['ago'];

$fusername=$fdata['username'];
  echo ' <div class="col-md-6 cols-sm-6 col-xs-12">
                  <div class="media block-update-card">
                    <a class="pull-left" href="'.$fusername.'">
                      <img class="media-object update-card-MDimentions" src="user_img/'.$fusername.'/'.$fimg.'" alt="'.$fusername.'">
                    </a>
                    <div class="media-body update-card-body">
                      <h4 class="media-heading">'.$fusername.'</h4>
                      <div class="btn-toolbar card-body-social" role="toolbar"> 
                        <br/> ';
                        ?>
                        <?php
                 if ($status==1) 
                 {
                  echo '<a href="'.$fusername.'" class="btn btn-default"><i class="fa fa-check-circle connected-status alert-success"></i> View Profile | '.time_passed($ago).'</a>
                   ';
                 }
                 else
                 {
                  echo '<a href="'.$fusername.'" class="btn btn-default"><i class="fa fa-times-circle absent-status alert-danger"></i> View Profile | '.time_passed($ago).'</a>';
                 }

                  ?>
                  <?php
                      echo'</div>
                    </div>
                  </div>   
                </div>';
}
if ($friendsList==0) {
echo'<h3 class="btn btn-danger btn-responsive"><i class="fa fa-users"></i> No Friend\'s</h3>';
}

                ?>
                



              </div>
            </div>
          </div><!-- end family-->
        </div>
      </div>
    </div>

    <?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs">
          <a href="#" class="hide-chat btn btn-success btn-sm">Hide
          </a>
        </p> 
        <p class="text-center chat-title">Online users</p>  
<?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>


        
      </div>
    </div>
    <!-- Online users sidebar content-->
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>



<script type="text/javascript">
$(document).ready(function(){
//Initialize the DOM
$(".follow").click(function(){

var element = $(this);
var usertoken = element.attr("id");
  //alert(usertoken);
  $(this).removeClass();
    $(this).addClass("btn btn-warning following");
    $(this).text("Following");
// alert(usertoken);

var dataString = 'friend='+usertoken+'&user_id='+<?php echo $session_uid; ?>;
                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "ajax/respond-request.php",
                    data: dataString,
                    cache: false,

                  });
return false;

});

});
</script>
  </body>
</html>
