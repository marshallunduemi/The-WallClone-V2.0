<?php include 'session.php'; ?>
<?php include 'connection.php'; ?>
<?php
if (isset($_POST['post']) AND !empty($_POST['post']) AND !empty($_SESSION['uid']))
 {

$post1=htmlspecialchars($_POST['post'], ENT_QUOTES, 'UTF-8');
$post=trim($post1);
$group_id=($_POST['groupid']);
//$photo=htmlentities($_POST['photoimg']);
$user_id=$_SESSION['uid'];
//$username=$_SESSION['username'];
$time=time();

// insert into group update table
$db->query("INSERT INTO updates (message,user_id_fk,group_id_fk, created) VALUES ('$post','$user_id','$group_id','$time')");

// insert into post table
$db->query("INSERT INTO post (created, user_id, group_id, message) 
  VALUES ('$time','$user_id','$group_id','$post')");
//to notification
$db->query("INSERT INTO notification (activityID, userid, message, type,created) 
  VALUES ('$group_id', '$user_id','$post', 'grouppost', '$time')");

//convert hashtags
function gethashtags($text)
{
  //Match the hashtags
  preg_match_all('/(^|[^a-z0-9_])#([a-z0-9_]+)/i', $text, $matchedHashtags);
  $hashtag = '';
  // For each hashtag, strip all characters but alpha numeric
  if(!empty($matchedHashtags[0])) {
    foreach($matchedHashtags[0] as $match) {
      $hashtag .= preg_replace("/[^a-z0-9]+/i", "", $match).',';
    }
  }
    //to remove last comma in a string
return rtrim($hashtag, ',');
}

//convert text to clickable links
function convert_clickable_links($message)
{
  $parsedMessage = preg_replace(array('/(?i)\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))/', '/(^|[^a-z0-9_])@([a-z0-9_]+)/i', '/(^|[^a-z0-9_])#([a-z0-9_]+)/i'), array('<a href="$1" target="_blank">$1</a>', '$1<a href="http://thewallclone.com/$2">@$2</a>',  '$1<a target="_blank" href="http://thewallclone.com/search.php?s=$2&searching=yes">#$2</a>'), $message);
  return $parsedMessage;
}


$query = $db->query("SELECT * FROM updates ORDER BY update_id DESC");
    //Count total number of rows
    $rowCount = $query->num_rows;
$row=mysqli_fetch_array($query);
$user_id=$row['user_id_fk'];
$message=$row['message'];
$id=$row['update_id'];
$timecreated=$row['created'];
$postimage=$row['img'];
$group_id_fk=$row['group_id_fk'];


$sql_group= $db->query("SELECT * FROM groups WHERE group_id=$group_id_fk");
$owner=mysqli_fetch_array($sql_group);
$group_name=$owner['group_name'];
$owner_id=$owner['user_id_fk'];
$group_img=$owner['img'];



$sql_user= $db->query("SELECT img, username,uid FROM users WHERE uid=$user_id");
$ruser=mysqli_fetch_array($sql_user);
//$name=$ruser['name'];
$usernamepost=$ruser['username'];
$imgpost=$ruser['img'];
$groupowner=$ruser['uid'];
}
include_once("classes/agoTime_example.php"); // Include the class library
?>


<!-- first post-->
          <div class="panel panel-white post panel-shadow">

            <?php

if ($owner_id==$groupowner) 
{
 echo '  <div class="post-heading">
              <div class="pull-left image">
                <img src="groups/'.$group_name."/".$group_img.'" class="avatar" alt="user profile image">
              </div>
              <div class="pull-left meta">
                <div class="title h5">
                  <a href="" class="post-user-name">'.$group_name.'</a>';
                  ?>
                   <?php if ($postimage==true)
                        {
                          echo "Shared picture";
                        }
                        else
                        {
                          echo "Shared a post";
                        }
                        
                        ?> 
<?php
             echo '</div>
                <h6 class="text-muted time"><i class="fa fa-calendar"></i> '.time_passed($time).'</h6>
              </div>
            </div>';
}
else
{
  echo '  <div class="post-heading">
              <div class="pull-left image">
                <img src="user_img/'.$usernamepost."/".$imgpost.'" class="avatar" alt="user profile image">
              </div>
              <div class="pull-left meta">
                <div class="title h5">
                  <a href="" class="post-user-name">'.$usernamepost.'</a>';
                  ?>
                   <?php if ($postimage==true)
                        {
                          echo "Shared picture";
                        }
                        else
                        {
                          echo "Shared a post";
                        }
                        
                        ?> 
<?php
             echo '</div>
                <h6 class="text-muted time"><i class="fa fa-calendar"></i> '.time_passed($time).'</h6>
              </div>
            </div>';
}

 ?>

             <!--<div class="post-image">
              <img src="web.png" class="image show-in-modal" alt="image post">
            </div> -->
            <div class="post-description">
              <p class="show-read-more"><?php echo convert_clickable_links($message); ?></p>

<?php
if(preg_match('~(?:https?://)?(?:www.)?(?:thewallclone.com|thescript.net16.net)/(?:group\?id=)?([^\s]+)~', $message, $match)){


$sql_check= $db->query("SELECT * FROM groups WHERE group_id='".($match[1])."'");
$groupinfo=mysqli_fetch_array($sql_check);
$group_nameinfo=$groupinfo['group_name'];
$group_info=$groupinfo['group_desc'];
$group_idinfo=$groupinfo['group_id'];
$owner_idinfo=$groupinfo['user_id_fk'];
$group_imginfo=$groupinfo['img'];
$group_coverinfo=$groupinfo['cover'];

if ($group_idinfo==$match[1]) {
$GroupLike=$db->query("SELECT U.username, U.uid, U.img
FROM
users U, group_users G
WHERE
U.uid=G.user_id_fk
AND
G.group_id_fk='$group_idinfo' ORDER BY G.group_user_id DESC");
 //Count total number of people am following
$CountGroupLike = mysqli_num_rows($GroupLike); // count of total friends like

$querycount = $db->query("SELECT * FROM updates WHERE group_id_fk='$group_idinfo' ");
    //Count total number of rows
    $tweetcount = $querycount->num_rows;

  echo '<a href="group.php?id='.($match[1]).'"><div class="box box-widget widget-user">';
  ?>

        <div class="widget-user-header" style="background-image: url(<?php echo "groups/$group_nameinfo/$group_coverinfo"; ?>); background-size:cover; position:relative; background-position:center ">
<?php
         echo '
         <h3 class="widget-user-username" style="color:red;">'.$group_nameinfo.' Group</h3>
        </div>
        <div class="widget-user-image">
          <img class="img-responsive" src="groups/'.$group_nameinfo."/".$group_imginfo.'" alt="User Avatar">
        </div></a>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-4 border-right">
              <div class="description-block">
                <h5 class="description-header"><i class="fa fa-rss"></i> '.$tweetcount.'</h5>
                <span class="description-text">TWEETS</span>
              </div>
            </div>
            <div class="col-sm-4 border-right">
              <div class="description-block">';
                ?>
                <?php
                if($CountGroupLike <=1)
                {

                  echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                  <span class="description-text">LIKE</span>';

                }
                else
                {
                   echo '<h5 class="description-header"><i class="fa fa-thumbs-up"></i> '.$CountGroupLike.' </h5>
                   <span class="description-text">LIKES</span>';
                }
                ?>
                <?php
              echo '</div>
            </div>
            <div class="col-sm-4">
              <div class="description-block">
                <h5 class="description-header"> <a href="#"  id="'.$group_idinfo.'"><i class="fa fa-heart"></i> LIKE GROUP</a></h5>
                <p class="sponsor-name alert-success"><i class="fa fa-check"></i> Sponsored Group</p>
              </div>
            </div>
            <p style="word-wrap: break-word;">'.convert_clickable_links($group_info).'</p>
          </div>
        </div>
      </div>
';
}
else
{
  echo '
              <div class="description-block">
                <h5 class="description-header alert-danger"><i class="fa fa-info-circle"></i> THIS GROUP DOES NOT EXIST</h5>
                <br/>
                <a href="createpage.php" class="alert alert-success"><i class="fa fa-check"></i> CREATE NEW GROUP</a>
              </div>';
}
}

if(preg_match('~(?:https?://)?(?:www.)?(?:youtube.com|youtu.be)/(?:watch\?v=)?([^\s]+)~', $message, $match)){
echo "<br><iframe width='600' src='http://www.youtube.com/embed/".$match[1]."' frameborder='0' class='video' allowfullscreen></iframe><br>\n";
//print Youtube ID: ($match[1]);
}

if(preg_match("/(https?:\/\/)?(www.)?(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/", $message, $output_array)) {
echo "<br>";

echo '<br><iframe width="600" src="//player.vimeo.com/video/'.$output_array[5].'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" class="video"></iframe>';

    //echo "Vimeo ID: $output_array[5]";
    }
?>
              <div class="stats">
                <div class="stats">
<div class="feed" id="feed<?php echo $id; ?>">
<div class="heart" id="like<?php echo $id; ?>" rel="like">
<div class="likeCount" id="likeCount<?php echo $id; ?>"></div>
</div> 
                <a href="#" class="stat-item">
                  <i class="fa fa-retweet icon">
                  </i>
                  0
                </a>
                <a href="#" class="stat-item">
                  <i class="fa fa-comments-o icon">
                  </i>
                  0
                </a>
              </div>
            </div>
           

  