<?php
include ('../config/config.php');
?>
<?php
$user_id=$_POST['userid'];
//Insert query
$group_id=$_POST['groupid'];

	
$db->query("DELETE FROM group_users 
WHERE user_id_fk='$user_id' AND group_id_fk='$group_id' AND status='1'");   // if(!mysql_errno()){
//echo "Form Submitted Succesfully $friend_id / $user_id";


 ?>
