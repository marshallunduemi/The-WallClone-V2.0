<?php
include ('../config/config.php');
?>
<?php
$user_id=$_POST['userid'];
//Insert query
$group_id=$_POST['groupid'];


$sql_check= $db->query("SELECT * FROM group_users 
	WHERE group_id_fk='group_id' AND user_id_fk='$user_id' AND status='1'");
$group=mysqli_fetch_array($sql_check);
$group_id_fk=$group['group_id_fk'];
$user_id_fk=$group['user_id_fk'];
$time=time();
if ($group_id_fk==$group_id AND $user_id_fk==$user_id) {
	// do not add to table

}
else
{
	$db->query("INSERT INTO group_users (group_id_fk, user_id_fk, status) VALUES ('$group_id ', ' $user_id', '1')");

	$db->query("INSERT INTO activities (user_id_fk, activity_id, status, created) VALUES ('$user_id', '$group_id', 'group_like', '$time')");

	 if(!mysqli_errno())
	 {
	 }
//echo "Form Submitted Succesfully $friend_id / $user_id";

}
	


 ?>
