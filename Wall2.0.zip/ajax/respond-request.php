<?php
include ('../connection.php');
?>
<?php
$friend_id=$_POST['friend'];
//Insert query
$user_id=$_POST['user_id'];
	//if (isset($friend_id!=$user_id)) {

$db->query("INSERT INTO friends (friend_one, friend_two, status) 
VALUES ('$user_id ',' $friend_id', '1')");   // if(!mysql_errno()){
//echo "Form Submitted Succesfully $friend_id / $user_id";

		# code...
	//}
	//else
	//{}
 ?>
