<?php
include ('../config.php');
?>
<?php
$friend_id=$_POST['friend'];
//Insert query
$user_id=$_SESSION['uid'];
	//if (isset($friend_id!=$user_id)) {

$db->query("INSERT INTO friends
(friend_one,friend_two)
VALUES
(' $user_id ',' $friend_id ')");   // if(!mysql_errno()){
//echo "Form Submitted Succesfully $friend_id / $user_id";

		# code...
	//}
	//else
	//{}
 ?>
