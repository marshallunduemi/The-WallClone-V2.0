
//Initialize the DOM
$(".follow").click(function(){
var element = $(this);
var usertoken = element.attr("id");
  //alert(usertoken);
  $(this).removeClass();
    $(this).addClass("btn btn-danger following");
    $(this).text("Following");
    
var dataString = 'friend='+usertoken+'&user_id='+<?php echo $session_uid; ?>;
                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "ajax/respond-request.php",
                    data: dataString,
                    cache: false,

                  });
return false;

});

/* *********************************************************************
   Purpose      : function to truncate text and show read more links.
   Parameters       : @maxLenghtc : story description
   Returns      : string
   *********************************************************************** */

  var maxLength = 300;
  $(".show-read-more").each(function(){
    var myStr = $(this).text();
    if($.trim(myStr).length > maxLength){
      var newStr = myStr.substring(0, maxLength);
      var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
      $(this).empty().html(newStr);
      $(this).append(' <a href="javascript:void(0);" class="read-more">read more...</a>');
      $(this).append('<span class="more-text">' + removedStr + '</span>');
    }
  });

  $(".read-more").click(function(){
    $(this).siblings(".more-text").contents().unwrap();
    $(this).remove();
  });

/*  *********************************************************************
   Purpose      : function to truncate text and show read more links.
   Parameters       : @maxLenghtc : story description
   Returns      : string
                                    END HERE
   *********************************************************************** */
