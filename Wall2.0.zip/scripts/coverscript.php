<?php
$folder=$_SESSION['username'];
$session_uid=$_SESSION['uid'];

$path = "user_img/$folder/";

  $valid_formats = array("jpg","jpeg", "JPG", "png", "PNG", "gif", "bmp");
  // Check if image file is a actual image or fake image
if(isset($_POST["btn_timeline"])) {

  if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
    {
      $name = $_FILES['timelineFile']['name'];
      $size = $_FILES['timelineFile']['size'];
      
      if(strlen($name))
        {
          list($txt, $ext) = explode(".", $name);
          if(in_array($ext,$valid_formats))
          {
          if($size<(1024*1024))
            {
              $image = time().substr(str_replace(" ", "_", $txt), 10).".".$ext;
              $tmp = $_FILES['timelineFile']['tmp_name'];
              if(move_uploaded_file($tmp, $path.$image))
                {

$action=$db->query("UPDATE users SET profile_background='$image' WHERE uid='".$_SESSION['uid']."'");


$db->query("INSERT INTO post (created, user_id, type, image) VALUES ('$time','$session_uid', 'timeline', '$image')");

                  
    
   $success='<div class="alert"> Cover Updated...</div>';
                }
              else

                $success='<div class="error">failed to Upload! </div>';     
            }
            else
              $success='<div class="error">Image file size must not exceed 1MB!</div>';        
            }
            else
               $success='<div class="error">Invalid file format!</div>';
        }
        
      else
       $success='<div class="error">Please select image to upload</div>';   
        
 
    }
  }