<?php 
include('config/config.php');
 if(empty($_SESSION['id'])&&(empty($_SESSION['email']))&&(empty($_SESSION['username']))) {
header('location: index.php');
}