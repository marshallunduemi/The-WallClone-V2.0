
<?php
$folder1=$_SESSION['username'];
$session_uid=$_SESSION['uid'];

$path = "groups/$groupNameset/";
$time=time();
  $valid_formats = array("jpg","jpeg", "JPG", "png", "PNG", "gif", "bmp");
  // Check if image file is a actual image or fake image
if(isset($_POST["btn_timeline"])) {

  if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
    {
      $name = $_FILES['timelineFile']['name'];
      $size = $_FILES['timelineFile']['size'];
      
      if(strlen($name))
        {
          list($txt, $ext) = explode(".", $name);
          if(in_array($ext,$valid_formats))
          {
          if($size<(1024*1024))
            {
              $image = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
              $tmp = $_FILES['timelineFile']['tmp_name'];
              if(move_uploaded_file($tmp, $path.$image))
                {

$action=$db->query("UPDATE groups SET cover='$image' WHERE group_id='$pid'");


$db->query("INSERT INTO updates (img, user_id_fk,group_id_fk, type, created) VALUES ('$image','$session_uid','$pid','cover','$time')");
                  


   $success='<div class="alert"> Cover Updated...</div>';
                }
              else

                $success='<div class="error">failed to Upload! </div>';     
            }
            else
              $success='<div class="error">Image file size must not exceed 1MB!</div>';        
            }
            else
               $success='<div class="error">Invalid file format!</div>';
        }
        
      else
       $success='<div class="error">Please select image to upload</div>';   
        
 
    }
  }

  $setid= $db->query("SELECT * FROM groups WHERE group_id='$pid'");
$items=mysqli_fetch_array($setid);

  $groupNameset=$items['group_name'];
  $groupImageset=$items['img'];
  $groupIdset=['group_id'];
  $groupCreatorId=$items['user_id_fk'];
  $groupInfo=$items['group_desc'];
  $groupCover=$items['cover'];