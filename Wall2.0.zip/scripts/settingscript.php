
<?php

$folder1=$_SESSION['username'];
$session_uid=$_SESSION['uid'];
$time=time();
$path = 'user_img/'.$folder1.'/'; //image folder path

  $valid_formats = array("jpg","jpeg", "JPG", "png", "PNG", "gif", "bmp");
  // Check if image file is a actual image or fake image
if(isset($_POST["btn_upload"])) {

  if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
    {
      $name = $_FILES['fileToUpload']['name'];
      $size = $_FILES['fileToUpload']['size'];
      
      if(strlen($name))
        {
          list($txt, $ext) = explode(".", $name);
          if(in_array($ext,$valid_formats))
          {
          if($size<(1024*1024))
            {
              $image = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
              $tmp = $_FILES['fileToUpload']['tmp_name'];
              if(move_uploaded_file($tmp, $path.$image))
                {

$action=$db->query("UPDATE users SET img='$image' WHERE uid='".$_SESSION['uid']."'");

$db->query("INSERT INTO post (created, user_id, type, image) VALUES ('$time','$session_uid', 'profile', '$image')");


                  
    
      $success='<div class="alert"> Profile Upload Complete...</div>';
                }
              else

                $success='<div class="error">failed to Upload! </div>';     
            }
            else
              $success='<div class="error">Image file size must not exceed 1MB!</div>';        
            }
            else
               $success='<div class="error">Invalid file format!</div>';
        }
        
      else
       $success='<div class="error">Please select image to upload</div>';   
        
 
    }
  }