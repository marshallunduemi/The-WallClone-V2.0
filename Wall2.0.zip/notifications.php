<?php
include("check.php"); 
include_once("classes/agoTime_example.php"); // Include the class library

$ago=time();
$session_uid=$_SESSION['uid'];
$album=$_SESSION['username'];
$query_profile= $db->query("SELECT * FROM users WHERE uid='$session_uid'");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_img=$user_data['img'];
  $status=$user_data['status'];
  $ago=$user_data['ago'];


$folder1=$_SESSION['username'];
include("session-data.php"); 

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Wall Clone Social Network : Notification : Codexpress Labs </title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="animated fadeIn">

       <!-- Fixed navbar -->
    <?php include ('navbar.php'); ?>

<!-- Timeline content -->
    <div class="container container-timeline" style="margin-top:70px;">
      <div class="col-md-10 no-paddin-xs">
        <div class="col-md-5 no-paddin-xs">
   <!-- start left content -->
          <?php
          //include ('left-content.php');
          ?>
          <!-- End people yout may know -->
        </div>
        <!-- end left content -->

			<!-- notification list-->
    		<div class="col-md-7 no-paddin-xs">
    		<div class="panel panel-white post panel-shadow">
					  <div class="panel-body">

   <ul class="nav nav-tabs" role="tablist">
      <li class="active"><a href="#tab1" role="tab" data-toggle="tab"><span class="fa fa-info"></span> Notifications <small class="chat-alert label label-danger">1</small></a></li>
      </ul>
 </div>
 </div>
  <div class="tab-content">
      <div class="tab-pane active" id="tab1">
<?php
$querycount = $db->query("SELECT * FROM notification ORDER BY id DESC");
    //Count total number of rows
    $tweetcount = $querycount->num_rows;

while($items=mysqli_fetch_array($querycount))
{
  $id=$items['id'];
  $activityID=$items['activityID'];
  $userid=$items['userid'];
  $type=$items['type'];
  $message=$items['message'];
  $ncreated=$items['created'];
// if grouppost select from group update table
  if ($type=='grouppost') {

$query001 = $db->query("SELECT G.group_name, G.img, G.group_id, U.created FROM groups G, updates U  WHERE G.group_id='$activityID' ORDER BY U.update_id DESC");

$row=mysqli_fetch_array($query001);
$group_id=$row['group_id'];
$group_name=$row['group_name'];
$group_img=$row['img'];
$group_created=$row['created'];

$sql_user= $db->query("SELECT img, username,uid FROM users WHERE uid=$userid");
$ruser=mysqli_fetch_array($sql_user);
//$name=$ruser['name'];
$username=$ruser['username'];
$imgpost=$ruser['img'];
$groupowner=$ruser['uid'];


echo '<div class="panel panel-white post panel-shadow">
          <div class="post-heading">
              <div class="pull-left image">
                  <img src="groups/'.$group_name.'/'.$group_img.'" class="avatar" alt="'.$group_name.'">
              </div>
              <div class="pull-left meta">
                  <div class="title h5">
                      <a href="'.$username.'" class="post-user-name">'.$username.'</a>
                  </div>                 
                  <h6 class="text-muted time"><i class="fa fa-share"></i> Share a post on 
                  <a href="group.php?id='.$group_id.'">'.$group_name.' Group Wall </a></h6>
                  <h6 class="text-muted time">'.time_passed($ncreated).'</h6>
                  
                  
             </div>
          </div>
        </div>';

  }

 
}



?>


</div>



     
</div>

				

				<div class="panel panel-white post-load-more panel-shadow text-center">
					<button class="btn btn-success">
						<i class="fa fa-refresh"></i>Load More...
					</button>
				</div>				
    		</div><!-- notification list-->
    	</div>
    </div>
<?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs">
          <a href="#" class="hide-chat btn btn-success btn-sm">Hide
          </a>
        </p> 
        <p class="text-center chat-title">Online users</p>  
<?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>


        
      </div>
    </div>
    
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>
        <script src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>

<script type="text/javascript">
$(document).ready(function(){
//Initialize the DOM
$(".follow").click(function(){

var element = $(this);
var usertoken = element.attr("id");
  //alert(usertoken);
  $(this).removeClass();
    $(this).addClass("btn btn-danger following");
    $(this).text("Following");

var dataString = 'friend='+usertoken+'&user_id='+<?php echo $session_uid; ?>;
                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "ajax/respond-request.php",
                    data: dataString,
                    cache: false,

                  });
return false;

});

});
</script>
  </body>
</html>
