<?php
include 'config/config.php';
include 'scripts/Oaut.php';
include_once 'scripts/settingscript.php';
include_once 'scripts/coverscript.php';
$session_uid=$_SESSION['uid'];
?>
<?php 
$query_profile= $db->query("select * from users where uid='$session_uid' AND 1=1");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_email=$user_data['email'];
  $profile_background=$user_data['profile_background'];
  $user_img=$user_data['img'];
  $profile_background_position=$user_data['profile_background_position'];


$sqlheadline=$db->query("select * from user_bio where uid='$session_uid'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$phone=$row['phone'];
$address=$row['address'];
$site=$row['site'];
$country=$row['country'];
$state=$row['state'];
$lessons=$row['lessons'];
$linked=$row['linkedIn'];
$dob=$row['dob'];
$info=$row['about'];



?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Wall Script Social Network : Codexpress Labs </title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="style.css"/>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

    <script type="text/javascript">
$(function() {
    $("#uploadFile").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function(){ // set image data as background of div
                $("#imagePreview").css("background-image", "url("+this.result+")");
            }
        }
    });
});
</script>

<style>
.error{
                margin-bottom: 40px;
                background: red;
                padding: 5px;
                color: white;
            }

#imagePreview{
    width: 150px;
    height: 150px;
    margin-left: 80px;
    background-position: center center;
    background-size: cover;
    -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
    display: inline-block;
}
            .alert{
                margin-bottom: 40px;
                background: #ebf8a4;
                padding: 5px;
                color: black;
            }
.timelineUploadBG {
            	position: absolute;
            	margin-top: 60px;
            	margin-right: 813px;
            	height: 32px;
            	width: 30px;
            	left: 140px;
            	top: 100px;
            }

.timelineUpload {
            	position: absolute;
            	margin-top: 250px;
            	margin-right: 813px;
            	height: 32px;
            	width: 30px;
            	left: 35px;
            	top: 115px;
            }

            .uploadFile {
            background: url('images/whitecam.png') no-repeat;
            height: 32px;
            width: 30px;
            overflow: hidden;
            cursor: pointer;
            }
            .uploadFile input {
            filter: alpha(opacity=0);
            opacity: 0;
            margin-right: -110px;
            }

            .custom-file-input {
            height: 25px;
            cursor: pointer;
            }
            .left {
				position: absolute;
            	margin-top: 250px;
            	margin-right: 813px;
            	height: 32px;
            	left: 75px;
            	top: 115px;
}
</style>
  </head>
  <body class="animated fadeIn">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <a class="navbar-brand" href="home.php">
            <b>The Wall Script 2.0
            </b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <div class="col-md-5 col-sm-4">         
            <form class="navbar-form">
              <div class="form-group" style="display:inline;">
                <div class="input-group" style="display:table;">
                  <input class="form-control" name="search" placeholder="Search..." autocomplete="off" type="text">
                  <span class="input-group-addon" style="width:1%;">
                    <span class="fa fa-search">

                    </span>
                  </span>
                </div>
              </div>
            </form>
          </div>        
          <ul class="nav navbar-nav navbar-right">
            <li class="active">
              <a href="home.php">
                <i class="fa fa-bars">
                </i>&nbsp;Home
              </a>
            </li>
            <li>
              <a href="messages.php">
                <i class="fa fa-envelope">
                </i> Message
              </a>
            </li>
            <li>
              <a href="notifications.php">
                <i class="fa fa-globe">
                </i> Notification
              </a>
            </li>
            <li>
              <a href="#" class="nav-controller">
                <i class="fa fa-user">
                </i> Users
              </a>
            </li>
            <li>
              <a href="logout.php" class="nav-controller">
                <i class="fa fa-sign-out">
                </i> Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Timeline content -->
    <div class="container">
	    <!-- cover content -->
	    <div class="row">
	      <div class="col-md-10 no-paddin-xs">
	      	<!-- cover and profile image-->
	        <div class="col-md-12 col-sm-12 col-xs-12 cover-content">
				<div class="cover-container" style="background-image: url(<?php echo "uploads/$profile_background"; ?>);" id="imageProfile">
					<div class="social-cover"></div>
					<div class="social-desc">
					   <div class="desc-content">
					      <h1 class="fg-white text-shadow"><?php echo "$country $state"; ?></h1>
					      <h5 class="fg-white text-shadow">- <?php echo date('M d, Y'); ?></h5>
					      <div style="margin-top:50px;"></div>
					   </div>
					</div>
					<div class="social-avatar" >
					<div class="img-avatar" style="background-image: url(<?php echo "user_img/$username/$user_img"; ?>);" id="imagePreview"></div>
					   <h4 class="fg-white text-center text-shadow">
					   <?php echo "$name @ $username";?></h4>
					   <h5 class="fg-white text-center" style="opacity:0.8;"><?php echo $info;?></h5>

					   <hr class="border-black75 text-shadow" style="border-width:2px;" >
					   
					           <div class="text-center">
                    <form accept="" method="POST" enctype="multipart/form-data">
                      <div class="uploadFile timelineUploadBG">
                      <input id="uploadFile" type="file" required name="fileToUpload" class=" custom-file-input" original-title="Change Cover Picture">
                      </div>
                      <button role="button" class="btn btn-inverse btn-outlined btn-retainBg btn-brightblue" type="submit" name="btn_upload">
					      <span>Set Profile</span>
					    </button>
					   </form>
					   </div>
					</div>
				</div>
	        </div><!-- end cover and profile image-->

	         <div class="form-group">
                    <form accept="" method="POST" enctype="multipart/form-data">
                      <div class="uploadFile timelineUpload">
                      <input id="uploadProfile" type="file" required name="timelineFile" class=" custom-file-input" original-title="Change Cover Picture">
                      </div>
                    </div>
                    <button type="submit" name="btn_timeline" value="Upload" class="btn btn-primary left"><span class="fa fa-cloud-upload"></span></button>
                    </form>

	        <!-- cover menu -->
	        <div class="col-md-12  col-sm-12 col-xs-12">
	          <div class="panel-options">
	            <div class="navbar navbar-default navbar-cover">
	              <div class="container-fluid">
	                <div class="navbar-header">
	                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#profile-opts-navbar">
	                    <span class="sr-only">Toggle navigation</span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                  </button>
	                </div>

	                <div class="collapse navbar-collapse" id="profile-opts-navbar">
	                  <ul class="nav navbar-nav navbar-right">
	                    <li class="active"><a href="#"><i class="fa fa-tasks"></i>Timeline</a></li>
	                    <li><a href="about.html"><i class="fa fa-info-circle"></i>About</a></li>
	                    <li><a href="friends.html"><i class="fa fa-users"></i>Friends</a></li>
	                    <li><a href="photos.html"><i class="fa fa-file-image-o"></i>Photos</a></li>
	                    <li><a href="messages.html"><i class="fa fa-comment"></i>Messages</a></li>
	                  </ul>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div><!-- cover menu -->
	      </div>
	    </div><!-- cover content -->

	    <div class="row">
	    	<div class="col-md-10 no-paddin-xs">
	    		<!-- left content (detail, frields, photos) -->
	    		<div class="col-md-5 user-detail no-paddin-xs">
	    			<!-- user detail -->
					<div class="panel panel-default panel-user-detail">
						<div class="panel-body">
						  <ul class="list-unstyled">
						    <li><i class="fa fa-suitcase"></i>Works at <a href="#"><?php echo $info;?></a></li>
						    <li><i class="fa fa-calendar"></i>Born on <?php echo $dob;?></li>

<?php

$queryFollowing=$db->query("SELECT F.status, U.username,U.img,U.uid, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
END

AND
F.status='1'");
 //Count total number of people am following
$rowCountFollowing = mysqli_num_rows($queryFollowing); // count of total friends


$queryFollowers=$db->query("SELECT F.status, U.username,U.img,U.uid, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = U.uid
THEN F.friend_two = '$_SESSION[uid]'
END

AND
F.status='1'");
 //Count total number of people am following
$rowCountFollowers = mysqli_num_rows($queryFollowers); // count of total friends

?>

						    <li><i class="fa fa-rss"></i>Followed by 
						    <a href="home.php"><?php if($rowCountFollowers ==1)
						    {
						    	echo "$rowCountFollowers Person";
						    }
						    else
						    {
						    	echo "$rowCountFollowers People";
						    }
						    ?>
						     </a>
						     </a></li>
						     <li><i class="fa fa-rss"></i>Following 
						    <a href="home.php"><?php if($rowCountFollowing ==1)
						    {
						    	echo "$rowCountFollowing Person";
						    }
						    else
						    {
						    	echo "$rowCountFollowing People";
						    }
						    ?>
						     </a></li>
                 <li><i class="fa fa-globe"></i>Visit
                 <?php if(!empty($site))
                {
                  echo '<a href="'.$site.'">'.$site.'</a>';
                }
                ?>
                </li>
                
                 <?php 
                if(empty($name))
                {
              echo '<li><i class="fa fa-info"></i>
              <a href="edit-profile.php" class="alert alert-warning">You are awesome, but You\'r not complete</a></li>';
                }
                ?>
                
						  </ul>
						</div>
						<div class="panel-footer text-center">
						<div class="panel-heading">
						  <a href="edit-profile.php" class="pull-right">Edit Profile&nbsp;<i class="fa fa-edit"></i></a>
						  </div>
						</div>
					</div><!-- end user detail -->
					
					<!-- friends -->
					<div class="panel panel-white panel-friends">
						<div class="panel-heading">
						  <a href="#" class="pull-right">View all&nbsp;<i class="fa fa-share-square-o"></i></a>
						  <h3 class="panel-title">Friends</h3>
						</div>
						<div class="panel-body text-center">
						  <ul class="friends">
<?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid, U.email
FROM users U, friends F
WHERE
CASE

WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends

while($fdata=mysqli_fetch_array($flist))
{
$fimg=$fdata['img'];
$fuid=$fdata['uid'];
$fusername=$fdata['username'];
  echo ' 						<li>
						        <a href="'.$fusername.'">
						        <img src="user_img/'.$fusername.'/'.$fimg.'" title="'.$fusername.'" class="img-responsive tip" style="height:90px;">
						        </a>
						    	</li>';
}
if ($friendsList==0) {
echo'<h3 class="btn btn-danger btn-responsive"><i class="fa fa-users"></i> No Follower\'s</h3>';
}
?>

						   

						    
						  </ul>
						</div>
					</div><!-- end friends --> 
					<!-- photos -->
<?php

$subpath= $folder_path = 'user_img/'.$folder1.'/'; //image folder path
    $files = glob($folder_path . "*.{JPG,jpg,jpeg,JPEG,gif,png,PNG,bmp}", GLOB_BRACE);
?>
					<div class="panel panel-white">
						<div class="panel-heading">
						  <a href="#" class="pull-right">View all&nbsp;<i class="fa fa-share-square-o"></i></a>
						  <h3 class="panel-title">Photos <strong>(<?php echo count($files); ?>)</strong></h3>
						</div>
						<div class="panel-body text-center">
						  <ul class="photos">
<?php 
foreach($files as $file){
       				echo '	<li>
						        <a href="#">
						          <img src="'.$file.'" alt="'.$file.'" class="img-responsive show-in-modal" style="height:110px;">
						        </a>
						    </li>';
   }

    
?> 
						  </ul>
						</div>
					</div><!-- end photos-->
					
					<div class="panel panel-white panel-likes">
						<div class="panel-heading">
						  <h3 class="panel-title"><i class="fa fa-thumbs-o-up"></i>&nbsp;Likes</h3>
						</div>
						<div class="panel-body">
						  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" data-interval="">
						    <!-- Indicators -->
						    <ol class="carousel-indicators">
						      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
						      <li data-target="#carousel-example-generic" data-slide-to="1"></li>
						    </ol>

						    <!-- Wrapper for slides -->
						    <div class="carousel-inner" role="listbox-likes">
						      <div class="item active">
						        <div class="row">
						          <div class="col-md-6 col-sm-6 col-xs-3"><a href="#" class="thumbnail"><img src="img/Likes/likes-5.png" alt="Like"></a></div>
						          <div class="col-md-6 col-sm-6 col-xs-3"><a href="#" class="thumbnail"><img src="img/Likes/likes-6.png" alt="Like"></a></div>
						          <div class="col-md-6 col-sm-6 col-xs-3"><a href="#" class="thumbnail"><img src="img/Likes/likes-1.png" alt="Like"></a></div>
						          <div class="col-md-6 col-sm-6 col-xs-3"><a href="#" class="thumbnail"><img src="img/Likes/likes-2.png" alt="Like"></a></div>
						        </div>
						      </div>
						      <div class="item">
						        <div class="row">
						          <div class="col-md-6 col-sm-6 col-xs-3"><a href="#" class="thumbnail"><img src="img/Likes/likes-3.png" class="show-in-modal" alt="Like"></a></div>
						          <div class="col-md-6 col-sm-6 col-xs-3"><a href="#" class="thumbnail"><img src="img/Likes/likes-4.png" class="show-in-modal" alt="Like"></a></div>
						          <div class="col-md-6 col-sm-6 col-xs-3"><a href="#" class="thumbnail"><img src="img/Likes/likes-5.png" class="show-in-modal" alt="Like"></a></div>
						          <div class="col-md-6 col-sm-6 col-xs-3"><a href="#" class="thumbnail"><img src="img/Likes/likes-6.png" class="show-in-modal" alt="Like"></a></div>
						        </div>
						      </div>
						    </div>

						    <!-- Controls -->
						    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
						      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						      <span class="sr-only">Previous</span>
						    </a>
						    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
						      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						      <span class="sr-only">Next</span>
						    </a>
						  </div>
						</div>
					</div><!-- en likes -->

					<!-- groups -->
					<div class="panel panel-white panel-groups">
						<div class="panel-heading">
            <a href="createpage.php" class="pull-right">Create Group&nbsp;<i class="fa fa-pencil"></i></a>
						  <h3 class="panel-title">Groups</h3>
						</div>
						<div class="panel-body">
						  <ul class="list-group">
<?php
$querygroup= $db->query("select * from groups where creatorid='$session_uid' AND 1=1");
  while($pages=mysqli_fetch_array($querygroup))
  {
  $groupName=$pages['name'];
  $groupImage=$pages['img'];
  $GroupId=$pages['id'];


  echo '<li class="list-group-item">
                  <div class="col-xs-3 col-sm-6 col-md-3">
                      <img src="groups/'.$groupName.'/'.$groupImage.'" alt="Group" class="img-responsive" />
                  </div>
                  <div class="col-xs-9 col-sm-6">
                      <a href="viewgroup/'.$GroupId.'"><span class="name">'.$groupName.'</span></a>
                  </div>
                  <div class="clearfix"></div>
                </li>
';
  }
?>
						  </ul>
						</div>
					</div><!-- end groups-->              										
	    		</div><!-- end left content (detail, frields, photos) -->

	    		<!-- right content-->
	    		<div class="col-md-7 no-paddin-xs">
	    			<!-- add post form-->
        			<div class="panel profile-info panel-success">
			          <form action="" method="POST" name="form" id="imageform" enctype="multipart/form-data" action='upload.php'>
            <textarea name="post" id="post" class="form-control input-lg p-text-area" rows="2" placeholder="Whats in your mind today?"></textarea>
                </form>
                <?php echo @$success; ?>

            <div class="panel-footer">
               <input type="submit" id="update" value="Post" class="btn btn-info pull-right">

              <ul class="nav nav-pills">
                
            </div>
			        </div><!-- end add post form-->
<!-- end add post form-->
              <!-- first post -->
              <div id="main">
            <?php include 'embedmypost.php'; ?>
            </div>
					<div class="panel panel-white post-load-more panel-shadow text-center">
						<button class="btn btn-success">
							<i class="fa fa-refresh"></i>Load More...
						</button>
					</div>
	    		</div><!-- end right content-->	
	    	</div>
	    </div>   
    </div>

    <!-- Online users sidebar content-->
    <div class="chat-sidebar focus">
      <div class="list-group text-left">
        <p class="text-center visible-xs"><a href="#" class="hide-chat btn btn-success btn-sm">Hide</a></p> 
        <p class="text-center chat-title">Online users</p>  
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/guy-2.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Jeferh Smith</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="img/Friends/woman-1.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Dapibus acatar</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/guy-3.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Antony andrew lobghi</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/woman-2.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Maria fernanda coronel</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/guy-4.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Markton contz</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="img/Friends/woman-3.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Martha creaw</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="img/Friends/woman-8.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Yira Cartmen</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/woman-4.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Jhoanath matew</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/woman-5.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Ryanah Haywofd</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/woman-9.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Linda palma</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/woman-10.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Andrea ramos</span>
        </a>
        <a href="messages.html" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="img/Friends/child-1.jpg" class="img-chat img-thumbnail">
          <span class="chat-user-name">Dora ty bluekl</span>
        </a>        
      </div>
    </div><!-- Online users sidebar content-->
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>

   <script type="text/javascript" src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>

    <script type="text/javascript">
  $(document).ready(function(){
//Initialize the DOM

$('#update').click(function(){

var test=$('#post').val();
var dataString = 'post='+ test;
if (test=='') {
  alert('Write something...');
}
else
{
  $('#loader').show();
  $('#loader').fadeOut(400).html('<img src="img/preloader.gif" width="40"> Updating...');
  var dataString = 'post='+test;

                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "postdata.php",
                    data: dataString,
                    cache: false,

    success: function(html)
    {
      $('#content').prepend(html);
      $('#post').val('');
      $('#content').focus();
      $('#loader').hide();
 
   }
  });
}
return false;
   });

});
   
</script>

<!-- *********************************************************************
              Comment plugin
   *********************************************************************** -->
<script type="text/javascript">
$(function() { 

  //alert(postid);
$(".comment_submit").click(function() {
 var postid = $(this).attr('id');

//var name = $("#name").val();
//var email = $("#email").val();
  var comment = $("#comment"+postid).val();
   //alert(postid); 
    var dataString = 'comment=' + comment + '&postid=' + postid;
  
  if(comment=='')
     {
    alert('Please Enter Content');
     }
  else
  {
  $("#cflash"+postid).show();
  $("#cflash"+postid).fadeIn(400).html('<img src="images/ajax-loader.gif" align="absmiddle">');
$.ajax({
    type: "POST",
  url: "ajaxcomment.php",
   data: dataString,
  cache: false,
  success: function(html){
 //alert(post_id);
  $("#comments-list"+postid).append(html);
    $("#comment"+postid).val('');
  //$("#name").focus();
 
  $("#cflash"+postid).hide();
  
  }
 });
}
return false;
  });



});


</script>
<!-- *********************************************************************
            End Comment plugin
   *********************************************************************** -->


<!-- *********************************************************************
   Purpose      : function to truncate text and show read more links.
   Parameters       : @maxLenghtc : story description
   Returns      : string
   *********************************************************************** -->
<script type="text/javascript">
$(document).ready(function(){
  var maxLength = 300;
  $(".show-read-more").each(function(){
    var myStr = $(this).text();
    if($.trim(myStr).length > maxLength){
      var newStr = myStr.substring(0, maxLength);
      var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
      $(this).empty().html(newStr);
      $(this).append(' <a href="javascript:void(0);" class="read-more">read more...</a>');
      $(this).append('<span class="more-text">' + removedStr + '</span>');
    }
  });
  $(".read-more").click(function(){
    $(this).siblings(".more-text").contents().unwrap();
    $(this).remove();
  });
});
</script>
<!-- *********************************************************************
   Purpose      : function to truncate text and show read more links.
   Parameters       : @maxLenghtc : story description
   Returns      : string
                                    END HERE
   *********************************************************************** -->

<script src="js/jquery.elastic.source.js" type="text/javascript" charset="utf-8" async></script>
    <script type="text/javascript">
      // <![CDATA[
      //$(document).ready(function(){
        $('textarea').elastic();
        $('.well').elastic();
        $('.col-md-12').trigger('update');
      //});
      // ]]>
    </script>

    <script>
  $(document).ready(function()
  {
    
  $('body').on("click",'.heart',function()
    {
      
      var A=$(this).attr("id");
      var B=A.split("like");
        var messageID=B[1];
        var C=parseInt($("#likeCount"+messageID).html());
      $(this).css("background-position","")
        var D=$(this).attr("rel");
       
        if(D === 'like') 
        {      
        $("#likeCount"+messageID).html(C+1);
        $(this).addClass("heartAnimation").attr("rel","unlike");
        //alert(messageID);

var dataString = 'userid='+<?php echo $_SESSION['uid']; ?>+'&postid='+messageID;
// AJAX Code To Submit Form.
//alert('<?php echo $_SESSION['uid']; ?>');
$.ajax({
type: "POST",
url: "like.php",
data: dataString,
cache: false,
});
        }
        else
        {
        $("#likeCount"+messageID).html(C-1);
        $(this).removeClass("heartAnimation").attr("rel","like");
        $(this).css("background-position","left");
        }
    });
  });
  </script>



<script type="text/javascript">
$(document).ready(function(){
//Initialize the DOM
$(".follow").click(function(){

var element = $(this);
var usertoken = element.attr("id");
  //alert(usertoken);
  $(this).removeClass();
    $(this).addClass("btn btn-danger following");
    $(this).text("Following");

var dataString = 'friend='+usertoken+'&user_id='+<?php echo $session_uid; ?>;
                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "ajax/respond-request.php",
                    data: dataString,
                    cache: false,

                  });
return false;

});

});
</script>


    <script type="text/javascript">
$(function() {
    $("#uploadFile").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function(){ // set image data as background of div
                $("#imagePreview").css("background-image", "url("+this.result+")");
            }
        }
    });
});
</script>


 <script type="text/javascript">
$(function() {
    $("#uploadProfile").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function(){ // set image data as background of div
                $("#imageProfile").css("background-image", "url("+this.result+")");
            }
        }
    });
});
</script>

  </body>
</html>
