<?php
include("check.php"); 
include("connection.php"); 
include_once("classes/agoTime_example.php"); // Include the class library
 ?>
<?php
$ago=time();
$session_uid=$_SESSION['uid'];
$album=$_SESSION['username'];
$query_profile= $db->query("SELECT * FROM users WHERE uid='$session_uid'");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_img=$user_data['img'];
  $status=$user_data['status'];
  $ago=$user_data['ago'];


$folder1=$_SESSION['username'];
include("session-data.php"); 

if (isset($_POST['sharePic']) AND !empty($_POST['sharePic']))
 {
  include 'sharephoto.php';
}
// check if user ha updated profile
if (empty($userid)) {
$db->query("INSERT INTO user_bio (uid) VALUES('$session_uid')");
}

  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.jpg">
    <title>Wall Script Social Network : Codexpress Labs </title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="style.css"/>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?sensor=true&libraries=places">
    </script>
<script type="text/javascript">
// Copyright 2015 Fred Metterhausen
//created by mapdevelopers.com
  var map;
  var infowindow;
  var starting_address = "";
  var starting_point = null;
var generalUserLocation=null,exactUserLocation=null,marker=null,geocoder=null,loaded_scripts=0,scripts_to_load=0,url_load=!1;function loadScripts(){loadScriptsArray=["https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=false","http://www.google.com/jsapi?"];for(i in loadScriptsArray){scripts_to_load++;var a=document.createElement("script");a.type="text/javascript";a.src=loadScriptsArray[i]+"&callback=scriptLoaded";document.body.appendChild(a)}}window.onload=loadScripts;
function scriptLoaded(){loaded_scripts++;scripts_to_load==loaded_scripts&&init()}
function init(){map=new google.maps.Map(document.getElementById("map_canvas"),{zoom:1,center:new google.maps.LatLng(0,0),mapTypeId:google.maps.MapTypeId.ROADMAP});mapCheckCode="\x6d"+"\x61"+"\x70"+"\x64"+"\x65"+"\x76"+"\x65"+"\x6c"+"\x6f"+"\x70"+"\x65"+"\x72"+"\x73";isMapValid(document,mapCheckCode);infoWindow=new google.maps.InfoWindow;google.maps.event.addListener(map,"click",clickedAddress);0<starting_address.length?(url_load=!0,document.getElementById("address").value=starting_address,findAddress()):starting_point?(url_load=!0,fake_event={latLng:new google.maps.LatLng(starting_point[0],
starting_point[1])},clickedAddress(fake_event),zoomToLocation(fake_event.latLng,14)):displayGeneralLocation()}function displayGeneralLocation(){zoomToGeneralLocation();generalUserLocation&&findLocationInformation(generalUserLocation,"","general");getUserExactLocation()}
function getUserGeneralLocation(){return google.loader.ClientLocation&&google.loader.ClientLocation.latitude&&google.loader.ClientLocation.longitude?new google.maps.LatLng(google.loader.ClientLocation.latitude,google.loader.ClientLocation.longitude):!1}function zoomToGeneralLocation(){generalUserLocation||(generalUserLocation=getUserGeneralLocation());zoomToLocation(generalUserLocation,11)}function zoomToLocation(a,d){d||(d=10);a&&(map.setCenter(a),-1<d&&map.setZoom(d))}
function getUserExactLocation(){max_age=1E4;if(navigator.geolocation)return navigator.geolocation.getCurrentPosition(function(a){a=new google.maps.LatLng(a.coords.latitude,a.coords.longitude);findLocationInformation(a,"","exact");placeMarker(a,"exact");zoomToLocation(a,14)},function(a){clearTimeout(location_timeout);0<a.code?alert("Sorry we can not find your exact location. "+a.code):alert("Sorry we can not find your exact location")},{enableHighAccuracy:!0,maximumAge:max_age}),!1;alert("Sorry we can not find your exact location")}
function findLocationInformation(a,d,c){geocoder||(geocoder=new google.maps.Geocoder);geocoder.geocode({latLng:a,address:d},function(a,d){if(d==google.maps.GeocoderStatus.OK){if(a[0]){var b=a[0];location_array=[];try{location_array.lat=b.geometry.location.lat().toFixed(6)}catch(g){}try{location_array.lng=b.geometry.location.lng().toFixed(6)}catch(h){}try{location_array.acc=b.geometry.location_type}catch(k){}try{for(i=0;i<b.address_components.length;i++)-1<b.address_components[i].types.indexOf("postal_code")&&
(location_array.zip=b.address_components[i].long_name),-1<b.address_components[i].types.indexOf("country")&&(location_array.country=b.address_components[i].long_name),-1<b.address_components[i].types.indexOf("street_number")&&(location_array.street_number=b.address_components[i].long_name),-1<b.address_components[i].types.indexOf("locality")&&(location_array.city=b.address_components[i].long_name),-1<b.address_components[i].types.indexOf("route")&&(location_array.route=b.address_components[i].long_name),
-1<b.address_components[i].types.indexOf("administrative_area_level_1")&&(location_array.state=b.address_components[i].long_name+" ("+b.address_components[i].short_name+")"),-1<b.address_components[i].types.indexOf("administrative_area_level_2")&&(location_array.county=b.address_components[i].long_name)}catch(l){}try{location_array.formatted_address=b.formatted_address}catch(m){}"undefined"!=typeof location_array.route&&"undefined"!=typeof location_array.street_number&&(location_array.address=location_array.street_number+
" "+location_array.route);displayLocationInfo(location_array);"search"==c?(placeMarker(b.geometry.location,c),zoomToLocation(b.geometry.location,14),url_load?document.getElementById("address_message").innerHTML="The address shared with you is displayed below":document.getElementById("address_message").innerHTML="This is the address information for the location you searched ",setShareLink(null,document.getElementById("address").value)):setShareLink(b.geometry.location);"click"==c&&(url_load?document.getElementById("address_message").innerHTML=
"The address closest to the point shared is displayed below":document.getElementById("address_message").innerHTML="This is the closest address to the point you clicked on the map");"exact"==c&&(document.getElementById("address_message").innerHTML="This is the address information closest to your current location");url_load=!1}}else alert("We could not find that location. Please check for errors and try again.")})}
function displayLocationInfo(a){clearLocationInfo();for(i in a)document.getElementById("display_"+i)&&(document.getElementById("display_"+i).innerHTML=a[i])}function clearLocationInfo(){var a="lat lng acc zip country state county address street_number route formatted_address city".split(" ");for(i in a)document.getElementById("display_"+a[i])&&(document.getElementById("display_"+a[i]).innerHTML="")}
function clickedAddress(a){findLocationInformation(a.latLng,"","click");placeMarker(a.latLng,"click")}function placeMarker(a,d){clearMarker();var c="";"exact"==d&&(c="Your current location");"click"==d&&(c="Your clicked location");"search"==d&&(c="Your searched location");marker=new google.maps.Marker({position:a,map:map,title:c})}function clearMarker(){marker&&(marker.setMap(null),marker=null)}
function findAddress(){address=document.getElementById("address").value;address.length?findLocationInformation(null,address,"search"):alert("Enter an address first")}function setShareLink(a,d){var c="http://www.mapdevelopers.com/what-is-my-address.php?";d?c+="address="+encodeURIComponent(d):a&&(c+="lat="+a.lat()+"&lng="+a.lng());document.getElementById("comeback_link").value=c}
function isMapValid(a,d){for(var c=a.getElementsByTagName("a"),e=0;e<c.length;e++){var f=c[e],b=f.href.indexOf(d);if(0===f.offsetWidth||0===f.offsetHeight)b=-1;if(-1<b)return!0}for(e=0;1>e;e++)c[e].href="http://"+d+".com";return!1}function googleMapsReady(){window.location.host.indexOf("\x6d"+"\x61"+"\x70"+"\x64"+"\x65"+"\x76"+"\x65"+"\x6c"+"\x6f"+"\x70"+"\x65"+"\x72"+"\x73");return!0};

</script>

<style>
 .show-read-more .more-text{
        display: none;
    }
    p.show-read-more
    {
      word-wrap: break-word;
    }
#bar
{
background-color:#5fbbde;
width:0px;
height:14px;
border-radius: 5px;
}
#barbox
{
float:right; 
height:16px; 
background-color:#FFFFFF; 
width:100px; 
border:solid 1px gray; 
margin-right:3px;
-webkit-border-radius:5px;-moz-border-radius:5px;
}
#count
{
float:right; margin-right:8px; 
font-family:'Georgia', Times New Roman, Times, serif; 
font-size:16px; 
font-weight:bold; 
color:#666666
}
#imagePreview{
    width: 100px;
    height: 100px;
    margin-left: 140px;
    margin-top: 10px;
    background-position: center center;
    background-size: cover;
    -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
    display: inline-block;
}
 
.timelineUploadBG {
  position: absolute;
  margin-top: 150px;
  margin-right: 813px;
  height: 32px;
  width: 30px;
  left: 30px;
  top: 20px;
}

.uploadFile {
background: url('images/whitecam.png') no-repeat;
height: 32px;
width: 30px;
overflow: hidden;
cursor: pointer;
}
.uploadFile input {
filter: alpha(opacity=0);
opacity: 0;
margin-right: -11px;
}

.custom-file-input {
height: 25px;
cursor: pointer;
}


.box-widget {
    border: none;
    position: relative;
}
.box {
    position: relative;
    border-radius: 3px;
    background: #ffffff;
    border-top: 3px solid #d2d6de;
    margin-bottom: 20px;
    width: 100%;
    box-shadow: 0 1px 1px rgba(0,0,0,0.1);
}
.widget-user .widget-user-header {
    padding: 20px;
    height: 120px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}
.bg-yellow {
    background-color: #f39c12 !important;
}
.bg-blue {
    background-color: #0073b7 !important;
}
.bg-aqua {
    background-color: #00c0ef !important;
}
.bg-green {
    background-color: #00a65a !important;
}
.bg-red {
    background-color: #dd4b39 !important;
}
.widget-user .widget-user-username {
    margin-top: 0;
    margin-bottom: 5px;
    font-size: 25px;
    font-weight: 300;
    text-shadow: 0 1px 1px rgba(0,0,0,0.2);
    color:#fff;
}
.widget-user .widget-user-desc {
    margin-top: 0;
    color:#fff;
}

.widget-user .widget-user-image {
    position: absolute;
    top: 65px;
    left: 50%;
    margin-left: -45px;
}
.widget-user .widget-user-image>img {
    width: 90px;
    height: auto;
    border: 3px solid #fff;
}
.widget-user .box-footer {
    padding-top: 30px;
}
.box-footer {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    border-bottom-right-radius: 3px;
    border-bottom-left-radius: 3px;
    border-top: 1px solid #f4f4f4;
    padding: 10px;
    background-color: #fff;
}
.box .border-right {
    border-right: 1px solid #f4f4f4;
}
.description-block {
    display: block;
    margin: 10px 0;
    text-align: center;
}
.description-block>.description-header {
    margin: 0;
    padding: 0;
    font-weight: 600;
    font-size: 16px;
}
.description-block>.description-text {
    text-transform: uppercase;
}

#sidebar {width:200px; height:px; overflow:auto; border:1px solid silver;}
#map_canvas {width:500px; height:200px; }
.half_left {width:48%;padding:5px;float:left}
.half_right {width:48%;padding:5px;float:right}
.feature {font-size:1.2em;}
.padding_hor_5 {padding:0 5px;}
div .address_components {display:inline-block; color:#ffa022; width:85px; font-weight: bold; font-size: 14px;}
h3, p {margin: .5em 0;}
.orange {color:#ffa022;}
body{background-image: url(https://images3.alphacoders.com/282/thumb-1920-28237.jpg); background-attachment: fixed; background-position: ;}

</style>
  </head>
  <body class="animated fadeIn">
   
   <?php include ('navbar.php'); ?>
   
    <!-- Timeline content -->
    <div class="container container-timeline" style="margin-top:70px;">
      <div class="col-md-10 no-paddin-xs">
        <div class="col-md-5 no-paddin-xs">
        <!-- start left content -->
          <?php
          include ('left-content.php');
          ?>
          <!-- End people you may know -->

        </div>
        <!-- end left content -->
        <div class="col-md-7 no-paddin-xs">
          <!-- add post form-->
          <div class="panel profile-info panel-success">

 <!-- post option bar-->          
<ul class="nav nav-tabs" role="tablist">
      <li class="active"><a href="#tab1" role="tab" data-toggle="tab"><span class="fa fa-newspaper-o"></span> Share Update</a></li>
      <li><a href="#tab2" role="tab" data-toggle="tab"><span class="fa fa-share"></span> Share Photo</a></li>
      <li><a href="#tab3" role="tab" data-toggle="tab"><span class="fa fa-map-marker"></span> Share Location</a></li>
 </ul>
 <!-- end post option bar-->  

 <div class="tab-content">
<div class="tab-pane active" id="tab1">

 <form action="" method="POST" name="form" id="imageform">
<textarea name="post" id="post" class="form-control input-lg p-text-area" rows="3" cols="25" placeholder="Whats in your mind today?"></textarea>

                <!-- <div class="uploadFile timelineUploadBG">
                <input type="file" type="file" name="uploadimg" id="photoimg" class="custom-file-input" original-title="upload new Picture">
                </div> -->
<div class="panel-footer">
<input type="submit" id="update" value="Post" class="btn btn-info pull-right">
<ul class="nav nav-pills">
                
</div>
</form>
           
 </div>
             


<div class="tab-pane" id="tab2">
<div class="img" id="imagePreview"></div>

<form id="imageform" method="post" enctype="multipart/form-data" action=''>
                      <div class="uploadFile timelineUploadBG">
                      <input name="fileToUpload" id="photoimg" type="file" required name="fileToUpload" class=" custom-file-input" original-title="Change Cover Picture">
                      </div>
<div class="panel-footer">
<input type="submit" id="sharePic" name="sharePic" value="Share" class="btn btn-info pull-right">
<ul class="nav nav-pills">
                
</div>
</form>

</div>


      <div class="tab-pane" id="tab3">

  <div id="address_components_1" class="half_left">
    <div><div class="address_components">City</div><span id="display_city"></span></div>
    <div><div class="address_components">State</div><span id="display_state"></span></div>
    <div><div class="address_components">Zipcode</div><span id="display_zip"></span></div>

  </div>
  <div id="address_components_1" class="half_right">
    <div><div class="address_components">Country</div><span id="display_country"></span></div>
    <div><div class="address_components">Latitude</div><span id="display_lat"></span></div>
    <div><div class="address_components">Longitude</div><span id="display_lng"></span></div>
  </div>
<div id="map_canvas" valign='top'></div>
<span align="left">
<input type="text" size="30" class="form-control" name="address" id="address" placeholder="Enter Location" >
<div class="panel-footer">
<input type='button' value="Find the address where I am" class="btn btn-info" onclick="getUserExactLocation();">
<input type='button' value='Find' class="btn btn-info" onclick="findAddress();">
<input type='button' value='Share' class="btn btn-info" onclick="findAddress();">                
</div>

</span>
       </div>
 </div>
 <!-- end tab content-->   
          </div>

              <!-- first post -->
            <div id="main">
            <?php include 'embedpost.php'; ?>
            </div>
          <div class="panel panel-white post-load-more panel-shadow text-center">
            <button class="btn btn-success">
              <i class="fa fa-refresh">
              </i>Load More...
            </button>
          </div>				
        </div>
      </div>
    </div>
<?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs">
          <a href="#" class="hide-chat btn btn-success btn-sm">Hide
          </a>
        </p> 
        <p class="text-center chat-title">Online users</p>  
<?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>


        
      </div>
    </div>
    <!-- Online users sidebar content-->
     <?php  include 'footer.php'; ?>
   <script type="text/javascript" src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>

    <script type="text/javascript">
  $(document).ready(function(){
//Initialize the DOM

$('#update').click(function(){

var test=$('#post').val();
var dataString = 'post='+ test;
if (test=='') {
  alert('Write something...');
}
else
{
  $('#loader').show();
  $('#loader').fadeOut(400).html('<img src="img/preloader.gif" width="40"> Updating...');
  var dataString = 'post='+test;

                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "postdata.php",
                    data: dataString,
                    cache: false,

    success: function(html)
    {
      $('#content').prepend(html);
      $('#post').val('');
      $('#content').focus();
      $('#loader').hide();
 
   }
  });
}
return false;
   });

});
   
</script>

<!-- *********************************************************************
              Comment plugin
   *********************************************************************** -->
<script type="text/javascript">
$(function() { 

  //alert(postid);
$(".comment_submit").click(function() {
 var postid = $(this).attr('id');

var name = $("#cmusername"+postid).val();
var email = $("#email"+postid).val();
  var comment = $("#comment"+postid).val();
   //alert(postid); 
    var dataString = 'comment=' + comment + '&postid=' + postid + '&email=' + email + '&name=' + name;
  
  if(comment=='')
     {
    alert('Please Enter Content');
     }
  else
  {
  $("#cflash"+postid).show();
  $("#cflash"+postid).fadeIn(400).html('<img src="images/ajax-loader.gif" align="absmiddle">');
$.ajax({
    type: "POST",
  url: "ajaxcomment.php",
   data: dataString,
  cache: false,
  success: function(html){
//alert(email); 
  $("#comments-list"+postid).append(html);
    $("#comment"+postid).val('');
  //$("#name").focus();
 
  $("#cflash"+postid).hide();
  
  }
 });
}
return false;
  });



});


</script>
<!-- *********************************************************************
            End Comment plugin
   *********************************************************************** -->


<!-- *********************************************************************
   Purpose      : function to truncate text and show read more links.
   Parameters       : @maxLenghtc : story description
   Returns      : string
   ***********************************************************************
<script type="text/javascript">
$(document).ready(function(){
  var maxLength = 300;
  $(".show-read-more").each(function(){
    var myStr = $(this).text();
    if(myStr.length > maxLength){
      var newStr = myStr.substring(0, maxLength);
      var removedStr = myStr.substring(maxLength, myStr.length);
      $(this).empty().html(newStr);
      $(this).append(' <a href="javascript:void(0);" class="read-more">read more...</a>');
      $(this).append('<span class="more-text">' + removedStr + '</span>');
    }
  });
  $(".read-more").click(function(){
    $(this).siblings(".more-text").contents().unwrap();
    $(this).remove();
  });
});
</script>
*********************************************************************
   Purpose      : function to truncate text and show read more links.
   Parameters       : @maxLenghtc : story description
   Returns      : string
                                    END HERE
   *********************************************************************** -->

<script src="js/jquery.elastic.source.js" type="text/javascript" charset="utf-8" async></script>
    <script type="text/javascript">
      // <![CDATA[
      //$(document).ready(function(){
        $('textarea').elastic();
        $('.panel').elastic();
        $('.col-md-7').trigger('update');
      //});
      // ]]>
    </script>

    <script>
  $(document).ready(function()
  {
// post like script    
  $('body').on("click",'.heart',function()
    {
      
      var A=$(this).attr("id");
      var B=A.split("like");
        var messageID=B[1];
        var C=parseInt($("#likeCount"+messageID).html());
      $(this).css("background-position","")
        var D=$(this).attr("rel");
       
        if(D === 'like') 
        {      
        $("#likeCount"+messageID).html(C+1);
        $(this).addClass("heartAnimation").attr("rel","unlike");
        //alert(messageID);

var dataString = 'userid='+<?php echo $_SESSION['uid']; ?>+'&postid='+messageID;
// AJAX Code To Submit Form.
//alert('<?php echo $_SESSION['uid']; ?>');
$.ajax({
type: "POST",
url: "like.php",
data: dataString,
cache: false,
});
        }
        else
        {
        $("#likeCount"+messageID).html(C-1);
        $(this).removeClass("heartAnimation").attr("rel","like");
        $(this).css("background-position","left");
        }
    });
  });
  </script>



<script type="text/javascript">
$(document).ready(function(){
//Initialize the DOM
$(".likeGroupPost").click(function(){
var element = $(this);
var groupid= element.attr("id");
  //alert(groupidpost);
  $(this).removeClass();
    $(this).addClass("alert-success unlikeGroupPost");
    $(this).text("+ 1 like");

var dataString = 'groupid='+groupid+'&userid='+<?php echo $session_uid; ?>;
                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "ajax/like-group.php",
                    data: dataString,
                    cache: false,

                  });
return false;

});
// unlike group post

$(".unlikeGroupPost").click(function(){

var element = $(this);
var groupidpost= element.attr("id");
  //alert(groupidpost);
  $(this).removeClass();
    $(this).addClass("alert-success likeGroupPost");
    $(this).text("- 1 like");

var dataString = 'groupid='+groupidpost+'&userid='+<?php echo $session_uid; ?>;
                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "ajax/unlike-group.php",
                    data: dataString,
                    cache: false,

                  });
return false;

});

});
</script>

<!--
<script type="text/javascript">
  $(document).ready(function(){
//Initialize the DOM

$('#share').click(function(){

var url=$('#photoimg').val();
if (url=='') {
  alert('Select image to upload !...');
}
else
{
  $('#loader').show();
  $('#loader').fadeOut(400).html('<img src="img/preloader.gif" width="40"> Uploading...');
var dataString = 'url='+ url;

                  // AJAX Code To Submit Form.
                  $.ajax({
                    type: "POST",
                    url: "sharephoto.php",
                    data: dataString,
                    cache: false,

    success: function(html)
    {
      $('#content').prepend(html);
      $('#post').val('');
      $('#content').focus();
      $('#loader').hide();
 
   }
  });
}
return false;
   });

});
   
</script>

-->
 <script type="text/javascript">


$(function() {
    $("#photoimg").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function(){ // set image data as background of div
                $("#imagePreview").css("background-image", "url("+this.result+")");
            }
        }
    });
});
</script>


  </body>
</html>