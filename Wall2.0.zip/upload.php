<?php
include('config/config.php');
$path = "uploads/";
$user_id=$_SESSION['uid'];
//$username=$_SESSION['username'];
$time=time();

	$valid_formats = array("jpg", "png", "gif", "bmp");
	if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name = $_FILES['photoimg']['name'];
			$size = $_FILES['photoimg']['size'];
			
			if(strlen($name))
				{
					list($txt, $ext) = explode(".", $name);
					if(in_array($ext,$valid_formats))
					{
					if($size<(1024*1024))
						{
							$image = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
							$tmp = $_FILES['photoimg']['tmp_name'];
							if(move_uploaded_file($tmp, $path.$image))
								{
	$db->query("INSERT INTO post (created, user_id, type, message) 
		VALUES ('$time','$user_id','local', '$image')");

echo '<script>alert("Image file size must not exceed 1MB!"); </script>';		
								}
							else
								echo "failed";
						}
						else
						echo '<script>alert("Image file size must not exceed 1MB!"); </script>';					
						}
						else
						echo '<script>alert("Invalid file format!"); </script>';	
				}
				
			else
				echo '<script>alert("Please select image to upload"); </script>';
				
			exit;
		}
?>