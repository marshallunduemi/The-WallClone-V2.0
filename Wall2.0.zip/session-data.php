<?php
$sqlheadline=$db->query("SELECT * FROM user_bio WHERE uid='$session_uid'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$phone=$row['phone'];
$address=$row['address'];
$site=$row['site'];
$country=$row['country'];
$state=$row['state'];
$lessons=$row['lessons'];
$linked=$row['linkedIn'];
$day=$row['day'];
$month=$row['month'];
$yr=$row['yr'];
$info=$row['about'];
$useruid=$row['uid'];

?>