<?php include 'session.php'; ?>
<?php include 'connection.php'; ?>
<?php
$session_uid=$_SESSION['uid'];

$folder1=$_SESSION['username'];
?>
<?php 
$query_profile= $db->query("select * from users where uid='$session_uid' AND 1=1");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_email=$user_data['email'];
  $profile_background=$user_data['profile_background'];
  $user_img=$user_data['img'];
  $profile_background_position=$user_data['profile_background_position'];


$sqlheadline=$db->query("select * from user_bio where uid='$session_uid'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$phone=$row['phone'];
$address=$row['address'];
$site=$row['site'];
$country=$row['country'];
$state=$row['state'];
$lessons=$row['lessons'];
$linked=$row['linkedIn'];
$dob=$row['dob'];
$info=$row['about'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Day-Friend</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">
    <script src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    <!-- Start VisualLightBox.com HEAD section -->
    <link rel="stylesheet" href="vlb_files1/vlightbox1.css" type="text/css" />
    <link rel="stylesheet" href="vlb_files1/visuallightbox.css" type="text/css" media="screen" />
<script src="vlb_engine/jquery.min.js" type="text/javascript"></script>
    <script src="vlb_engine/visuallightbox.js" type="text/javascript"></script>
    <!-- End VisualLightBox.com HEAD section -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
        <style>
.error{
                margin-bottom: 40px;
                background: red;
                padding: 5px;
                color: white;
            }

#imagePreview{
    width: 150px;
    height: 150px;
    margin-left: 80px;
    background-position: center center;
    background-size: cover;
    -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
    display: inline-block;
}
</style>

  </head>
  <body class="animated fadeIn">

   <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <a class="navbar-brand" href="home.php">
            <b>The Wall Script 2.0
            </b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <div class="col-md-5 col-sm-4">         
            <form class="navbar-form" action="search.php" method="get">
              <div class="form-group" style="display:inline;">
                <div class="input-group" style="display:table;">
                  <input class="form-control" name="s" placeholder="Hit Enter Search Users, Groups..." autocomplete="off" type="text">
                  <input type="hidden" name="searching" value="yes" />
                  <span class="input-group-addon" style="width:1%;">
                    <span class="fa fa-search"></span>
                  </span>
                </div>
              </div>
            </form>
          </div>        
          <ul class="nav navbar-nav navbar-right">
              <li>
              <a href="profile.php">
                <img src="user_img/<?php echo "$folder1/$user_img"; ?>" class="img-nav">
              </a>
            </li>
            <li  class="active">
              <a href="home.php">
                <i class="fa fa-bars">
                </i>&nbsp;Home
              </a>
            </li>
            <li>
              <a href="messages.php">
                <i class="fa fa-envelope">
                </i>
              </a>
            </li>
            <li>
              <a href="notifications.php">
                <i class="fa fa-globe">
                </i>
              </a>
            </li>
            <li>
              <a href="edit-profile.php">
                <i class="fa fa-cogs">
                </i>
              </a>
            </li>
            <li>
              <a href="#" class="nav-controller">
                <i class="fa fa-users">
                </i>
              </a>
            </li>
            <li>
              <a href="logout.php" class="nav-controller">
                <i class="fa fa-sign-out">
                </i> Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Timeline content -->
    <div class="container">
      <!-- cover content -->
      <div class="row">
        <div class="col-md-10 no-paddin-xs">
                  <div class="col-md-12 col-sm-12 col-xs-12 cover-content">
        <div class="cover-container" style="background-image: url(<?php echo "user_img/$folder1/$profile_background"; ?>);" id="imageProfile">
          <div class="social-cover"></div>
          <div class="social-desc">
             <div class="desc-content">
                <h1 class="fg-white text-shadow"><?php echo "$country $state"; ?></h1>
                <h5 class="fg-white text-shadow">- <?php echo date('M d, Y'); ?></h5>
                <div style="margin-top:50px;"></div>
             </div>
          </div>
          <div class="social-avatar" >
          <div class="img-avatar" style="background-image: url(<?php echo "user_img/$username/$user_img"; ?>);" id="imagePreview"></div>
             <h4 class="fg-white text-center text-shadow">
             <?php echo "$name @ $username";?></h4>
             <h5 class="fg-white text-center" style="opacity:0.8;"><?php echo $info;?></h5>

             <hr class="border-black75 text-shadow" style="border-width:2px;" >
                <div class="text-center">
                  <a href="profile.php" role="button" class="btn btn-inverse btn-outlined btn-retainBg btn-brightblue"><span class="fa fa-user"> Profile</span></a>
                 </div>/a>
          </div>
        </div>
          </div><!-- end cover and profile image-->
          <!-- cover menu -->
          <div class="col-md-12  col-sm-12 col-xs-12">
            <div class="panel-options">
              <div class="navbar navbar-default navbar-cover">
                <div class="container-fluid">
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#profile-opts-navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                    </button>
                  </div>

                  <div class="collapse navbar-collapse" id="profile-opts-navbar">
                    <ul class="nav navbar-nav navbar-right">
                      <li><a href="profile.php"><i class="fa fa-tasks"></i>Timeline</a></li>
                      <li><a href="<?php echo "$username";?>"><i class="fa fa-info-circle"></i>About</a></li>
                      <li><a href="friends.php"><i class="fa fa-users"></i>Friends</a></li>
                      <li class="active"><a href="photos.php"><i class="fa fa-file-image-o"></i>Photos</a></li>
                      <li><a href="messages.php"><i class="fa fa-comment"></i>Messages</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- cover menu -->
        </div>
      </div><!-- cover content -->
      <div class="row">
        <div class="col-md-10 no-paddin-xs"> 
          <div class="col-md-12">
            <!-- panel photos -->
            <!-- panel photos -->
            <div class="panel panel-white panel-list-photos">
              <div class="panel-heading">
                <h3 class="panel-title">Photos</h3>
              </div>

              <div class="panel-body">

              <!-- Start VisualLightBox.com BODY section id=1 -->
  <?php
  $true=true;
$queryalbum = $db->query("SELECT * FROM `post` 
  WHERE `user_id`='$session_uid' AND message=''  ");
$count = mysqli_num_rows($queryalbum);

  ?>
  <div id="vlightbox1">
  <?php
  while($albums = mysqli_fetch_assoc($queryalbum))
    {
    $alimg=$albums['image'];
    ?>
  <a class="vlightbox1" href="user_img/<?php echo "$folder1/$alimg"; ?>"  title="<?php echo "$alimg"; ?>">
  <img src="user_img/<?php echo "$folder1/$alimg"; ?>" alt="<?php echo "$alimg"; ?>" class="img-responsive  show-in-modal">
  </a>
  <?php
}
?>



  </div>

  <!-- End VisualLightBox.com BODY section -->


                

                      
              </div>
            </div><!-- end panel photos -->
          </div>
        </div>
      </div>
    </div>
<?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs"><a href="#" class="hide-chat btn btn-success btn-sm">Hide</a></p> 
        <p class="text-center chat-title">Online users</p>  
        <?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>

      </div>
    </div><!-- Online users sidebar content-->
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>
  </body>
    <script src="vlb_engine/vlbdata1.js" type="text/javascript"></script>
</html>
