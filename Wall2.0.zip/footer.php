<footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="http://www.codexpresslabs.info/p/privacy-policy-for-codexpress-labs.html">Privacy Policy</a> | 
            <a href="http://facebook.com/marshallunduemi">Developers</a> | 
            <a href="http://codexpresslabs.info/p/contact-me.html">Contact</a> | 
            <a href="http://www.codexpresslabs.info/2016/05/wall-clone-social-network-script-20.html">About</a>
          </div>   
          Copyright &copy; <a href="http://www.codexpresslabs.info">CodeXpress Labs</a> <?php echo date("Y"); ?> - All rights reserved       
        </p>
      </div>
    </footer>