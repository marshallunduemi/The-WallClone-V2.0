<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'thewallc_wall');
define('DB_PASSWORD', '69735107');
define('DB_DATABASE', 'thewallc_wall');
$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

define('APPNAME', 'The Wall Clone 2.0');

?>