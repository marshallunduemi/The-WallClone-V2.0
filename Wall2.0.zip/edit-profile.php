<?php include 'session.php'; ?>
<?php include 'connection.php'; ?>
<?php
  define('INCLUDE_CHECK',1);
  require "dobfunctions.php";

if(isset($_POST["btn_update"])) 
{
    include 'updateuser.php';
  }

$session_uid=$_SESSION['uid'];

$folder1=$_SESSION['username'];
?>
<?php 
$query_profile= $db->query("select * from users where uid='$session_uid' AND 1=1");
  $user_data=mysqli_fetch_array($query_profile);
  $friend_id=$user_data['uid'];
  $username=$user_data['username'];
  $g_email=$user_data['email'];
  $profile_background=$user_data['profile_background'];
  $g_img=$user_data['img'];
  $profile_background_position=$user_data['profile_background_position'];


$sqlheadline=$db->query("select * from user_bio where uid='$session_uid'");
$row=mysqli_fetch_array($sqlheadline);
$headline=$row['headline'];
$gplus=$row['gplus'];
$tw=$row['tw'];
$fb=$row['fb'];
$name=$row['name'];
$phone=$row['phone'];
$address=$row['address'];
$site=$row['site'];
$country=$row['country'];
$state=$row['state'];
$lessons=$row['lessons'];
$linked=$row['linkedIn'];
$info=$row['about'];
$day=$row['day'];
$month=$row['month'];
$yr=$row['yr'];
$sex=$row['sex'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Wall Script Social Network: Edit Profile : Codexpress Labs</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/timeline.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="animated fadeIn">

   
    <!-- Fixed navbar -->
       <?php include ('navbar.php'); ?>
    <!-- Timeline content -->
    <div class="container container-timeline" style="margin-top:100px;">
    	<div class="col-md-10 no-paddin-xs">
			<!-- left content-->
    		<div class="col-md-10 col-md-offset-2 no-paddin-xs">

				<form id="" action="" method="post">
			    <!-- update cover and profile image-->
					<div class="panel panel-white post panel-shadow">
					  <div class="post-heading">
					      <div class="pull-left image">
					          <img src="<?php echo "user_img/$username/$g_img"; ?>" class="avatar" alt="user profile image">
					      </div>
					  </div>
					</div><!-- end update cover and profile image-->
			    <!-- update info -->
					<div class="panel panel-white post panel-shadow">
					  <div class="panel-body">

   <ul class="nav nav-tabs" role="tablist">
      <li class="active"><a href="#tab1" role="tab" data-toggle="tab"><span class="fa fa-child"></span> Details</a></li>
      <li><a href="#tab2" role="tab" data-toggle="tab"><span class="fa fa-newspaper-o"></span> Contact Info</a></li>
      <li><a href="#tab3" role="tab" data-toggle="tab"><span class="fa fa-map-marker"></span>  Place</a></li>
      <li><a href="#tab4" role="tab" data-toggle="tab"><span class="fa fa-globe"></span> Social Network</a></li>
      <li><a href="#tab5" role="tab" data-toggle="tab"><span class="fa fa-calendar"></span> Birth Date</a></li>
 </ul>
  <div class="alert alert-success" id="msg">Update Successful</div>
 <div class="tab-content">
      <div class="tab-pane active" id="tab1">

            <div class="form-group">
                <label class="col-md-3 control-label">Full Name</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $name; ?>" name="name" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">User Name</label>
                <div class="col-md-8">
                  <input class="form-control" disabled="disabled" value="<?php echo $username; ?>" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Work at</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $headline; ?>" name="work" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Email</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $g_email; ?>" disabled="disabled" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Sex</label>
                <div class="col-md-8">
                
                 <select name="sex" class="form-control">
                 <?php
                if (empty($sex)) {
                  echo '<option value="0">Select Sex:</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>';
                }
                elseif ($sex=="male")
                {
                  echo '<option value="male">Male</option>';
                }
                elseif ($sex=="female")
                {
                  echo '<option value="female">Female</option>';
                }

                ?>
                  
                </select>
                </div>
              </div>

             

              
       </div>
      <div class="tab-pane" id="tab2">
       <div class="form-group">
                <label class="col-md-3 control-label">Email</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $g_email; ?>" disabled="disabled" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Phone No.</label>
                <div class="col-md-8">
                  <input class="form-control"  value="<?php echo $phone; ?>" name="phone" placeholder="+2347069735107" type="number">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Website</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $site; ?>" name="site" placeholder="www.codexpresslabs.info" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Address</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $address; ?>" name="address" placeholder="Address" type="text">
                </div>
              </div>
      </div>


      <div class="tab-pane" id="tab3">
       <div class="form-group">
                <label class="col-md-3 control-label">Country</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $country; ?>" name="country" placeholder="Country" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">State</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $state; ?>" name="state" placeholder="State" type="text">
                </div>
              </div> 
       </div>


             <div class="tab-pane" id="tab4">
       <div class="form-group">
                <label class="col-md-3 control-label">Facebook</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $fb; ?>" name="fb" placeholder="/Username" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Twitter</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $tw; ?>" name="tw" placeholder="/Username" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Google Plus</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $gplus; ?>" name="gplus" placeholder="/+Username" type="text">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">9lessons</label>
                <div class="col-md-8">
                  <input class="form-control" value="<?php echo $lessons; ?>" name="lessons" placeholder="/Username" type="text">
                </div>
              </div>
      </div>

       <div class="tab-pane" id="tab5">
               <div class="form-group">
                <label class="col-md-3 control-label">Day</label>
                <div class="col-md-8">
      <select name="day" class="form-control">
      <?php
      if (empty($day)) {
       ?>
       <option value="0">Day: <?php echo "$day"; ?></option>
                  <?=generate_options(1,31)?>
      <?php
      }
      else
      {
        echo "<option value='$day'>$day</option>";
      }
      ?>
                 
      </select>

                </div>
              </div>

              <div class="form-group">
                <label class="col-md-3 control-label">Month</label>
                <div class="col-md-8">
             <select name="month" class="form-control">
             <?php
      if (empty($day)) {
       ?>
      <option value="0">Month: <?php echo "$month"; ?></option>
                  <?=generate_options(1,12,'callback_month')?>
      <?php
      }
      else
      {
        echo "<option value='$month'>$month</option>";
      }
      ?>
            </select>

                </div>
              </div>

              <div class="form-group">
                <label class="col-md-3 control-label">Year</label>
                <div class="col-md-8">
                <select name="yr" class="form-control">
                       <?php
      if (empty($day)) {
       ?>
       <option value="0">Year: <?php echo "$yr"; ?></option>
                  <?=generate_options(date('Y'),1900)?>
      <?php
      }
      else
      {
        echo "<option value='$yr'>$yr</option>";
      }
      ?>

                 
                  </select>
                </div>
              </div>


              
              

</div>

 </div>

					  </div>
					</div><!-- end update info-->

					<div class="panel panel-white post-load-more panel-shadow text-center">
						<button class="btn btn-success" name="btn_update" type="submit" id="update">
							Save
						</button>
					</div>				
				</form>
    		</div><!-- end left content--> 
    	</div>
    </div>

    <?php
// Friends List Data relations between users and friends tables for displaying user friends

$flist=$db->query("SELECT F.status, U.username,U.img,U.uid,U.status, U.email
FROM users U, friends F
WHERE
CASE
WHEN F.friend_one = '$_SESSION[uid]'
THEN F.friend_two = U.uid
WHEN F.friend_two= '$_SESSION[uid]'
THEN F.friend_one= U.uid
END

AND
F.status='1'");
$friendsList=mysqli_num_rows($flist); // count of total friends


?>
    <!-- Online users sidebar content-->
    <div class="chat-sidebar">
      <div class="list-group text-left">
        <p class="text-center visible-xs">
          <a href="#" class="hide-chat btn btn-success btn-sm">Hide
          </a>
        </p> 
        <p class="text-center chat-title">Online users</p>  
<?php
while($fdata=mysqli_fetch_array($flist))
{
  if ($fdata['status']==1) {
    echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-check-circle connected-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }
  else
  {
     echo '<a href="'.@$fdata['username'].'" class="list-group-item">
          <i class="fa fa-times-circle absent-status"></i>
          <img src="user_img/'.@$fdata['username'].'/'.@$fdata['img'].'" class="img-chat img-thumbnail" width="40">
          <p class="chat-user-name">'.@$fdata['username'].'</p>
        </a>';
  }

 
}
if ($friendsList <= 0) {
echo'<h3>No Friends</h3>';
}
 ?>


        
      </div>
    </div>
    <!-- Online users sidebar content-->
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">
            <a href="#">Terms of Use</a> | 
            <a href="#">Privacy Policy</a> | 
            <a href="#">Developers</a> | 
            <a href="#">Contact</a> | 
            <a href="#">About</a>
          </div>   
          Copyright &copy; Company - All rights reserved       
        </p>
      </div>
    </footer>
    <script src="js/jquery.1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
     <script src="js/jquery.form.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
            // bind 'myForm' and provide a simple callback function
            $('#msg').hide();// hide input for image upload after ajax call
            $('#myUpdate').ajaxForm(function() {                
               $('#msg').slideDown().fadeOut(7000);
              $('#update').text("Save"); // after form submision set button to default text Update

            });
            // if user click update button, please change update text to updating
            $('#update').click(function(){
            $('#update').text("Updating...");
        });
             });
    </script>
  </body>
</html>
