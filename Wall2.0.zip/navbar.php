 <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <a class="navbar-brand" href="home.php">
            <b><?php echo APPNAME; ?>
            </b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <div class="col-md-5 col-sm-4">         
            <form class="navbar-form" action="search.php" method="get">
              <div class="form-group" style="display:inline;">
                <div class="input-group" style="display:table;">
                  <input class="form-control" name="s" placeholder="Hit Enter Search Users, Groups..." autocomplete="off" type="text">
                  <input type="hidden" name="searching" value="yes" />
                  <span class="input-group-addon" style="width:1%;">
                    <span class="fa fa-search"></span>
                  </span>
                </div>
              </div>
            </form>
          </div>        
          <ul class="nav navbar-nav navbar-right">
              <li>
              <a href="profile.php">
                <img src="user_img/<?php echo "$folder1/$g_img"; ?>" class="img-nav">
              </a>
            </li>
            <li>
              <a href="home.php">
                <i class="fa fa-bars">
                </i>&nbsp;Home
              </a>
            </li>
            <li>
              <a href="messages.php">
                <i class="fa fa-envelope">
                </i>
              </a>
            </li>
            <li>
              <a href="notifications.php">
                <i class="fa fa-globe">
                </i>
              </a>
            </li>
            <li>
              <a href="edit-profile.php">
                <i class="fa fa-cogs">
                </i>
              </a>
            </li>
            <li>
              <a href="#" class="nav-controller">
                <i class="fa fa-users">
                </i>
              </a>
            </li>
            <li>
              <a href="logout.php" class="nav-controller">
                <i class="fa fa-sign-out">
                </i> Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
